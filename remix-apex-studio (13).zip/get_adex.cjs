const fs = require('fs');
const content = fs.readFileSync('src/server/adex/adex3Engine.ts', 'utf-8');

const tStart = content.indexOf('static teachConcept(');
console.log("=== teachConcept ===");
console.log(content.substring(tStart, content.indexOf('}', tStart) + 1));

const rStart = content.indexOf('export class ReasoningEngine {');
const rEnd = content.indexOf('// ==========================================', rStart);
console.log("=== ReasoningEngine ===");
console.log(content.substring(rStart, rEnd));

const dStart = content.indexOf('private static detectIntent(');
const dEnd = content.indexOf('private static evaluateAndLearn', dStart);
console.log("=== detectIntent ===");
console.log(content.substring(dStart, dEnd));

