const fs = require('fs');
let code = fs.readFileSync('src/utils/avatar3dRenderer.ts', 'utf-8');

const regex = /export function buildAvatar3DParts[\s\S]+$/;
const newFunction = `export function buildAvatar3DParts(avatar: Partial<Record<string, any>>): AvatarPartDef[] {
  const skinColor = avatar.skinColor || '#fde047';
  const shirtId = avatar.shirtId || 'shirt_01';
  const pantsId = avatar.pantsId || 'pants_01';
  const shoesId = avatar.shoesId || 'default_shoes';
  const hairStyle = avatar.hairStyle || 'bacon_hair';
  const accessory = avatar.accessory || 'none';
  const bodyStyle = avatar.bodyStyle || 'blocky';

  const shirtInfo = SHIRT_MAP[shirtId] || { torso: '#dc2626', arms: '#b91c1c', accent: '#ffffff' };
  const pantsInfo = PANTS_MAP[pantsId] || { legs: '#1e3a8a', accent: '#3b82f6' };
  const shoesInfo = SHOES_MAP[shoesId] || null;
  const hairInfo = HAIR_MAP[hairStyle] || null;

  const parts: AvatarPartDef[] = [];

  // ==========================================
  // PERFECT BLOCKY PROPORTIONS (Classic 2006)
  // ==========================================
  // Torso: 2 x 2 x 1, Centered at Y = 0.5
  // Arms: 1 x 2 x 1, Centered at Y = 0.5, X = +/- 1.5
  // Legs: 1 x 2 x 1, Centered at Y = -1.5, X = +/- 0.5
  // Head: 1.25 x 1.25 x 1.25, Centered at Y = 2.125
  // ==========================================

  const tW = 2.0, tH = 2.0, tD = 1.0, tY = 0.5;
  const aW = 1.0, aH = 2.0, aD = 1.0, aY = 0.5, aX = 1.5;
  const lW = 1.0, lH = 2.0, lD = 1.0, lY = -1.5, lX = 0.5;
  const hS = 1.25, hY = 2.125;
  
  // Base Limbs
  parts.push(
    { name: 'Head', shape: 'block', size: { x: hS, y: hS, z: hS }, offset: { x: 0, y: hY, z: 0 }, color: skinColor },
    { name: 'Torso', shape: 'block', size: { x: tW, y: tH, z: tD }, offset: { x: 0, y: tY, z: 0 }, color: shirtInfo.torso || '#dc2626' },
    { name: 'LeftArm', shape: 'block', size: { x: aW, y: aH, z: aD }, offset: { x: -aX, y: aY, z: 0 }, color: shirtInfo.arms || '#b91c1c' },
    { name: 'RightArm', shape: 'block', size: { x: aW, y: aH, z: aD }, offset: { x: aX, y: aY, z: 0 }, color: shirtInfo.arms || '#b91c1c' },
    { name: 'LeftLeg', shape: 'block', size: { x: lW, y: lH, z: lD }, offset: { x: -lX, y: lY, z: 0 }, color: pantsInfo.legs || '#1e3a8a' },
    { name: 'RightLeg', shape: 'block', size: { x: lW, y: lH, z: lD }, offset: { x: lX, y: lY, z: 0 }, color: pantsInfo.legs || '#1e3a8a' }
  );

  // Clothing - Jackets (Adds slight volume to Torso and Arms)
  if (shirtInfo.modeledDetails?.hasLayeredJacket || shirtId.includes('jacket') || shirtId.includes('blazer')) {
    const jCol = shirtInfo.torso;
    parts.push(
      { name: 'JacketTorso', shape: 'block', size: { x: tW * 1.05, y: tH * 1.02, z: tD * 1.05 }, offset: { x: 0, y: tY, z: 0 }, color: jCol },
      { name: 'JacketLeftArm', shape: 'block', size: { x: aW * 1.06, y: aH * 1.02, z: aD * 1.06 }, offset: { x: -aX, y: aY, z: 0 }, color: shirtInfo.arms },
      { name: 'JacketRightArm', shape: 'block', size: { x: aW * 1.06, y: aH * 1.02, z: aD * 1.06 }, offset: { x: aX, y: aY, z: 0 }, color: shirtInfo.arms }
    );
  }

  // Shoes (Adds volume to bottom of legs)
  if (shoesId !== 'none' && shoesInfo) {
    const sCol = shoesInfo.color || '#18181b';
    parts.push(
      { name: 'LeftShoe', shape: 'block', size: { x: lW * 1.1, y: 0.5, z: lD * 1.1 }, offset: { x: -lX, y: lY - 0.75, z: 0.05 }, color: sCol },
      { name: 'RightShoe', shape: 'block', size: { x: lW * 1.1, y: 0.5, z: lD * 1.1 }, offset: { x: lX, y: lY - 0.75, z: 0.05 }, color: sCol }
    );
  }

  // Hair
  if (hairStyle !== 'none' && hairInfo) {
    const hc = hairInfo.color || '#78350f';
    const topY = hY + (hS / 2); // 2.75
    
    // Check actual hair Style ID
    if (hairStyle.includes('bacon')) {
      parts.push(
        { name: 'HairTop', shape: 'block', size: { x: hS * 1.1, y: 0.4, z: hS * 1.1 }, offset: { x: 0, y: topY + 0.1, z: 0 }, color: hc },
        { name: 'HairBack', shape: 'block', size: { x: hS * 1.1, y: 1.0, z: 0.3 }, offset: { x: 0, y: topY - 0.4, z: -hS/2 - 0.1 }, color: hc },
        { name: 'HairL', shape: 'block', size: { x: 0.3, y: 0.8, z: hS * 1.1 }, offset: { x: -hS/2 - 0.1, y: topY - 0.3, z: 0 }, color: hc },
        { name: 'HairR', shape: 'block', size: { x: 0.3, y: 0.8, z: hS * 1.1 }, offset: { x: hS/2 + 0.1, y: topY - 0.3, z: 0 }, color: hc },
        { name: 'HairFront', shape: 'block', size: { x: hS * 1.1, y: 0.3, z: 0.4 }, offset: { x: 0, y: topY, z: hS/2 + 0.1 }, color: hc }
      );
    } else if (hairStyle.includes('blonde_swept') || hairStyle.includes('classic_blonde_hair')) {
      parts.push(
        { name: 'BlondeTop', shape: 'block', size: { x: hS * 1.15, y: 0.45, z: hS * 1.15 }, offset: { x: 0, y: topY + 0.1, z: 0 }, color: hc },
        { name: 'BlondeSweep', shape: 'wedge', size: { x: hS * 1.1, y: 0.5, z: 0.6 }, offset: { x: 0.1, y: topY, z: hS/2 + 0.1 }, rotation: {x: 0, y: 90, z: 0}, color: hc }
      );
    } else if (hairStyle.includes('fade') || hairStyle.includes('crop')) {
      parts.push(
        { name: 'FadeTop', shape: 'block', size: { x: hS * 1.02, y: 0.35, z: hS * 1.02 }, offset: { x: 0, y: topY, z: 0 }, color: hc },
        { name: 'FadeBase', shape: 'block', size: { x: hS * 1.01, y: 0.3, z: hS * 1.01 }, offset: { x: 0, y: topY - 0.2, z: 0 }, color: shadeColor(hc, 0.7) }
      );
    } else if (hairStyle.includes('curtain')) {
      parts.push(
        { name: 'CurtainTop', shape: 'block', size: { x: hS * 1.1, y: 0.3, z: hS * 1.1 }, offset: { x: 0, y: topY + 0.1, z: 0 }, color: hc },
        { name: 'CurtainL', shape: 'wedge', size: { x: 0.7, y: 0.8, z: 0.6 }, offset: { x: -0.4, y: topY - 0.2, z: hS/2 + 0.1 }, rotation: {x: 0, y: -90, z: 0}, color: hc },
        { name: 'CurtainR', shape: 'wedge', size: { x: 0.7, y: 0.8, z: 0.6 }, offset: { x: 0.4, y: topY - 0.2, z: hS/2 + 0.1 }, rotation: {x: 0, y: 90, z: 0}, color: hc }
      );
    } else if (hairStyle.includes('dreads') || hairStyle.includes('locs')) {
      parts.push({ name: 'LocTop', shape: 'block', size: { x: hS * 1.05, y: 0.3, z: hS * 1.05 }, offset: { x: 0, y: topY + 0.1, z: 0 }, color: hc });
      for(let i=0; i<8; i++) {
         const lx = Math.cos(i) * 0.5;
         const lz = Math.sin(i) * 0.5;
         parts.push({ name: \`Loc\${i}\`, shape: 'cylinder', size: { x: 0.2, y: 1.2, z: 0.2 }, offset: { x: lx, y: topY - 0.3, z: lz }, rotation: {x: lx*30, y: 0, z: lz*30}, color: hc });
      }
    } else if (hairStyle.includes('shag') || hairStyle.includes('curly')) {
      parts.push({ name: 'ShagBase', shape: 'block', size: { x: hS * 1.1, y: 0.4, z: hS * 1.1 }, offset: { x: 0, y: topY + 0.1, z: 0 }, color: hc });
      const positions = [{x: 0.5, y: 0, z: 0.5}, {x: -0.5, y: 0, z: 0.5}, {x: 0.5, y: 0, z: -0.5}, {x: -0.5, y: 0, z: -0.5}, {x: 0, y: 0.2, z: 0}];
      positions.forEach((p,i) => {
        parts.push({ name: \`Curl\${i}\`, shape: 'sphere', size: { x: 0.8, y: 0.8, z: 0.8 }, offset: { x: p.x, y: topY + p.y, z: p.z }, color: hc });
      });
    } else if (hairStyle.includes('silk') || hairStyle.includes('straight')) {
      parts.push(
        { name: 'SilkTop', shape: 'block', size: { x: hS * 1.1, y: 0.3, z: hS * 1.1 }, offset: { x: 0, y: topY + 0.1, z: 0 }, color: hc },
        { name: 'SilkBack', shape: 'block', size: { x: hS * 1.1, y: 1.8, z: 0.4 }, offset: { x: 0, y: topY - 0.6, z: -hS/2 - 0.1 }, color: hc },
        { name: 'SilkL', shape: 'block', size: { x: 0.3, y: 1.6, z: hS }, offset: { x: -hS/2 - 0.1, y: topY - 0.5, z: 0 }, color: hc },
        { name: 'SilkR', shape: 'block', size: { x: 0.3, y: 1.6, z: hS }, offset: { x: hS/2 + 0.1, y: topY - 0.5, z: 0 }, color: hc }
      );
    } else {
      // Fallback
      parts.push(
        { name: 'HairTop', shape: 'block', size: { x: hS * 1.1, y: 0.4, z: hS * 1.1 }, offset: { x: 0, y: topY + 0.1, z: 0 }, color: hc }
      );
    }
  }

  // Accessories
  if (accessory !== 'none' && accessoryIds) {
    const accToRender = accessoryIds.length > 0 ? accessoryIds : [accessory];
    accToRender.forEach((acc) => {
      const accInfo = ACCESSORY_MAP[acc];
      if (!accInfo) return;
      if (acc.includes('fedora') || accInfo.name.toLowerCase().includes('fedora')) {
        parts.push(
          { name: 'FedoraCrown', shape: 'cylinder', size: { x: 1.1, y: 0.6, z: 1.1 }, offset: { x: 0, y: hY + hS/2 + 0.3, z: 0 }, color: accInfo.color || '#18181b' },
          { name: 'FedoraBrim', shape: 'cylinder', size: { x: 1.8, y: 0.1, z: 1.8 }, offset: { x: 0, y: hY + hS/2, z: 0 }, color: shadeColor(accInfo.color || '#18181b', 0.8) }
        );
      } else if (acc.includes('glasses') || acc.includes('shades')) {
        parts.push(
          { name: 'Shades', shape: 'block', size: { x: hS * 1.05, y: 0.25, z: 0.1 }, offset: { x: 0, y: hY + 0.1, z: hS/2 + 0.05 }, color: accInfo.color || '#000000' }
        );
      } else if (acc.includes('wings')) {
        parts.push(
          { name: 'WingL', shape: 'wedge', size: { x: 1.5, y: 2.0, z: 0.2 }, offset: { x: -1.2, y: tY + 0.5, z: -tD/2 - 0.2 }, rotation: {x: 10, y: -20, z: -20}, color: accInfo.color || '#ffffff' },
          { name: 'WingR', shape: 'wedge', size: { x: 1.5, y: 2.0, z: 0.2 }, offset: { x: 1.2, y: tY + 0.5, z: -tD/2 - 0.2 }, rotation: {x: 10, y: 20, z: 20}, color: accInfo.color || '#ffffff' }
        );
      }
    });
  }

  return parts;
}
`;

code = code.replace(regex, newFunction);
fs.writeFileSync('src/utils/avatar3dRenderer.ts', code);
console.log("Renderer patched!");
