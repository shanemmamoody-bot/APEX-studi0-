const fs = require('fs');
let code = fs.readFileSync('src/server/adex/adex3Engine.ts', 'utf-8');

const replacement = `
        const casualSearch = LearnedKnowledge.findConceptFuzzy(lastMessage, db);
        if (casualSearch && casualSearch.sim > 0.85) { 
            let res = \`A **\${casualSearch.concept.keyword}** is \${casualSearch.concept.definition}.\`;
            if (casualSearch.concept.examples) res += \` Examples include: \${casualSearch.concept.examples}\`;
            return res;
        }

        return generateProceduralText(promptContext, 'adex_3');
    }
`;

code = code.replace(/        const casualSearch = LearnedKnowledge\.findConceptFuzzy\(lastMessage, db\);[\s\S]*?return \`I'm here\. We can brainstorm, write some code, or build a new system—what's the plan\?\`;\n    \}/, replacement);

fs.writeFileSync('src/server/adex/adex3Engine.ts', code);
