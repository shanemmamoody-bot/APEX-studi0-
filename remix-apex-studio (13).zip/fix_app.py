with open('src/App.tsx', 'r') as f:
    lines = f.readlines()

lines[4255] = ""

# Let's check 6684
print(lines[6683])

with open('src/App.tsx', 'w') as f:
    f.writelines(lines)
