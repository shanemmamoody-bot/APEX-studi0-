const fs = require('fs');
let code = fs.readFileSync('src/utils/creatureAiEngine.ts', 'utf-8');

code += `\n
// === LUA SCRIPTING BRIDGE ===
import { ApexLuaSession } from './luaEngine';

export function dispatchCreatureAiEvent(creatureId: string, eventName: 'onTame' | 'onAttack' | 'onIdle' | 'onHeal' | 'onPatrol' | 'onFollow') {
  if (typeof window === 'undefined') return;
  const session = ApexLuaSession.currentSession;
  if (!session || !session.L) return;
  
  // Convert standard JS event name (e.g. onAttack) to Lua TitleCase event (e.g. OnAttack)
  const luaEventName = eventName.charAt(0).toUpperCase() + eventName.slice(1);
  
  try {
    const code = \`
      local m = _G.__instanceRegistry["\${creatureId}"]
      if m and m.\${luaEventName} then
        m.\${luaEventName}:Fire()
      end
    \`;
    
    // Attempt dynamic resolution if module requires
    const lauxlib = (window as any).__fengari_lauxlib || require('fengari-web').lauxlib;
    const to_luastring = (window as any).__fengari_to_luastring || require('fengari-web').to_luastring;
    
    if (lauxlib && to_luastring) {
      lauxlib.luaL_dostring(session.L, to_luastring(code));
    }
  } catch (e) {
    console.warn("CreatureAIEngine Script Bridge Error:", e);
  }
}
`;

fs.writeFileSync('src/utils/creatureAiEngine.ts', code);
