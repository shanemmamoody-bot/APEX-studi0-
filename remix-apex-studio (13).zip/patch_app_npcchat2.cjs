const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf-8');

const targetStr = `  useEffect(() => {
    playerHealthRef.current = playerHealth;
  }, [playerHealth]);`;

const replaceStr = `  useEffect(() => {
    playerHealthRef.current = playerHealth;
  }, [playerHealth]);

  useEffect(() => {
    const handleOpenNpcChat = (e: any) => {
      setActiveNpcChat(e.detail);
    };
    window.addEventListener('OPEN_NPC_CHAT', handleOpenNpcChat);
    return () => {
      window.removeEventListener('OPEN_NPC_CHAT', handleOpenNpcChat);
    };
  }, []);`;

code = code.replace(targetStr, replaceStr);
fs.writeFileSync('src/App.tsx', code);
