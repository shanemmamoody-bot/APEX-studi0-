const fs = require('fs');
let code = fs.readFileSync('src/server/adex/modelInstructions.ts', 'utf-8');

const lines = code.split('\n');
for (let i = 0; i < lines.length; i++) {
  if (lines[i].includes('3. **Advanced VFX**')) {
    lines[i] = '3. **Advanced VFX**: \\`Instance.new("Explosion")\\`, \\`Instance.new("ParticleEmitter")\\`, \\`Instance.new("Fire")\\`, \\`Instance.new("Sparkles")\\`. Parenting an Explosion to Workspace with a position triggers an immediate visual blast and shockwave.';
  }
}

fs.writeFileSync('src/server/adex/modelInstructions.ts', lines.join('\n'));
