const fs = require('fs');
const content = fs.readFileSync('src/server/adex/adex3Engine.ts', 'utf8');
const lines = content.split('\n');
let depth = 0;
for(let i = 796; i < 1015; i++) {
    const line = lines[i];
    depth += (line.match(/\{/g) || []).length;
    depth -= (line.match(/\}/g) || []).length;
    if (i === 898) console.log("Line 899 depth:", depth);
    if (i === 1011) console.log("Line 1012 depth:", depth);
}
