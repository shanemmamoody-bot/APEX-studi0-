const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf-8');

let lines = code.split('\n');
const idx = lines.findIndex(l => l.includes('NpcChatOverlay'));
if (idx !== -1) {
  // Remove the dangling )} on the next line if it exists
  if (lines[idx+1].trim() === ')}') {
    lines.splice(idx+1, 1);
  }
}
fs.writeFileSync('src/App.tsx', lines.join('\n'));
