with open("src/App.tsx", "r") as f:
    code = f.read()

bad_block = """  const currentUserRef = useRef(currentUser);
  useEffect(() => { currentUserRef.current = currentUser; }, [currentUser]);"""

good_block = """  const [currentUser, setCurrentUser] = useState<UserProfile | null>(() => {
    try {
      const saved = localStorage.getItem('apex_current_user');
      if (saved) return JSON.parse(saved);
    } catch (e) {}
    return null;
  });
  const currentUserRef = useRef(currentUser);
  useEffect(() => { currentUserRef.current = currentUser; }, [currentUser]);"""

code = code.replace(bad_block, good_block)

with open("src/App.tsx", "w") as f:
    f.write(code)

print("Fixed state order in App.tsx")
