import re

with open("src/components/CreatorDashboard.tsx", "r") as f:
    cd_code = f.read()

# Add onManageCollaborators to destructured props
cd_code = cd_code.replace(
    "  onReturnToLobby,",
    "  onManageCollaborators = () => {},\n  onReturnToLobby,"
)

with open("src/components/CreatorDashboard.tsx", "w") as f:
    f.write(cd_code)
print("Fixed CreatorDashboard.tsx")

with open("src/components/Viewport.tsx", "r") as f:
    vp_code = f.read()

vp_code = vp_code.replace("if (part.type === 'model') return;", "if ((part.type as string) === 'model') return;")

with open("src/components/Viewport.tsx", "w") as f:
    f.write(vp_code)
print("Fixed Viewport.tsx")
