with open("src/App.tsx", "r") as f:
    code = f.read()

# 1. Map game.collaborators to proper structure in handlePlayPublishedGame and handleEditPublishedGame
code = code.replace(
    "collaborators: game.collaborators,",
    "collaborators: (game.collaborators || []).map((c: any) => typeof c === 'string' ? { username: c, permissions: ['edit'] } : c),"
)

# 2. Move currentUser state definition above studio WebSocket effect
# Let's findcurrentUser definition
user_state_marker = 'const [currentUser, setCurrentUser] = useState<UserProfile | null>'
idx_user = code.find(user_state_marker)

if idx_user != -1:
    # Find the end of user state block (e.g. up to next const/useState or function)
    # Actually, currentUser initialization block goes from line 239 to ~285
    # Let's extract the currentUser state block
    pass

with open("src/App.tsx", "w") as f:
    f.write(code)

print("Updated App.tsx collaborators mapping")
