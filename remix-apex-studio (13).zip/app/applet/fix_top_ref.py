with open("src/App.tsx", "r") as f:
    code = f.read()

# Replace the ref declaration near the bottom with a top-level ref declaration
old_ref_decl = "  const currentUserRef = useRef(currentUser);"
code = code.replace(old_ref_decl, "")

# Insert top-level ref right after export default function App() {
app_sig = "export default function App() {"
top_ref_insertion = app_sig + "\n  const currentUserRef = useRef<UserProfile | null>(null);"
code = code.replace(app_sig, top_ref_insertion)

with open("src/App.tsx", "w") as f:
    f.write(code)

print("Placed currentUserRef at the top of App()")
