with open("src/App.tsx", "r") as f:
    lines = f.readlines()

new_lines = []
for i, line in enumerate(lines):
    if i < 250:
        line = line.replace("currentUser?.", "currentUserRef.current?.")
        line = line.replace("currentUser.", "currentUserRef.current.")
    new_lines.append(line)

with open("src/App.tsx", "w") as f:
    f.writelines(new_lines)

print("Replaced currentUser with currentUserRef in top lines of App.tsx")
