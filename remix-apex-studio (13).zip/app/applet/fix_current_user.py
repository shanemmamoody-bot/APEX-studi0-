with open("src/App.tsx", "r") as f:
    code = f.read()

# Add currentUserRef definition right after component start
component_start = "export const App: React.FC = () => {"
if component_start in code:
    replacement = component_start + "\n  const [currentUser, setCurrentUser] = useState<UserProfile | null>(() => {\n    try {\n      const saved = localStorage.getItem('apex_current_user');\n      if (saved) return JSON.parse(saved);\n    } catch (e) {}\n    return null;\n  });\n  const currentUserRef = useRef(currentUser);\n  useEffect(() => { currentUserRef.current = currentUser; }, [currentUser]);"
    # Wait, let's remove the original currentUser declaration further down so we don't duplicate it
    code = code.replace(component_start, replacement)
    
    # Now remove the old currentUser useState block
    old_user_block_start = '  const [currentUser, setCurrentUser] = useState<UserProfile | null>(() => {'
    # Let's find the second occurrence (or replace all references of currentUser?.username to currentUserRef.current?.username in lines 1-230)
    
with open("src/App.tsx", "w") as f:
    f.write(code)

print("Modified App.tsx for currentUserRef")
