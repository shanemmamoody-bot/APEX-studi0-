with open("server.ts", "r") as f:
    code = f.read()

start = code.find("function getFallbackAssistantReply")
end = code.find("function getFallbackAICode")

clean_fn = """function getFallbackAssistantReply(userText: string): string {
  const lower = userText.toLowerCase();
  const isNonLuaRequested = /\\b(javascript|js|typescript|ts|python|c#|c\\+\\+|java|rust|go)\\b/i.test(userText);
  const prefix = isNonLuaRequested
    ? "💬 [Apex Assistant]: Apex Studio only supports Lua, so I converted your request into valid Lua:\\n"
    : "💬 [Apex Assistant]: Here is the working Lua script for your request:\\n\\n```lua";

  if (lower.includes("bounce") || lower.includes("jump") || lower.includes("pad") || lower.includes("speed") || lower.includes("boost")) {
    return prefix + "-- Super Bounce Pad / Velocity Boost (Lua)\\nlocal pad = workspace:find(\\"BouncePad\\")\\nlocal player = Players.LocalPlayer\\nif pad and player then\\n    local dx = pad.Position.x - player.Position.x\\n    local dy = pad.Position.y - player.Position.y\\n    local dz = pad.Position.z - player.Position.z\\n    local dist = math.sqrt(dx*dx + dy*dy + dz*dz)\\n    if dist < 3.5 then\\n        player.VelocityY = 25\\n        player.WalkSpeed = 30\\n        playSound(\\"Bounce\\")\\n        print(\\"Super Bounce activated!\\")\\n    end\\nend\\n```";
  }

  if (lower.includes("coin") || lower.includes("score") || lower.includes("collectible") || lower.includes("point")) {
    return prefix + "-- Collectible Coin System (Lua)\\nlocal coin = script.Parent\\nlocal function onTouch(hit)\\n    local character = hit.Parent\\n    local player = Players:GetPlayerFromCharacter(character)\\n    if player then\\n        player.Score = (player.Score || 0) + 10\\n        print(player.Name .. \\" collected a coin!\\")\\n        coin:Destroy()\\n    end\\nend\\ncoin.Touched:Connect(onTouch)\\n```";
  }

  if (lower.includes("spawn") || lower.includes("part") || lower.includes("build") || lower.includes("3d") || lower.includes("model") || lower.includes("add")) {
    return "💬 [Apex Assistant]: Building in Apex Studio is simple! Open Studio, click \\'Add Part\\' or drag models from the Toolbox onto the canvas. You can move, scale, rotate, and change materials or colors easily.";
  }
  if (lower.includes("publish") || lower.includes("community") || lower.includes("share") || lower.includes("game") || lower.includes("obby")) {
    return "💬 [Apex Assistant]: Ready to share your game? Click the \\'Publish\\' button in Apex Studio, give your project a title and description, and it will immediately show up on the Home page and Community Hub for other players to play!";
  }
  if (lower.includes("abux") || lower.includes("a-bucks") || lower.includes("money") || lower.includes("currency")) {
    return "💬 [Apex Assistant]: A-Bucks are Apex Studio\\'s virtual currency! You earn A-Bucks when players play your published games, or you can get more in the A-Bucks Store in the top bar.";
  }
  return "💬 [Apex Assistant]: Thanks for your message! I am your 24/7 Lua Scripting Assistant. Let me know if you need any custom Lua scripts, bug fixes, or 3D world mechanics generated!";
}

"""

if start != -1 and end != -1:
    new_code = code[:start] + clean_fn + code[end:]
    with open("server.ts", "w") as f:
        f.write(new_code)
    print("Successfully updated server.ts via update_server.py!")
else:
    print("Markers not found:", start, end)
