with open("src/App.tsx", "r") as f:
    code = f.read()

# Let's remove any duplicate currentUser declarations if any, and ensure currentUser & currentUserRef are at the top of App()
app_sig = "export default function App() {"
replacement = """export default function App() {
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(() => {
    try {
      const saved = localStorage.getItem('apex_current_user');
      if (saved) return JSON.parse(saved);
    } catch (e) {}
    return null;
  });
  const currentUserRef = useRef(currentUser);
  useEffect(() => { currentUserRef.current = currentUser; }, [currentUser]);"""

if app_sig in code:
    code = code.replace(app_sig, replacement)

# Also remove the later duplicate currentUser useState definition if it exists
old_def = """  const [currentUser, setCurrentUser] = useState<UserProfile | null>(() => {
    try {
      const saved = localStorage.getItem('apex_current_user');
      if (saved) return JSON.parse(saved);
    } catch (e) {}
    return null;
  });"""
# Replace second occurrence or clean up
code = code.replace(old_def, "", 1)

with open("src/App.tsx", "w") as f:
    f.write(code)

print("Reordered App.tsx state declarations")
