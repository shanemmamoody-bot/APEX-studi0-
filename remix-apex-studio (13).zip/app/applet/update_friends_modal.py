with open("src/components/FriendsAndMessagingModal.tsx", "r") as f:
    code = f.read()

# Add friendReqError state
if "friendReqError" not in code:
    code = code.replace(
        "  const [friendReqSuccess, setFriendReqSuccess] = useState('');",
        "  const [friendReqSuccess, setFriendReqSuccess] = useState('');\n  const [friendReqError, setFriendReqError] = useState('');"
    )

with open("src/components/FriendsAndMessagingModal.tsx", "w") as f:
    f.write(code)

print("Added friendReqError state")
