with open("src/App.tsx", "r") as f:
    code = f.read()

# Remove the top declaration we added earlier
top_added = """  const [currentUser, setCurrentUser] = useState<UserProfile | null>(() => {
    try {
      const saved = localStorage.getItem('apex_current_user');
      if (saved) return JSON.parse(saved);
    } catch (e) {}
    return null;
  });
  const currentUserRef = useRef(currentUser);
  useEffect(() => { currentUserRef.current = currentUser; }, [currentUser]);"""

code = code.replace(top_added, "")

# Ensure currentUserRef is declared right after the main currentUser useState block
target_block = """  const [currentUser, setCurrentUser] = useState<UserProfile | null>(() => {
    const storedToken = localStorage.getItem('apex_session_token');
    try {
      const saved = localStorage.getItem('apex_current_user_v2');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed && parsed.username) {
          if (storedToken) parsed.sessionToken = storedToken;
          return parsed;
        }
      }
    } catch (e) {
      console.error('Error loading saved user profile:', e);
    }
    return null;
  });"""

ref_addition = target_block + "\n  const currentUserRef = useRef(currentUser);\n  useEffect(() => { currentUserRef.current = currentUser; }, [currentUser]);"

code = code.replace(target_block, ref_addition)

with open("src/App.tsx", "w") as f:
    f.write(code)

print("Placed currentUserRef correctly below currentUser state")
