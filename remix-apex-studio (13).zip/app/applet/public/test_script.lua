local dropper = script.Parent

local block = Instance.new("Part", workspace)

block.Name = "Drop"
block.Size = Vector3.new(2, 2, 2)
if dropper and dropper.Position then
  block.Position = dropper.Position + Vector3.new(0, -3, 0)
else
  block.Position = Vector3.new(0, 10, 0)
end
block.Anchored = true
block.CanCollide = true

local health = Instance.new("NumberValue", block)
health.Name = "Health"
health.Value = 1

for i = 1, 40 do
    block.Position = block.Position + Vector3.new(0.5, 0, 0)
    task.wait(0.05)
end

block:Destroy()
