const fs = require('fs');

const code = `export type BodyStyleId = 'blocky';
export type ShirtId = string;
export type PantsId = string;
export type ShoesId = string;
export type HairStyleId = string;
export type FaceId = string;
export type AccessoryId = string;

export interface AvatarCatalogItem {
  id: string;
  name: string;
  price: number;
  description: string;
}

export interface BodyStyleOption extends AvatarCatalogItem { id: BodyStyleId; }
export interface ShirtOption extends AvatarCatalogItem { torso: string; arms: string; accent?: string; modeledDetails?: { hasLayeredJacket?: boolean; hasCollar?: boolean; hasPockets?: boolean; hasZipper?: boolean }; }
export interface PantsOption extends AvatarCatalogItem { legs: string; accent?: string; }
export interface ShoesOption extends AvatarCatalogItem { color: string; sole: string; }
export interface HairOption extends AvatarCatalogItem { color: string; geometryType: string; }
export interface FaceOption extends AvatarCatalogItem { decalUrl: string; }
export interface AccessoryOption extends AvatarCatalogItem { color?: string; }

export const BODY_STYLE_OPTIONS: BodyStyleOption[] = [
  { id: 'blocky', name: 'Classic Blocky Avatar', price: 0, description: 'The timeless blocky aesthetic. Pure angular geometry.' }
];

export const SHIRT_OPTIONS: ShirtOption[] = [
  { id: 'shirt_01', name: 'Classic Red T-Shirt', price: 0, description: 'A standard red t-shirt.', torso: '#dc2626', arms: '#b91c1c' },
  { id: 'modern_apex_tech_streetwear_jacket', name: 'Apex Tech Streetwear Jacket', price: 100, description: 'A sleek, black and red multi-layered tactical jacket.', torso: '#0f172a', arms: '#18181b', accent: '#dc2626', modeledDetails: { hasLayeredJacket: true } },
  { id: 'golden_royale_tailored_blazer', name: 'Golden Royale Blazer', price: 250, description: 'An elegant golden blazer over a white dress shirt.', torso: '#facc15', arms: '#eab308', accent: '#ffffff', modeledDetails: { hasLayeredJacket: true } },
  { id: 'casual_denim_jacket', name: 'Casual Denim Jacket', price: 50, description: 'A classic blue denim jacket over a white tee.', torso: '#2563eb', arms: '#1d4ed8', accent: '#ffffff', modeledDetails: { hasLayeredJacket: true } }
];

export const PANTS_OPTIONS: PantsOption[] = [
  { id: 'pants_01', name: 'Classic Blue Jeans', price: 0, description: 'Standard blue jeans.', legs: '#1e3a8a' },
  { id: 'modern_apex_tech_streetwear_pants', name: 'Apex Tech Cargo Pants', price: 100, description: 'Tactical black cargo pants.', legs: '#09090b', accent: '#dc2626' },
  { id: 'golden_royale_slacks', name: 'Golden Royale Slacks', price: 150, description: 'Tailored black dress slacks.', legs: '#18181b', accent: '#facc15' },
  { id: 'casual_sweatpants', name: 'Casual Sweatpants', price: 20, description: 'Comfortable gray sweatpants.', legs: '#64748b' }
];

export const SHOES_OPTIONS: ShoesOption[] = [
  { id: 'default_shoes', name: 'Standard Sneakers', price: 0, description: 'Classic black sneakers.', color: '#18181b', sole: '#27272a' },
  { id: 'high_top_kicks', name: 'High-Top Kicks', price: 50, description: 'Stylish red and white high-tops.', color: '#dc2626', sole: '#ffffff' },
  { id: 'formal_dress_shoes', name: 'Formal Dress Shoes', price: 80, description: 'Polished black dress shoes.', color: '#09090b', sole: '#000000' }
];

export const HAIR_OPTIONS: HairOption[] = [
  { id: 'bacon_hair', name: 'Classic Layered Bacon Hair', price: 0, description: 'The iconic layered brown hairstyle.', color: '#78350f', geometryType: 'spiky_blocks' },
  { id: 'classic_blonde_hair', name: 'Classic Blonde Swept Hair', price: 10, description: 'Smooth, bright yellow-blonde hair.', color: '#facc15', geometryType: 'spiky_blocks' },
  { id: 'hair_new_01_shadow_fade', name: 'Textured Burst Fade', price: 50, description: 'Clean fade with texture on top.', color: '#0f172a', geometryType: 'fade_crop' },
  { id: 'hair_new_03_curtain_bangs', name: 'Luxury Wavy Curtain Bangs', price: 60, description: 'Modern curtain bangs.', color: '#522e1b', geometryType: 'layered_strands' },
  { id: 'hair_new_04_flowing_dreads', name: 'Flowing Dreads', price: 80, description: 'Freeform dreadlocks.', color: '#09090b', geometryType: 'dreadlocks' },
  { id: 'hair_new_11_curly_shag', name: 'Voluminous Curly Shag', price: 75, description: 'A big, curly shag hairstyle.', color: '#3b2219', geometryType: 'curly_bun' },
  { id: 'hair_new_13_silk_straight', name: 'Platinum Silk Straight', price: 120, description: 'Long, perfectly straight platinum hair.', color: '#f8fafc', geometryType: 'layered_strands' }
];

export const ACCESSORY_OPTIONS: AccessoryOption[] = [
  { id: 'none', name: 'None', price: 0, description: 'No accessory' },
  { id: 'black_fedora', name: 'Classic Black Fedora', price: 100, description: 'A sharp black fedora hat.', color: '#18181b' },
  { id: 'sunglasses', name: 'Aviator Sunglasses', price: 80, description: 'Dark shades.', color: '#000000' },
  { id: 'angel_wings', name: 'Radiant Angel Wings', price: 500, description: 'Huge white wings.', color: '#ffffff' }
];

export const FACE_OPTIONS: FaceOption[] = [
  { id: 'face_classic_smile', name: 'Classic Smile', price: 0, description: 'The iconic smile.', decalUrl: '' }
];

export const SHIRT_MAP: Record<string, ShirtOption> = {};
SHIRT_OPTIONS.forEach(s => { SHIRT_MAP[s.id] = s; });

export const PANTS_MAP: Record<string, PantsOption> = {};
PANTS_OPTIONS.forEach(p => { PANTS_MAP[p.id] = p; });

export const SHOES_MAP: Record<string, ShoesOption> = {};
SHOES_OPTIONS.forEach(s => { SHOES_MAP[s.id] = s; });

export const HAIR_MAP: Record<string, HairOption> = {};
HAIR_OPTIONS.forEach(h => { HAIR_MAP[h.id] = h; });

export const ACCESSORY_MAP: Record<string, AccessoryOption> = {};
ACCESSORY_OPTIONS.forEach(a => { ACCESSORY_MAP[a.id] = a; });

export const FACE_MAP: Record<string, FaceOption> = {};
FACE_OPTIONS.forEach(f => { FACE_MAP[f.id] = f; });

export const BODY_STYLE_MAP: Record<string, BodyStyleOption> = {};
BODY_STYLE_OPTIONS.forEach(b => { BODY_STYLE_MAP[b.id] = b; });
`;

fs.writeFileSync('src/data/avatarCatalog.ts', code);
console.log("Catalog rewritten!");
