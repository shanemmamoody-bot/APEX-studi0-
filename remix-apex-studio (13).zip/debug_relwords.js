const rel = 'is';
const cleanQuery = 'what is my game speed';
const s = 'my game speed';
const relWords = rel.replace(/^(is|was|are|the|a|an|of)\s+/g, '').replace(/\s+(of|in|to|for)$/g, '').trim().split(' ');
let hasRelWord = false;
for (const w of relWords) {
    if (w.length > 2 && cleanQuery.includes(w)) {
        hasRelWord = true;
        break;
    }
}
console.log("hasRelWord:", hasRelWord);
if (cleanQuery.includes(s) && hasRelWord) {
    console.log("Matched second condition!");
}
