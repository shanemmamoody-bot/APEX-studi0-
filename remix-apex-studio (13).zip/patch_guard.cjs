const fs = require('fs');
let code = fs.readFileSync('src/components/PropertiesPanel.tsx', 'utf-8');

code = code.replace(
  '<option value="Wander">Wander (Random Path)</option>',
  '<option value="Wander">Wander (Random Path)</option>\n                        <option value="Guard">Guard Area</option>'
);

fs.writeFileSync('src/components/PropertiesPanel.tsx', code);
