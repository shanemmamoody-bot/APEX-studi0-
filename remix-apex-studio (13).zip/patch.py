import sys
with open("src/server/adex/nlpBrain.ts", "r") as f:
    text = f.read()

replacement = """        // --- 3. Intent Detection ---
        if (/^(hello|hi|hey|how are you|greetings|sup)\\b/i.test(lower) && lower.split(' ').length <= 5) {
            intent = 'greeting';
            primarySubject = 'greeting';
        } 
        else if (lower.match(/^(tell me a joke|make me laugh|joke)/i)) {
            intent = 'joke';
            primarySubject = 'joke';
        }
        else if (lower.match(/^(i think|in my opinion|i believe|it seems like)\\b/i)) {
            intent = 'opinion';
            primarySubject = lower;
        }
        else if (lower.match(/^(what|which|how|why|who|when|where|can you explain|do you know|is there|calculate|solve|spell)\\b/i) || lower.endsWith('?')) {
            if (/^(can you|how do i)\\s+(make|build|create|write|generate|add)\\b/i.test(lower)) {
                intent = 'build';
            } else {
                intent = 'question';
                primarySubject = lower;
            }
        }
        else if (lower.match(/^(make|build|create|write|generate|add|do|run|stop|start|open|close|execute)\\b/i)) {
            intent = 'build';
        }
        else if (lower.includes('what is') || lower.includes('how to') || lower.includes('explain') || lower.includes('what does')) {"""

import re
text = text.replace("""        // --- 3. Intent Detection ---
        if (/^(hello|hi|hey|how are you|greetings|sup)\\b/i.test(lower) && lower.split(' ').length <= 5) {
            intent = 'greeting';
            primarySubject = 'greeting';
        } 
        else if (lower.includes('what is') || lower.includes('how to') || lower.includes('explain') || lower.includes('what does')) {""", replacement + " {")

with open("src/server/adex/nlpBrain.ts", "w") as f:
    f.write(text)
