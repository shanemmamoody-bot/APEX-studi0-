const s = 'my game speed';
const cleanQuery = 'what is my game speed';
const match = cleanQuery.match(new RegExp(`^(what|who|where)\\s+(is|are)\\s+(the\\s+)?${s}`, 'i'));
console.log("Match:", match);
