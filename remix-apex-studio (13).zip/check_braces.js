const fs = require('fs');
const content = fs.readFileSync('server.ts', 'utf8');
let depth = 0;
for(let i=0; i<content.length; i++) {
  if (content[i] === '{') depth++;
  if (content[i] === '}') {
    depth--;
    if (depth < 0) {
      console.log("Unbalanced at line: ", content.slice(0, i).split('\n').length);
      break;
    }
  }
}
console.log("Final depth: ", depth);
