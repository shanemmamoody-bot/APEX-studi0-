const fs = require('fs');
let code = fs.readFileSync('src/components/PropertiesPanel.tsx', 'utf-8');

code = code.replace(
  "(selectedPart.aiMode === 'Patrol' || selectedPart.aiMode === 'Wander')",
  "(selectedPart.aiMode === 'Patrol' || selectedPart.aiMode === 'Wander' || selectedPart.aiMode === 'Guard')"
);

fs.writeFileSync('src/components/PropertiesPanel.tsx', code);
