const fs = require('fs');
const filePath = 'src/server/adex/adex3Engine.ts';
let code = fs.readFileSync(filePath, 'utf-8');

const replacement = `    static getDb() {
        const dbPath = path.join(process.cwd(), 'adex_db.json');
        if (fs.existsSync(dbPath)) {
            try {
                return JSON.parse(fs.readFileSync(dbPath, 'utf-8'));
            } catch (e) {
                console.warn("Failed to parse adex_db.json, returning default:", e.message);
            }
        }
        return { 
            knowledgeBase: { concepts: [], codingPatterns: [], intentMap: {}, rules: [] },
            experienceLog: { unresolvedTerms: {}, successfulPatterns: [], failedPatterns: [], recentContext: [] },
            teacherState: { proficiency: {}, logs: [], activeBots: 0 }
        };
    }`;

code = code.replace(/static getDb\(\) \{[\s\S]*?return \{\s*knowledgeBase:[\s\S]*?teacherState:[\s\S]*?};\s*\}/, replacement);

fs.writeFileSync(filePath, code);
