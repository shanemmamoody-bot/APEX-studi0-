with open('src/App.tsx', 'r') as f:
    text = f.read()
print("Opening braces: ", text.count("{"))
print("Closing braces: ", text.count("}"))
print("Opening parens: ", text.count("("))
print("Closing parens: ", text.count(")"))
