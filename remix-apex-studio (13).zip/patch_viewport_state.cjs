const fs = require('fs');
let code = fs.readFileSync('src/components/Viewport.tsx', 'utf-8');

const targetStr = `  useEffect(() => {
    nearbyNPCRef.current = nearbyNPC;
  }, [nearbyNPC]);`;

const replaceStr = `  useEffect(() => {
    nearbyNPCRef.current = nearbyNPC;
  }, [nearbyNPC]);

  useEffect(() => {
    const handleUpdateNpcState = (e: any) => {
      if (!isTesting) return; // Only process during gameplay
      const { id, mode } = e.detail;
      const targetNPC = workspace.find(p => p.id === id);
      if (targetNPC && onUpdatePart) {
        let aiDamage = targetNPC.aiDamage || 0;
        let aiHeal = targetNPC.aiHeal || 0;
        
        if (mode === 'Attack') aiDamage = Math.max(15, aiDamage);
        if (mode === 'Heal') aiHeal = Math.max(15, aiHeal);
        if (mode === 'Follow' || mode === 'Idle' || mode === 'Wander') {
           // Clear hostile intent if explicitly calmed
           aiDamage = 0;
        }

        onUpdatePart({ ...targetNPC, aiMode: mode, aiDamage, aiHeal });
      }
    };
    window.addEventListener('UPDATE_NPC_STATE', handleUpdateNpcState);
    return () => window.removeEventListener('UPDATE_NPC_STATE', handleUpdateNpcState);
  }, [isTesting, workspace, onUpdatePart]);`;

code = code.replace(targetStr, replaceStr);
fs.writeFileSync('src/components/Viewport.tsx', code);
