const fs = require('fs');
let code = fs.readFileSync('src/components/Viewport.tsx', 'utf-8');

const originalClick = `                onClick={(e) => {
                  e.stopPropagation();
                  // Dispatch custom event to App.tsx to open chat
                  window.dispatchEvent(new CustomEvent('OPEN_NPC_CHAT', { detail: nearbyNPC }));
                }}`;

const newClick = `                onClick={(e) => {
                  e.stopPropagation();
                  const action = nearbyNPC.aiOnClick;
                  if (action === 'Tame') {
                    if (onUpdatePart) onUpdatePart(nearbyNPC.id, { aiMode: 'Follow', aiDamage: 0, aiHeal: 0, aiWalkSpeed: 20 });
                    dispatchCreatureAiEvent(nearbyNPC.id, 'onTame');
                  } else if (action === 'Attack') {
                    if (onUpdatePart) onUpdatePart(nearbyNPC.id, { aiMode: 'Follow', aiDamage: 20 });
                    dispatchCreatureAiEvent(nearbyNPC.id, 'onAttack');
                  } else if (action === 'Heal') {
                    if (onUpdatePart) onUpdatePart(nearbyNPC.id, { aiMode: 'Follow', aiHeal: 20 });
                    dispatchCreatureAiEvent(nearbyNPC.id, 'onHeal');
                  } else if (action === 'Follow') {
                    if (onUpdatePart) onUpdatePart(nearbyNPC.id, { aiMode: 'Follow' });
                    dispatchCreatureAiEvent(nearbyNPC.id, 'onFollow');
                  } else {
                    window.dispatchEvent(new CustomEvent('OPEN_NPC_CHAT', { detail: nearbyNPC }));
                  }
                }}`;

code = code.replace(originalClick, newClick);
fs.writeFileSync('src/components/Viewport.tsx', code);
