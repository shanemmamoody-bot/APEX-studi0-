const { readFileSync } = require('fs');
let template = readFileSync('src/utils/templates.ts', 'utf-8');
console.log(template.indexOf("const zombieWaveScript: GameScript = {"));
