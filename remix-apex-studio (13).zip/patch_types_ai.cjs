const fs = require('fs');
let code = fs.readFileSync('src/types.ts', 'utf-8');

code = code.replace(
  "  aiOwner?: string;",
  `  aiOwner?: string;
  
  // --- ADVANCED SENSORY & REACTION SYSTEMS ---
  aiVisionRange?: number;
  aiHearingRange?: number;
  aiFieldOfView?: number;
  aiReactionToThreat?: 'Ignore' | 'Flee' | 'Attack' | 'Cower' | 'CallHelp';
  aiReactionToDamage?: 'Flee' | 'Enrage' | 'CallHelp' | 'Panic' | 'Retaliate';
  aiCourage?: number;
  aiCuriosity?: number;
  aiPackMentality?: boolean;
  aiPackRadius?: number;
  aiCombatStyle?: 'Melee' | 'HitAndRun' | 'Strafe' | 'Charge';
  aiSleepAtNight?: boolean;
  aiIsNocturnal?: boolean;
  aiDropsLootId?: string;
  aiJumpPower?: number;
  aiCanClimb?: boolean;`
);

fs.writeFileSync('src/types.ts', code);
