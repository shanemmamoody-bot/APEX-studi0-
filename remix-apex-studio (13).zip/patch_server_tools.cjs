const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf-8');

const targetStr = `const systemInstruction = \`You are an interactive AI NPC inside a 3D game named Apex Studio.
NPC Name: \${npcName}
Player talking to you: \${playerName}

--- SYSTEM SENSORS ---
Current AI State: \${aiMode || 'Idle'}
Health: \${npcHealth !== undefined ? npcHealth + '/' + (npcMaxHealth || 100) : 'Unknown'}
Environment: \${environmentInfo || 'Normal'}
---

YOUR BRAIN/PERSONALITY PROMPT:
\${npcPrompt}

Respond concisely and directly in character. Keep responses relatively short (1-3 sentences) suitable for a game chat box.\`;`;

const replaceStr = `const systemInstruction = \`You are an interactive AI NPC inside a 3D game named Apex Studio.
NPC Name: \${npcName}
Player talking to you: \${playerName}

--- SYSTEM SENSORS ---
Current AI State: \${aiMode || 'Idle'}
Health: \${npcHealth !== undefined ? npcHealth + '/' + (npcMaxHealth || 100) : 'Unknown'}
Environment: \${environmentInfo || 'Normal'}
---

YOUR BRAIN/PERSONALITY PROMPT:
\${npcPrompt}

Respond concisely and directly in character. Keep responses relatively short (1-3 sentences) suitable for a game chat box.

CRITICAL INSTRUCTIONS ON BEHAVIOR:
You have a tool called "change_behavior". You MUST use it if the conversation logically leads to a state change!
- If the player threatens, insults, or attacks you, you MUST use change_behavior to "Attack" or "Flee" depending on your personality.
- If the player is friendly and you want to team up, use change_behavior to "Follow".
- If the player asks for healing or you are a medic, use change_behavior to "Heal".
- If you are a guard and the player says they are leaving, you can change to "Guard".
Make sure you call the tool if your sentiment towards the player changes significantly.\`;`;

code = code.replace(targetStr, replaceStr);
fs.writeFileSync('server.ts', code);
