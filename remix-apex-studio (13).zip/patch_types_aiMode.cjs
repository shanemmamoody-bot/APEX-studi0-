const fs = require('fs');
let code = fs.readFileSync('src/types.ts', 'utf-8');

code = code.replace(
  "aiMode?: 'Idle' | 'Follow' | 'Patrol';",
  "aiMode?: 'Idle' | 'Follow' | 'Patrol' | 'Wander' | 'Flee' | 'Guard';"
);

fs.writeFileSync('src/types.ts', code);
