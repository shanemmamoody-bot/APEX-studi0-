const fs = require('fs');
const games = [
  {
    "id": "game-apex-mega-obby",
    "projectId": "proj-apex-mega",
    "name": "Apex Mega Obby",
    "title": "Apex Mega Obby",
    "description": "A gigantic obstacle course created by Apex Studio. Jump and dash your way to victory!",
    "author": "Apex Studio",
    "creator": "Apex Studio",
    "thumbnail": "https://images.unsplash.com/photo-1620188981442-f5db666fb4f5?w=500&auto=format&fit=crop&q=60",
    "plays": 0,
    "likes": 0,
    "favorites": 0,
    "activePlayers": 0,
    "parts": [
      {
        "id": "spawn",
        "name": "SpawnLocation",
        "type": "part",
        "shape": "block",
        "color": "#ffffff",
        "material": "plastic",
        "size": { "x": 10, "y": 1, "z": 10 },
        "position": { "x": 0, "y": 0, "z": 0 },
        "rotation": { "x": 0, "y": 0, "z": 0 },
        "transparency": 0,
        "canCollide": true,
        "anchored": true
      },
      {
        "id": "p1",
        "name": "ObbyPart1",
        "type": "part",
        "shape": "block",
        "color": "#ff0000",
        "material": "plastic",
        "size": { "x": 4, "y": 1, "z": 4 },
        "position": { "x": 0, "y": 2, "z": -10 },
        "rotation": { "x": 0, "y": 0, "z": 0 },
        "transparency": 0,
        "canCollide": true,
        "anchored": true
      },
      {
        "id": "p2",
        "name": "ObbyPart2",
        "type": "part",
        "shape": "block",
        "color": "#00ff00",
        "material": "plastic",
        "size": { "x": 4, "y": 1, "z": 4 },
        "position": { "x": 0, "y": 4, "z": -20 },
        "rotation": { "x": 0, "y": 0, "z": 0 },
        "transparency": 0,
        "canCollide": true,
        "anchored": true
      }
    ],
    "scripts": [],
    "lighting": {
      "ambient": "#404040",
      "skyColor": "#87ceeb",
      "brightness": 1,
      "timeOfDay": "14:00",
      "graphicsTier": "tier3"
    },
    "createdAt": new Date().toISOString(),
    "publishedAt": new Date().toISOString()
  },
  {
    "id": "game-king-neon-obby",
    "projectId": "proj-king-neon",
    "name": "Ultimate Neon Obby",
    "title": "Ultimate Neon Obby",
    "description": "An intense neon-themed obby. Only the best can survive!",
    "author": "king",
    "creator": "king",
    "thumbnail": "https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=500&auto=format&fit=crop&q=60",
    "plays": 0,
    "likes": 0,
    "favorites": 0,
    "activePlayers": 0,
    "parts": [
      {
        "id": "spawn2",
        "name": "SpawnLocation",
        "type": "part",
        "shape": "block",
        "color": "#000000",
        "material": "neon",
        "size": { "x": 12, "y": 1, "z": 12 },
        "position": { "x": 0, "y": 0, "z": 0 },
        "rotation": { "x": 0, "y": 0, "z": 0 },
        "transparency": 0,
        "canCollide": true,
        "anchored": true
      },
      {
        "id": "p3",
        "name": "NeonPart1",
        "type": "part",
        "shape": "block",
        "color": "#ff00ff",
        "material": "neon",
        "size": { "x": 5, "y": 1, "z": 5 },
        "position": { "x": 0, "y": 5, "z": -15 },
        "rotation": { "x": 0, "y": 0, "z": 0 },
        "transparency": 0,
        "canCollide": true,
        "anchored": true
      }
    ],
    "scripts": [],
    "lighting": {
      "ambient": "#202020",
      "skyColor": "#000000",
      "brightness": 0.5,
      "timeOfDay": "00:00",
      "graphicsTier": "tier3"
    },
    "createdAt": new Date().toISOString(),
    "publishedAt": new Date().toISOString()
  }
];

fs.writeFileSync('published_games.json', JSON.stringify(games, null, 2), 'utf8');

// also add to users_db
const users = JSON.parse(fs.readFileSync('users_db.json', 'utf8'));
if (!users["apex_studio"]) {
  users["apex_studio"] = { publishedGames: [] };
}
users["apex_studio"].publishedGames = [games[0]];

if (!users["king"]) {
  users["king"] = { publishedGames: [] };
}
users["king"].publishedGames = [games[1]];

fs.writeFileSync('users_db.json', JSON.stringify(users, null, 2), 'utf8');
