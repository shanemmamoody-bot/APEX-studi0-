import re
with open('src/App.tsx', 'r') as f:
    text = f.read()

# Remove string literals (", ', `)
text = re.sub(r'(?<!\\)".*?(?<!\\)"', '""', text, flags=re.DOTALL)
text = re.sub(r"(?<!\\)'.*?(?<!\\)'", "''", text, flags=re.DOTALL)
text = re.sub(r"(?<!\\)`.*?(?<!\\)`", "``", text, flags=re.DOTALL)
# Remove comments
text = re.sub(r'//.*', '', text)
text = re.sub(r'/\*.*?\*/', '', text, flags=re.DOTALL)

stack = []
for i, char in enumerate(text):
    if char in '{(':
        stack.append((char, i))
    elif char == '}':
        if not stack:
            pass
        elif stack[-1][0] == '{':
            stack.pop()
        else:
            print("Mismatch }", stack[-1])
            break
    elif char == ')':
        if not stack:
            pass
        elif stack[-1][0] == '(':
            stack.pop()
        else:
            print("Mismatch )", stack[-1])
            break

for s in stack:
    # let's just find where in the original file this character is roughly
    # since we replaced things with same length? No, we replaced with '', ''
    # wait, the regex replaced with 2 chars. This messes up indices.
    pass

# Better approach: parse with TypeScript compiler!
