const fs = require('fs');
const lines = fs.readFileSync('src/App.tsx', 'utf-8').split('\n');
let func = null;
for(let i = 4850; i >= 0; i--) {
  if (lines[i].includes('function ')) {
    func = lines[i];
    console.log('Line ' + (i+1) + ': ' + func);
    break;
  }
}
