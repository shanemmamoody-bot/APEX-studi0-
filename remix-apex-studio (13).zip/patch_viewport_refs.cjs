const fs = require('fs');
let code = fs.readFileSync('src/components/Viewport.tsx', 'utf-8');

code = code.replace(
  "  const [equippedSlot, setEquippedSlot] = useState<number | null>(() =>\\n    starterPackItems.length > 0 ? 0 : null,\\n  );",
  "  const [equippedSlot, setEquippedSlot] = useState<number | null>(() =>\\n    starterPackItems.length > 0 ? 0 : null,\\n  );\\n  const equippedSlotRef = useRef<number | null>(equippedSlot);\\n  const starterPackItemsRef = useRef(starterPackItems);\\n  useEffect(() => { equippedSlotRef.current = equippedSlot; }, [equippedSlot]);\\n  useEffect(() => { starterPackItemsRef.current = starterPackItems; }, [starterPackItems]);"
);

fs.writeFileSync('src/components/Viewport.tsx', code);
