const fs = require('fs');
let code = fs.readFileSync('src/components/Viewport.tsx', 'utf-8');

code = code.replace(
  "  const modelLastAiModeRef = useRef<Map<string, string>>(new Map());",
  "  const modelLastAiModeRef = useRef<Map<string, string>>(new Map());\n  const modelAutonomousStateRef = useRef<Map<string, { state: string, lastStateChange: number, trust: number }>>(new Map());"
);

code = code.replace(
  "      modelLastAiModeRef.current.clear();",
  "      modelLastAiModeRef.current.clear();\n      modelAutonomousStateRef.current.clear();"
);

fs.writeFileSync('src/components/Viewport.tsx', code);
