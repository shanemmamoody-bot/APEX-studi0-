const fs = require('fs');
let code = fs.readFileSync('src/types.ts', 'utf-8');

code = code.replace(
  "aiMode?: 'Idle' | 'Follow' | 'Patrol' | 'Wander' | 'Flee' | 'Guard';",
  "aiMode?: 'Idle' | 'Follow' | 'Patrol' | 'Wander' | 'Flee' | 'Guard' | 'Attack';\n  aiFaction?: 'Friendly' | 'Hostile' | 'Neutral';"
);

fs.writeFileSync('src/types.ts', code);
