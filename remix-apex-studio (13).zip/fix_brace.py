with open('server.ts', 'r') as f:
    lines = f.readlines()

# line 4772 is index 4771
if lines[4771].strip() == '}':
    lines[4771] = '\n'
    with open('server.ts', 'w') as f:
        f.writelines(lines)
    print("Removed } at 4772")
