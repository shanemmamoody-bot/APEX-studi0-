const fs = require('fs');
let code = fs.readFileSync('src/components/PropertiesPanel.tsx', 'utf-8');

const aiModeSelectTarget = `<option value="Flee">Flee Player</option>
                      </select>
                    </div>`;

const aiModeSelectReplace = `<option value="Flee">Flee Player</option>
                        <option value="Attack">Aggressive / Attack</option>
                      </select>
                    </div>
                    
                    {/* Faction */}
                    <div className="space-y-1">
                      <span className="text-gray-400 font-medium text-xs block">Faction</span>
                      <select
                        value={selectedPart.aiFaction || 'Neutral'}
                        onChange={(e) => handlePartChange("aiFaction", e.target.value)}
                        className="bg-[#0d0810] text-white border border-[#3b1119] rounded px-2 py-1 text-xs w-full focus:outline-none focus:border-red-500"
                      >
                        <option value="Neutral">Neutral (Passive)</option>
                        <option value="Friendly">Friendly (Allies)</option>
                        <option value="Hostile">Hostile (Enemies)</option>
                      </select>
                    </div>`;

code = code.replace(aiModeSelectTarget, aiModeSelectReplace);
fs.writeFileSync('src/components/PropertiesPanel.tsx', code);
