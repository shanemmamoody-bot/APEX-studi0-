const fs = require('fs');
let code = fs.readFileSync('src/components/Viewport.tsx', 'utf-8');

const targetStr = `          // Inject advanced scriptable flat properties
          if (modelInst.aiMode === 'Follow') {
            behaviors.push({ type: 'Follow Player', speed: modelInst.aiWalkSpeed ?? 16, followDistance: modelInst.aiStopDistance ?? 2 });
          } else if (modelInst.aiMode === 'Patrol') {
            behaviors.push({ type: 'Patrol', speed: modelInst.aiWalkSpeed ?? 16, patrolDistance: modelInst.aiPatrolRadius ?? 10 });
          }`;

const replaceStr = `          // Inject advanced scriptable flat properties
          if (modelInst.aiMode === 'Follow') {
            behaviors.push({ type: 'Follow Player', speed: modelInst.aiWalkSpeed ?? 16, followDistance: modelInst.aiStopDistance ?? 2 });
          } else if (modelInst.aiMode === 'Patrol') {
            behaviors.push({ type: 'Patrol', speed: modelInst.aiWalkSpeed ?? 16, patrolDistance: modelInst.aiPatrolRadius ?? 10 });
          } else if (modelInst.aiMode === 'Wander') {
            behaviors.push({ type: 'Wander', speed: modelInst.aiWalkSpeed ?? 16, wanderDistance: modelInst.aiPatrolRadius ?? 15 });
          } else if (modelInst.aiMode === 'Flee') {
            behaviors.push({ type: 'Flee Player', speed: modelInst.aiWalkSpeed ?? 20, fleeDistance: 30 });
          }`;

code = code.replace(targetStr, replaceStr);
fs.writeFileSync('src/components/Viewport.tsx', code);
