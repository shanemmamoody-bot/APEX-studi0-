sed -i '81,83c\
}\
\
function saveUsersDB() {\
  try {\
    const data = JSON.stringify(usersDb, null, 2);\
    const tmpFile = USERS_FILE + ".tmp";\
    fs.writeFileSync(tmpFile, data, "utf-8");\
    fs.renameSync(tmpFile, USERS_FILE);\
    fs.writeFileSync(USERS_FILE + ".bak", data, "utf-8");\
  } catch (e) {\
    console.error("Failed to save users_db.json:", e);\
    try {\
      fs.writeFileSync(USERS_FILE, JSON.stringify(usersDb, null, 2), "utf-8");\
    } catch (err2) {\
      console.error("Direct write fallback failed for users_db.json:", err2);\
    }\
  }\
}' server.ts
