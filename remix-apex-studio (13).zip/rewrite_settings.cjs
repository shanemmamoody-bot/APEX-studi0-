const fs = require('fs');
const file = 'src/components/SettingsModal.tsx';
let code = fs.readFileSync(file, 'utf8');

// Replace standard setting cards with flat rows
// Pattern: <div className="p-3 bg-[#0A0A0C] border border-[#1E1E24] rounded-xl flex items-center justify-between">
// Also <div className="p-3 bg-[#0A0A0C] border border-emerald-500/30 rounded-xl flex items-center justify-between">

code = code.replace(
  /<div className="p-3 bg-\[#0A0A0C\] border border-\[#1E1E24\] rounded-xl flex items-center justify-between">/g,
  '<div className="py-4 border-b border-[#1E1E24] flex items-center justify-between">'
);

code = code.replace(
  /<div className="p-3 bg-\[#0A0A0C\] border border-emerald-500\/30 rounded-xl flex items-center justify-between">/g,
  '<div className="py-4 border-b border-[#1E1E24] flex items-center justify-between">'
);

code = code.replace(
  /<div className="p-3 bg-\[#0A0A0C\] border border-rose-500\/30 rounded-xl flex items-center justify-between">/g,
  '<div className="py-4 border-b border-[#1E1E24] flex items-center justify-between">'
);

// Settings grid wrapper
// <div className="grid grid-cols-2 gap-3">
// <div className="p-3 bg-[#0A0A0C] border border-[#1E1E24] rounded-xl">
code = code.replace(
  /<div className="grid grid-cols-2 gap-3">\s*<div className="p-3 bg-\[#0A0A0C\] border border-\[#1E1E24\] rounded-xl">/g,
  '<div className="grid grid-cols-2 gap-6 py-4 border-b border-[#1E1E24]">\n                    <div>'
);
code = code.replace(
  /<div className="p-3 bg-\[#0A0A0C\] border border-\[#1E1E24\] rounded-xl">\s*<div className="text-\[10px\] text-gray-500 font-mono uppercase">\s*Join Date/g,
  '<div>\n                      <div className="text-[10px] text-gray-500 font-mono uppercase">\n                        Join Date'
);

// Toggle cards
// <div className="p-3 bg-[#0A0A0C] border border-[#1E1E24] rounded-xl flex items-center justify-between cursor-pointer group hover:border-[#3B82F6]/50 transition-colors"
code = code.replace(
  /<div\s*onClick=\{[^}]+\}\s*className="p-3 bg-\[#0A0A0C\] border border-\[#1E1E24\] rounded-xl flex items-center justify-between cursor-pointer group hover:border-\[#3B82F6\]\/50 transition-colors"\s*>/g,
  (match) => match.replace(
    'className="p-3 bg-[#0A0A0C] border border-[#1E1E24] rounded-xl flex items-center justify-between cursor-pointer group hover:border-[#3B82F6]/50 transition-colors"',
    'className="py-4 border-b border-[#1E1E24] flex items-center justify-between cursor-pointer group"'
  )
);

// Let's replace ALL rounded-xl cards inside the space-y-3 of the settings panes.
code = code.replace(/<div className="space-y-3">/g, '<div className="flex flex-col">');

// For navigation:
// <button className="w-full text-left px-3 py-2 rounded-xl text-xs font-bold transition-all flex items-center space-x-2 cursor-pointer bg-[#3B82F6] text-white">
code = code.replace(
  /className=\{`w-full text-left px-3 py-2 rounded-xl text-xs font-bold transition-all flex items-center space-x-2 cursor-pointer \${[\s\S]*?}`\}/g,
  (match) => match.replace('rounded-xl', 'rounded-md').replace('bg-[#3B82F6]', 'bg-[#1E1E24]')
);

// Let's replace the outer spacing too
code = code.replace(/<div className="flex-1 overflow-y-auto p-6 space-y-4">/g, '<div className="flex-1 overflow-y-auto px-8 py-6 space-y-6">');

fs.writeFileSync(file, code);
