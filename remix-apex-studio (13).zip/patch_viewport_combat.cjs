const fs = require('fs');
let code = fs.readFileSync('src/components/Viewport.tsx', 'utf-8');

const targetStr = `          } else if (activeAiMode === 'Attack') {
            behaviors.push({ type: 'Follow Player', speed: (modelInst.aiWalkSpeed || 16) * 1.2, followDistance: 1 });
            behaviors.push({ type: 'Deal Damage', damage: modelInst.aiDamage || 15, radius: 3.5, cooldown: 1.0 });
          }`;

const replaceStr = `          } else if (activeAiMode === 'Attack') {
            const combatStyle = modelInst.aiCombatStyle || 'Melee';
            const atkSpeed = (modelInst.aiWalkSpeed || 16) * 1.2;
            
            if (combatStyle === 'HitAndRun') {
              if (dist < 4) {
                 behaviors.push({ type: 'Deal Damage', damage: modelInst.aiDamage || 15, radius: 4.0, cooldown: 1.0 });
                 behaviors.push({ type: 'Flee Player', speed: atkSpeed * 1.3, fleeDistance: 15 });
              } else {
                 behaviors.push({ type: 'Follow Player', speed: atkSpeed, followDistance: 1 });
              }
            } else if (combatStyle === 'Strafe') {
              behaviors.push({ type: 'Follow Player', speed: atkSpeed, followDistance: 8 });
              if (dist < 12) {
                 behaviors.push({ type: 'Patrol', speed: atkSpeed, patrolDistance: 8 }); // roughly strafe around spawn
                 behaviors.push({ type: 'Deal Damage', damage: modelInst.aiDamage || 10, radius: 12, cooldown: 2.0 }); // Ranged/Long attack
              }
            } else if (combatStyle === 'Charge') {
              behaviors.push({ type: 'Follow Player', speed: atkSpeed * 1.5, followDistance: 1 });
              behaviors.push({ type: 'Deal Damage', damage: (modelInst.aiDamage || 15) * 1.5, radius: 4.5, cooldown: 2.0 });
            } else {
              // Melee
              behaviors.push({ type: 'Follow Player', speed: atkSpeed, followDistance: 1 });
              behaviors.push({ type: 'Deal Damage', damage: modelInst.aiDamage || 15, radius: 3.5, cooldown: 1.0 });
            }
          }`;

code = code.replace(targetStr, replaceStr);
fs.writeFileSync('src/components/Viewport.tsx', code);
