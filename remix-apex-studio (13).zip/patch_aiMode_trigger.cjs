const fs = require('fs');
let code = fs.readFileSync('src/components/Viewport.tsx', 'utf-8');

const targetStr = `          const behaviors: any[] = modelInst.behaviors ? [...modelInst.behaviors] : [];

          // Inject advanced scriptable flat properties`;

const replaceStr = `          const behaviors: any[] = modelInst.behaviors ? [...modelInst.behaviors] : [];

          // Trigger state transition events
          const currentAiMode = modelInst.aiMode || 'Idle';
          if (modelLastAiModeRef.current.get(modelInst.id) !== currentAiMode) {
            modelLastAiModeRef.current.set(modelInst.id, currentAiMode);
            if (currentAiMode === 'Idle') dispatchCreatureAiEvent(modelInst.id, 'onIdle');
            if (currentAiMode === 'Patrol') dispatchCreatureAiEvent(modelInst.id, 'onPatrol');
            if (currentAiMode === 'Follow') dispatchCreatureAiEvent(modelInst.id, 'onFollow');
          }

          // Inject advanced scriptable flat properties`;

code = code.replace(targetStr, replaceStr);
fs.writeFileSync('src/components/Viewport.tsx', code);
