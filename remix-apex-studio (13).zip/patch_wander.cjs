const fs = require('fs');
let code = fs.readFileSync('src/components/Viewport.tsx', 'utf-8');

code = code.replace(
  "  const modelPatrolAnglesRef = useRef<Map<string, number>>(new Map());",
  "  const modelPatrolAnglesRef = useRef<Map<string, number>>(new Map());\n  const modelWanderTargetsRef = useRef<Map<string, {x: number, z: number, nextUpdate: number}>>(new Map());"
);

code = code.replace(
  "      modelPatrolAnglesRef.current.clear();",
  "      modelPatrolAnglesRef.current.clear();\n      modelWanderTargetsRef.current.clear();"
);

const wanderLogic = `              } else if (b.type === "Wander") {
                const wanderDist = b.wanderDistance || 15;
                const spd = b.speed || 2.5;
                const origin = modelInitialPositionsRef.current.get(modelInst.id) || mPos;
                let target = modelWanderTargetsRef.current.get(modelInst.id);
                if (!target || nowTimeMs > target.nextUpdate) {
                  const angle = Math.random() * Math.PI * 2;
                  const dist = Math.random() * wanderDist;
                  target = {
                    x: origin.x + Math.cos(angle) * dist,
                    z: origin.z + Math.sin(angle) * dist,
                    nextUpdate: nowTimeMs + 2000 + Math.random() * 4000
                  };
                  modelWanderTargetsRef.current.set(modelInst.id, target);
                }
                const dxW = target.x - mPos.x;
                const dzW = target.z - mPos.z;
                if (Math.hypot(dxW, dzW) > 0.5) {
                  stepMoveRigid(target.x, target.z, spd, true);
                }`;

code = code.replace(
  `              } else if (b.type === "Guard Area") {`,
  wanderLogic + `\n              } else if (b.type === "Guard Area") {`
);

fs.writeFileSync('src/components/Viewport.tsx', code);
