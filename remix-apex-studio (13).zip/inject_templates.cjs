const fs = require('fs');

const code = `import { Project, WorkspacePart, GameScript, GuiObjectData, ScriptedModelConfig } from '../types';

export const createPresetScriptedModels = (): ScriptedModelConfig[] => [];
export const createDefaultGuiObjects = (): GuiObjectData[] => [];

export const createDefaultBaseplate = (): Project => ({
  id: 'classic-baseplate',
  name: 'Classic Baseplate',
  thumbnail: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3',
  lastEdited: 'Just now',
  lighting: {
    ambient: '#404040',
    skyColor: '#87ceeb',
    brightness: 1.0,
    timeOfDay: '14:00',
  },
  workspace: [
    {
      id: 'baseplate-1',
      name: 'Baseplate',
      type: 'part',
      shape: 'block',
      position: { x: 0, y: -1, z: 0 },
      rotation: { x: 0, y: 0, z: 0 },
      size: { x: 300, y: 2, z: 300 },
      color: '#808080',
      material: 'plastic',
      transparency: 0,
      canCollide: true,
      anchored: true,
    }
  ],
  scripts: [],
  guiObjects: createDefaultGuiObjects(),
  scriptedModels: createPresetScriptedModels(),
});

export const createDefaultObby = (): Project => {
  const workspace: WorkspacePart[] = [
    {
      id: 'baseplate-1',
      name: 'Baseplate',
      type: 'part',
      shape: 'block',
      position: { x: 0, y: -1, z: 0 },
      rotation: { x: 0, y: 0, z: 0 },
      size: { x: 300, y: 2, z: 300 },
      color: '#1f2937',
      material: 'plastic',
      transparency: 0,
      canCollide: true,
      anchored: true,
    },
    {
      id: 'start-plat',
      name: 'Start Platform',
      type: 'part',
      shape: 'block',
      position: { x: 0, y: 0.5, z: 0 },
      rotation: { x: 0, y: 0, z: 0 },
      size: { x: 12, y: 1, z: 12 },
      color: '#10b981',
      material: 'plastic',
      transparency: 0,
      canCollide: true,
      anchored: true,
    }
  ];

  const rainbowColors = [
    '#ef4444', '#f97316', '#eab308', '#10b981',
    '#06b6d4', '#3b82f6', '#8b5cf6', '#ec4899'
  ];

  for (let i = 1; i <= 45; i++) {
    const jumpZ = -i * 12;
    const jumpX = Math.sin(i * 0.4) * 11;
    const jumpY = 1.0 + Math.sin(i * 0.25) * 2.2 + (i > 30 ? (i - 30) * 0.4 : 0);
    const isCheckpoint = i % 5 === 0;
    const isBounce = i % 7 === 0 && !isCheckpoint;
    const isLava = i % 4 === 0 && !isCheckpoint && !isBounce;

    const sizeX = isCheckpoint ? 8 : (isBounce ? 6.5 : 5.8);
    const sizeY = isCheckpoint ? 1.2 : 1.0;
    const sizeZ = isCheckpoint ? 8 : (isBounce ? 6.5 : 5.8);

    let color = rainbowColors[(i - 1) % rainbowColors.length];
    if (isCheckpoint) color = '#06b6d4';
    else if (isBounce) color = '#f59e0b';
    else if (isLava) color = '#ef4444';

    workspace.push({
      id: \`part-jump-\${i}\`,
      name: isCheckpoint ? \`Checkpoint \${i}\` : (isLava ? \`Lava Trap \${i}\` : \`Platform \${i}\`),
      type: 'part',
      shape: 'block',
      position: { x: Math.round(jumpX * 10) / 10, y: Math.round(jumpY * 10) / 10, z: Math.round(jumpZ * 10) / 10 },
      rotation: { x: 0, y: 0, z: 0 },
      size: { x: sizeX, y: sizeY, z: sizeZ },
      color: color,
      material: isLava ? 'neon' : 'plastic',
      transparency: 0,
      canCollide: true,
      anchored: true,
    });
  }

  // Finish Trophy Platform
  const finishZ = -46 * 12;
  const finishX = Math.sin(46 * 0.4) * 11;
  const finishY = 1.0 + Math.sin(46 * 0.25) * 2.2 + 16 * 0.4;

  workspace.push({
    id: 'part-finish-platform',
    name: 'Finish Platform',
    type: 'part',
    shape: 'block',
    position: { x: Math.round(finishX * 10) / 10, y: Math.round(finishY * 10) / 10, z: Math.round(finishZ * 10) / 10 },
    rotation: { x: 0, y: 0, z: 0 },
    size: { x: 16, y: 1.5, z: 16 },
    color: '#f59e0b',
    material: 'neon',
    transparency: 0,
    canCollide: true,
    anchored: true,
  });

  workspace.push({
    id: 'part-finish-trophy',
    name: 'Golden Victory Trophy',
    type: 'part',
    shape: 'block',
    position: { x: Math.round(finishX * 10) / 10, y: Math.round((finishY + 2.5) * 10) / 10, z: Math.round(finishZ * 10) / 10 },
    rotation: { x: 0, y: 45, z: 0 },
    size: { x: 3, y: 3.5, z: 3 },
    color: '#facc15',
    material: 'neon',
    transparency: 0,
    canCollide: true,
    anchored: true,
  });

  const obbyScript: GameScript = {
    id: 'script-obby-logic',
    name: 'ObbyLogic',
    type: 'server',
    code: \`local Players = game:GetService("Players")

local function getPlayerFromCharacter(char)
    for _, p in ipairs(Players:GetPlayers()) do
        if p.Character == char then return p end
    end
    return nil
end

local function setupObby()
    local spawnLocation = workspace:FindFirstChild("Start Platform")
    
    local function onPlayerAdded(player)
        local leaderstats = Instance.new("Folder")
        leaderstats.Name = "leaderstats"
        leaderstats.Parent = player
        
        local stage = Instance.new("NumberValue")
        stage.Name = "Stage"
        stage.Value = 1
        stage.Parent = leaderstats
        
        player.CharacterAdded:Connect(function(char)
            local humanoid = char:WaitForChild("Humanoid")
            local hrp = char:WaitForChild("HumanoidRootPart")
            
            task.wait(0.1)
            
            -- Teleport to checkpoint
            local targetStage = stage.Value
            if targetStage > 1 then
                local checkpoint = workspace:FindFirstChild("Checkpoint " .. targetStage)
                if checkpoint then
                    hrp.CFrame = checkpoint.CFrame + Vector3.new(0, 3, 0)
                end
            else
                if spawnLocation then
                    hrp.CFrame = spawnLocation.CFrame + Vector3.new(0, 3, 0)
                end
            end
        end)
    end
    
    Players.PlayerAdded:Connect(onPlayerAdded)
    for _, p in ipairs(Players:GetPlayers()) do
        onPlayerAdded(p)
    end
    
    -- Setup Lava and Checkpoints
    for _, part in ipairs(workspace:GetChildren()) do
        if string.find(part.Name, "^Lava") then
            part.Touched:Connect(function(hit)
                if hit and hit.Parent then
                    local hum = hit.Parent:FindFirstChild("Humanoid")
                    if hum then
                        hum.Health = 0
                    end
                end
            end)
        elseif string.find(part.Name, "^Checkpoint") then
            local stageNum = tonumber(string.match(part.Name, "%d+"))
            if stageNum then
                part.Touched:Connect(function(hit)
                    if hit and hit.Parent then
                        local player = getPlayerFromCharacter(hit.Parent)
                        if player then
                            local leaderstats = player:FindFirstChild("leaderstats")
                            if leaderstats and leaderstats:FindFirstChild("Stage") then
                                if leaderstats.Stage.Value < stageNum then
                                    leaderstats.Stage.Value = stageNum
                                end
                            end
                        end
                    end
                end)
            end
        elseif part.Name == "Golden Victory Trophy" or part.Name == "Finish Platform" then
            part.Touched:Connect(function(hit)
                if hit and hit.Parent then
                    local player = getPlayerFromCharacter(hit.Parent)
                    if player then
                        local leaderstats = player:FindFirstChild("leaderstats")
                        if leaderstats and leaderstats:FindFirstChild("Stage") then
                            if leaderstats.Stage.Value < 999 then
                                leaderstats.Stage.Value = 999
                                print(player.Name .. " has completed the obby!")
                            end
                        end
                    end
                end
            end)
        end
    end
end

setupObby()
\`
  };

  return {
    id: 'classic-45-jump-mega-obby',
    name: '45-Jump Mega Obby Course',
    thumbnail: 'https://images.unsplash.com/photo-1511512578047-dfb367046420?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3',
    lastEdited: 'Just now',
    lighting: {
      ambient: '#404040',
      skyColor: '#87ceeb',
      brightness: 1.0,
      timeOfDay: '14:00',
    },
    workspace,
    scripts: [obbyScript],
    guiObjects: createDefaultGuiObjects(),
    scriptedModels: createPresetScriptedModels(),
  };
};

export const createFullTycoon = (): Project => {
  const workspace: WorkspacePart[] = [
    {
      id: 'baseplate',
      name: 'Baseplate',
      type: 'part',
      shape: 'block',
      position: { x: 0, y: -1, z: 0 },
      rotation: { x: 0, y: 0, z: 0 },
      size: { x: 300, y: 2, z: 300 },
      color: '#4ade80', // Green grass
      material: 'plastic',
      transparency: 0,
      canCollide: true,
      anchored: true,
    },
    {
      id: 'tycoon-floor',
      name: 'Tycoon Floor',
      type: 'part',
      shape: 'block',
      position: { x: 0, y: 0.1, z: 0 },
      rotation: { x: 0, y: 0, z: 0 },
      size: { x: 60, y: 0.2, z: 60 },
      color: '#9ca3af',
      material: 'plastic',
      transparency: 0,
      canCollide: true,
      anchored: true,
    },
    {
      id: 'owner-door',
      name: 'Owner Door',
      type: 'part',
      shape: 'block',
      position: { x: 0, y: 2, z: 30 },
      rotation: { x: 0, y: 0, z: 0 },
      size: { x: 8, y: 4, z: 1 },
      color: '#ef4444', // Red (unclaimed)
      material: 'neon',
      transparency: 0.5,
      canCollide: false,
      anchored: true,
    },
    {
      id: 'dropper-1',
      name: 'Dropper 1',
      type: 'part',
      shape: 'block',
      position: { x: -10, y: 5, z: -10 },
      rotation: { x: 0, y: 0, z: 0 },
      size: { x: 4, y: 4, z: 4 },
      color: '#3b82f6',
      material: 'plastic',
      transparency: 0,
      canCollide: true,
      anchored: true,
    },
    {
      id: 'conveyor',
      name: 'Conveyor',
      type: 'part',
      shape: 'block',
      position: { x: 0, y: 1, z: -10 },
      rotation: { x: 0, y: 0, z: 0 },
      size: { x: 20, y: 1, z: 4 },
      color: '#1f2937',
      material: 'plastic',
      transparency: 0,
      canCollide: true,
      anchored: true,
    },
    {
      id: 'collector',
      name: 'Collector',
      type: 'part',
      shape: 'block',
      position: { x: 12, y: 2, z: -10 },
      rotation: { x: 0, y: 0, z: 0 },
      size: { x: 4, y: 4, z: 6 },
      color: '#eab308',
      material: 'neon',
      transparency: 0.5,
      canCollide: false,
      anchored: true,
    },
    {
      id: 'button-dropper-2',
      name: 'Buy Dropper 2',
      type: 'part',
      shape: 'block',
      position: { x: -10, y: 0.5, z: 0 },
      rotation: { x: 0, y: 0, z: 0 },
      size: { x: 4, y: 1, z: 4 },
      color: '#22c55e',
      material: 'neon',
      transparency: 0,
      canCollide: false,
      anchored: true,
    }
  ];

  const tycoonScript: GameScript = {
    id: 'script-tycoon-logic',
    name: 'TycoonLogic',
    type: 'server',
    code: \`local Players = game:GetService("Players")
local DataStoreService = game:GetService("DataStoreService")
local myStore = DataStoreService:GetStore("TycoonSaveData")

local function getPlayerFromCharacter(char)
    for _, p in ipairs(Players:GetPlayers()) do
        if p.Character == char then return p end
    end
    return nil
end

local owner = nil
local cash = 0
local dropping = true
local hasDropper2 = false

local ownerDoor = workspace:FindFirstChild("Owner Door")
local collector = workspace:FindFirstChild("Collector")
local buttonDropper2 = workspace:FindFirstChild("Buy Dropper 2")

-- Setup GUI
local function updateGUI()
    if not owner then return end
    local gui = owner:FindFirstChild("PlayerGui")
    if not gui then
        gui = Instance.new("Folder")
        gui.Name = "PlayerGui"
        gui.Parent = owner
    end
    
    local screen = gui:FindFirstChild("TycoonUI")
    if not screen then
        screen = Instance.new("ScreenGui")
        screen.Name = "TycoonUI"
        screen.Parent = gui
        
        local text = Instance.new("TextLabel")
        text.Name = "CashLabel"
        text.Parent = screen
    end
    
    local text = screen:FindFirstChild("CashLabel")
    if text then
        -- We will just use leaderstats instead of GUI for simplicity
    end
end

Players.PlayerAdded:Connect(function(player)
    local leaderstats = Instance.new("Folder")
    leaderstats.Name = "leaderstats"
    leaderstats.Parent = player
    
    local money = Instance.new("NumberValue")
    money.Name = "Cash"
    money.Value = myStore:GetAsync(player.Name .. "-cash") or 0
    money.Parent = leaderstats
    
    local d2 = myStore:GetAsync(player.Name .. "-dropper2")
    if d2 == true then
        hasDropper2 = true
        if buttonDropper2 then buttonDropper2.Transparency = 1 end
        local d2Part = Instance.new("Part", workspace)
        d2Part.Name = "Dropper 2"
        d2Part.Size = Vector3.new(4, 4, 4)
        d2Part.Position = Vector3.new(0, 5, -10)
        d2Part.Color = "purple"
        d2Part.Anchored = true
    end
end)

Players.PlayerRemoving:Connect(function(player)
    local leaderstats = player:FindFirstChild("leaderstats")
    if leaderstats and leaderstats:FindFirstChild("Cash") then
        myStore:SetAsync(player.Name .. "-cash", leaderstats.Cash.Value)
        myStore:SetAsync(player.Name .. "-dropper2", hasDropper2)
    end
end)

if ownerDoor then
    ownerDoor.Touched:Connect(function(hit)
        if owner == nil and hit and hit.Parent then
            local p = getPlayerFromCharacter(hit.Parent)
            if p then
                owner = p
                ownerDoor.Color = "green"
                ownerDoor.Transparency = 0.8
                print(p.Name .. " claimed the tycoon!")
            end
        end
    end)
end

if collector then
    collector.Touched:Connect(function(hit)
        if hit and string.find(hit.Name, "Drop") then
            local val = hit:FindFirstChild("Value")
            local amount = val and val.Value or 5
            
            if owner then
                local ls = owner:FindFirstChild("leaderstats")
                if ls and ls:FindFirstChild("Cash") then
                    ls.Cash.Value = ls.Cash.Value + amount
                end
            end
            hit:Destroy()
        end
    end)
end

if buttonDropper2 then
    buttonDropper2.Touched:Connect(function(hit)
        if not hasDropper2 and owner and hit and hit.Parent then
            local p = getPlayerFromCharacter(hit.Parent)
            if p == owner then
                local ls = owner:FindFirstChild("leaderstats")
                if ls and ls:FindFirstChild("Cash") and ls.Cash.Value >= 50 then
                    ls.Cash.Value = ls.Cash.Value - 50
                    hasDropper2 = true
                    buttonDropper2.Transparency = 1
                    
                    local d2Part = Instance.new("Part", workspace)
                    d2Part.Name = "Dropper 2"
                    d2Part.Size = Vector3.new(4, 4, 4)
                    d2Part.Position = Vector3.new(0, 5, -10)
                    d2Part.Color = "purple"
                    d2Part.Anchored = true
                end
            end
        end
    end)
end

-- Dropper Loop
task.spawn(function()
    while dropping do
        if owner then
            local d1 = workspace:FindFirstChild("Dropper 1")
            if d1 then
                local drop = Instance.new("Part", workspace)
                drop.Name = "Drop1"
                drop.Size = Vector3.new(1.5, 1.5, 1.5)
                drop.Position = d1.Position + Vector3.new(0, -3, 0)
                drop.Color = "yellow"
                local val = Instance.new("NumberValue", drop)
                val.Name = "Value"
                val.Value = 5
            end
            
            if hasDropper2 then
                local d2 = workspace:FindFirstChild("Dropper 2")
                if d2 then
                    local drop = Instance.new("Part", workspace)
                    drop.Name = "Drop2"
                    drop.Size = Vector3.new(1.5, 1.5, 1.5)
                    drop.Position = d2.Position + Vector3.new(0, -3, 0)
                    drop.Color = "purple"
                    local val = Instance.new("NumberValue", drop)
                    val.Name = "Value"
                    val.Value = 15
                end
            end
        end
        task.wait(2)
    end
end)

-- Conveyor Loop
task.spawn(function()
    while true do
        local conv = workspace:FindFirstChild("Conveyor")
        if conv then
            for _, p in ipairs(workspace:GetChildren()) do
                if string.find(p.Name, "Drop") then
                    if p.Position.y < 3 and p.Position.x < 11 then
                        p.Position = p.Position + Vector3.new(0.5, 0, 0)
                    end
                end
            end
        end
        task.wait(0.1)
    end
end)
\`
  };

  return {
    id: 'full-tycoon-template',
    name: 'Full Base Tycoon',
    thumbnail: 'https://images.unsplash.com/photo-1522204523234-8729aa6e3d5f?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3',
    lastEdited: 'Just now',
    lighting: {
      ambient: '#404040',
      skyColor: '#87ceeb',
      brightness: 1.0,
      timeOfDay: '14:00',
    },
    workspace,
    scripts: [tycoonScript],
    guiObjects: createDefaultGuiObjects(),
    scriptedModels: createPresetScriptedModels(),
  };
};

export const createForestGunGame = (): Project => {
  const workspace: WorkspacePart[] = [
    {
      id: 'baseplate',
      name: 'Forest Baseplate',
      type: 'part',
      shape: 'block',
      position: { x: 0, y: -1, z: 0 },
      rotation: { x: 0, y: 0, z: 0 },
      size: { x: 1000, y: 2, z: 1000 },
      color: '#166534', // Dark green grass
      material: 'grass',
      transparency: 0,
      canCollide: true,
      anchored: true,
    }
  ];

  // Generate some trees and cover
  for(let i=0; i<100; i++) {
    const px = (Math.random() - 0.5) * 800;
    const pz = (Math.random() - 0.5) * 800;
    
    // Trunk
    workspace.push({
      id: \`tree-trunk-\${i}\`,
      name: 'Trunk',
      type: 'part',
      shape: 'cylinder',
      position: { x: px, y: 6, z: pz },
      rotation: { x: 0, y: 0, z: 90 }, // cylinder is sideways by default usually? 
      size: { x: 12, y: 3, z: 3 },
      color: '#78350f',
      material: 'wood',
      transparency: 0,
      canCollide: true,
      anchored: true,
    });
    // Leaves
    workspace.push({
      id: \`tree-leaves-\${i}\`,
      name: 'Leaves',
      type: 'part',
      shape: 'sphere',
      position: { x: px, y: 15, z: pz },
      rotation: { x: 0, y: 0, z: 0 },
      size: { x: 15, y: 15, z: 15 },
      color: '#22c55e',
      material: 'grass',
      transparency: 0,
      canCollide: true,
      anchored: true,
    });
  }

  // Generate some NPCs
  for(let i=0; i<10; i++) {
    const px = (Math.random() - 0.5) * 200;
    const pz = (Math.random() - 0.5) * 200;
    workspace.push({
      id: \`npc-zombie-\${i}\`,
      name: 'ZombieNPC',
      type: 'part',
      shape: 'block',
      position: { x: px, y: 3, z: pz },
      rotation: { x: 0, y: 0, z: 0 },
      size: { x: 4, y: 6, z: 4 },
      color: '#84cc16',
      material: 'plastic',
      transparency: 0,
      canCollide: true,
      anchored: true,
    });
  }
  
  // Shop part
  workspace.push({
      id: 'shop-part',
      name: 'Weapon Shop',
      type: 'part',
      shape: 'block',
      position: { x: 0, y: 2, z: 50 },
      rotation: { x: 0, y: 0, z: 0 },
      size: { x: 10, y: 10, z: 10 },
      color: '#3b82f6',
      material: 'neon',
      transparency: 0.2,
      canCollide: true,
      anchored: true,
  });

  const gunGameScript: GameScript = {
    id: 'script-gungame-logic',
    name: 'GunGameLogic',
    type: 'server',
    code: \`local Players = game:GetService("Players")
local DataStoreService = game:GetService("DataStoreService")
local myStore = DataStoreService:GetStore("GunGameData")
local StarterPack = game:GetService("StarterPack")

local function getPlayerFromCharacter(char)
    for _, p in ipairs(Players:GetPlayers()) do
        if p.Character == char then return p end
    end
    return nil
end

-- Create weapons
local function createWeapon(name, damage, cooldown)
    local tool = Instance.new("Tool", StarterPack)
    tool.Name = name
    
    local handle = Instance.new("Part", tool)
    handle.Name = "Handle"
    handle.Size = Vector3.new(1, 1, 3)
    handle.Color = "black"
    
    local cd = Instance.new("NumberValue", tool)
    cd.Name = "Cooldown"
    cd.Value = cooldown
    
    local dmg = Instance.new("NumberValue", tool)
    dmg.Name = "Damage"
    dmg.Value = damage
    
    tool.Activated:Connect(function()
        local player = nil
        if tool.Parent and tool.Parent.ClassName == "Model" then
            player = getPlayerFromCharacter(tool.Parent)
        end
        if not player then return end
        
        local debounce = tool:FindFirstChild("Debounce")
        if debounce then return end
        
        debounce = Instance.new("BoolValue", tool)
        debounce.Name = "Debounce"
        
        -- Simple raycast forward simulation
        local hrp = player.Character:FindFirstChild("HumanoidRootPart")
        if hrp then
            -- Find nearest target for a basic "shoot" mechanic
            local nearest = nil
            local dist = 100
            for _, p in ipairs(workspace:GetChildren()) do
                if p.Name == "ZombieNPC" and p.Position then
                    local d = (p.Position - hrp.Position).Magnitude
                    if d < dist then
                        dist = d
                        nearest = p
                    end
                elseif p.ClassName == "Model" and p ~= player.Character then
                    -- PvP
                    local phrp = p:FindFirstChild("HumanoidRootPart")
                    if phrp then
                        local d = (phrp.Position - hrp.Position).Magnitude
                        if d < dist then
                            dist = d
                            nearest = p
                        end
                    end
                end
            end
            
            if nearest then
                if nearest.Name == "ZombieNPC" then
                    local health = nearest:FindFirstChild("Health") or Instance.new("NumberValue", nearest)
                    health.Name = "Health"
                    if health.Value == 0 then health.Value = 100 end
                    
                    health.Value = health.Value - dmg.Value
                    if health.Value <= 0 then
                        nearest.Position = Vector3.new((math.random()-0.5)*200, 3, (math.random()-0.5)*200)
                        health.Value = 100
                        local ls = player:FindFirstChild("leaderstats")
                        if ls and ls:FindFirstChild("Coins") then
                            ls.Coins.Value = ls.Coins.Value + 10
                            print(player.Name .. " killed a Zombie! +10 Coins")
                        end
                    end
                elseif nearest.ClassName == "Model" then
                    local hum = nearest:FindFirstChild("Humanoid")
                    if hum then
                        hum.Health = hum.Health - dmg.Value
                        if hum.Health <= 0 then
                            local ls = player:FindFirstChild("leaderstats")
                            if ls and ls:FindFirstChild("Coins") then
                                ls.Coins.Value = ls.Coins.Value + 10
                                print(player.Name .. " killed a Player! +10 Coins")
                            end
                        end
                    end
                end
            end
        end
        
        task.wait(cd.Value)
        if debounce then debounce:Destroy() end
    end)
    return tool
end

local basicPistol = createWeapon("Pistol", 25, 0.5)

Players.PlayerAdded:Connect(function(player)
    local leaderstats = Instance.new("Folder")
    leaderstats.Name = "leaderstats"
    leaderstats.Parent = player
    
    local coins = Instance.new("NumberValue")
    coins.Name = "Coins"
    coins.Value = myStore:GetAsync(player.Name .. "-coins") or 0
    coins.Parent = leaderstats
    
    local hasRifle = myStore:GetAsync(player.Name .. "-hasRifle")
    if hasRifle then
        local rifle = Instance.new("BoolValue", player)
        rifle.Name = "HasRifle"
    end
    
    player.CharacterAdded:Connect(function(char)
        -- Give weapons
        local clone = basicPistol:Clone()
        clone.Parent = player:FindFirstChild("Backpack") or char
        
        if player:FindFirstChild("HasRifle") then
            -- We just create the rifle on demand if they own it
            local rifle = createWeapon("Assault Rifle", 15, 0.1)
            rifle.Parent = player:FindFirstChild("Backpack") or char
        end
    end)
end)

Players.PlayerRemoving:Connect(function(player)
    local leaderstats = player:FindFirstChild("leaderstats")
    if leaderstats and leaderstats:FindFirstChild("Coins") then
        myStore:SetAsync(player.Name .. "-coins", leaderstats.Coins.Value)
        myStore:SetAsync(player.Name .. "-hasRifle", (player:FindFirstChild("HasRifle") ~= nil))
    end
end)

-- Shop Logic
local shop = workspace:FindFirstChild("Weapon Shop")
if shop then
    shop.Touched:Connect(function(hit)
        if hit and hit.Parent then
            local p = getPlayerFromCharacter(hit.Parent)
            if p then
                local ls = p:FindFirstChild("leaderstats")
                if ls and ls:FindFirstChild("Coins") then
                    if ls.Coins.Value >= 100 and not p:FindFirstChild("HasRifle") then
                        ls.Coins.Value = ls.Coins.Value - 100
                        local rifleTag = Instance.new("BoolValue", p)
                        rifleTag.Name = "HasRifle"
                        print(p.Name .. " bought the Assault Rifle!")
                        
                        local rifle = createWeapon("Assault Rifle", 15, 0.1)
                        rifle.Parent = p:FindFirstChild("Backpack") or hit.Parent
                    end
                end
            end
        end
    end)
end
\`
  };

  return {
    id: 'forest-gun-game-template',
    name: 'Giant Forest Gun Game',
    thumbnail: 'https://images.unsplash.com/photo-1542273917363-3b1817f69a2d?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3',
    lastEdited: 'Just now',
    lighting: {
      ambient: '#404040',
      skyColor: '#87ceeb',
      brightness: 1.0,
      timeOfDay: '14:00',
    },
    workspace,
    scripts: [gunGameScript],
    guiObjects: createDefaultGuiObjects(),
    scriptedModels: createPresetScriptedModels(),
  };
};

export const createDefaultSpaceArena = (): Project => createDefaultBaseplate();
`

fs.writeFileSync('src/utils/templates.ts', code);
