const fs = require('fs');
let code = fs.readFileSync('src/utils/lua/luaInstances.ts', 'utf-8');

const fxCode = `

  function createExplosion(className)
    local inst = createGenericInstance("Explosion", className)
    rawset(inst, "_position", Vector3.zero)
    rawset(inst, "_blastRadius", 10)
    rawset(inst, "_blastPressure", 500000)
    rawset(inst, "_visible", true)
    inst.Hit = Signal.new()

    local oldNewIdx = getmetatable(inst).__newindex
    local oldIdx = getmetatable(inst).__index

    setmetatable(inst, {
      __index = function(t, k)
        if k == "Position" or k == "position" then return rawget(t, "_position") end
        if k == "BlastRadius" or k == "blastRadius" then return rawget(t, "_blastRadius") end
        if k == "BlastPressure" or k == "blastPressure" then return rawget(t, "_blastPressure") end
        if k == "Visible" or k == "visible" then return rawget(t, "_visible") end
        return oldIdx(t, k)
      end,
      __newindex = function(t, k, v)
        if k == "Parent" or k == "parent" then
          oldNewIdx(t, k, v)
          if v ~= nil then
            -- Trigger explosion visual effect if parented to workspace
            local pos = rawget(t, "_position")
            local radius = rawget(t, "_blastRadius")
            if __js_triggerExplosion_raw then
               __js_triggerExplosion_raw(pos.x, pos.y, pos.z, radius, 50)
            end
          end
          return
        end
        if k == "Position" or k == "position" then rawset(t, "_position", v) return end
        if k == "BlastRadius" or k == "blastRadius" then rawset(t, "_blastRadius", tonumber(v) or 10) return end
        if k == "BlastPressure" or k == "blastPressure" then rawset(t, "_blastPressure", tonumber(v) or 500000) return end
        if k == "Visible" or k == "visible" then rawset(t, "_visible", v ~= false) return end
        oldNewIdx(t, k, v)
      end
    })
    return inst
  end

  function createParticleEmitter(className)
    local inst = createGenericInstance("ParticleEmitter", className)
    rawset(inst, "_color", Color3.new(1,1,1))
    rawset(inst, "_size", 1)
    rawset(inst, "_texture", "")
    rawset(inst, "_transparency", 0)
    rawset(inst, "_rate", 20)
    rawset(inst, "_enabled", true)
    
    local oldNewIdx = getmetatable(inst).__newindex
    local oldIdx = getmetatable(inst).__index
    setmetatable(inst, {
      __index = function(t, k)
        if k == "Color" or k == "color" then return rawget(t, "_color") end
        if k == "Size" or k == "size" then return rawget(t, "_size") end
        if k == "Enabled" or k == "enabled" then return rawget(t, "_enabled") end
        return oldIdx(t, k)
      end,
      __newindex = function(t, k, v)
        if k == "Color" or k == "color" then rawset(t, "_color", v) return end
        if k == "Size" or k == "size" then rawset(t, "_size", v) return end
        if k == "Enabled" or k == "enabled" then rawset(t, "_enabled", v ~= false) return end
        oldNewIdx(t, k, v)
      end
    })
    return inst
  end
`;

code = code.replace(/function createSoundInstance\(name, customId\)[\s\S]*?return snd\n  end\n/m, match => match + fxCode);

code = code.replace(/elseif lowerCls == "sound" then\n        inst = createSoundInstance\(className\)/, `elseif lowerCls == "sound" then
        inst = createSoundInstance(className)
      elseif lowerCls == "explosion" then
        inst = createExplosion(className)
      elseif lowerCls == "particleemitter" or lowerCls == "fire" or lowerCls == "sparkles" then
        inst = createParticleEmitter(className)`);

fs.writeFileSync('src/utils/lua/luaInstances.ts', code);
