const fs = require('fs');
let code = fs.readFileSync('src/components/Viewport.tsx', 'utf-8');

const targetStr = `          if (behaviors.length > 0) {
            // Process configured behaviors (up to 3)
            behaviors.forEach((b: any) => {`;

const replaceStr = `          
          // ADVANCED BLUEPRINTS: Health Regeneration
          if (modelInst.aiRegenRate && modelInst.aiRegenRate > 0 && modelInst.health !== undefined && modelInst.maxHealth !== undefined && modelInst.health < modelInst.maxHealth && modelInst.health > 0) {
              const lastRegen = modelCooldownsRef.current.get(modelInst.id + "_regen") || 0;
              if (nowTimeMs - lastRegen >= 1000) {
                 modelCooldownsRef.current.set(modelInst.id + "_regen", nowTimeMs);
                 const healAmount = Math.min(modelInst.aiRegenRate, modelInst.maxHealth - modelInst.health);
                 if (onUpdatePart) {
                   onUpdatePart({ ...modelInst, health: modelInst.health + healAmount });
                 }
                 // Floating text for regen
                 activeFloatingIndicatorsRef.current.push({
                   id: "regen_" + Math.random().toString(36).substring(2, 9),
                   x: mPos.x,
                   y: mPos.y + 2.5,
                   z: mPos.z,
                   text: \`+\${healAmount}\`,
                   color: "#10b981",
                   createdAt: performance.now(),
                 });
              }
          }

          if (behaviors.length > 0) {
            // Process configured behaviors (up to 3)
            behaviors.forEach((b: any) => {`;

code = code.replace(targetStr, replaceStr);
fs.writeFileSync('src/components/Viewport.tsx', code);
