const fs = require('fs');
let code = fs.readFileSync('src/components/Viewport.tsx', 'utf-8');

const targetStr = `          // Inject advanced scriptable flat properties
          let activeAiMode = modelInst.aiMode;`;

const replaceStr = `          // Inject advanced scriptable flat properties
          let activeAiMode = modelInst.aiMode;
          
          // ADVANCED SENSORY OVERRIDES (Threat & Damage Detection)
          const visionRange = modelInst.aiVisionRange ?? 60;
          const hearingRange = modelInst.aiHearingRange ?? 30;
          const isAwareOfPlayer = (() => {
             if (dist < hearingRange) return true;
             if (dist > visionRange) return false;
             const playerAngle = Math.atan2(dx, dz) * (180 / Math.PI);
             const viewDiff = Math.abs((playerAngle - mainPart.rotation.y + 360 + 180) % 360 - 180);
             return viewDiff <= (modelInst.aiFieldOfView ?? 160) / 2;
          })();
          
          const isPlayerArmed = (() => {
             const slot = equippedSlotRef.current;
             const items = starterPackItemsRef.current;
             if (slot !== null && items && items[slot]) {
               const item = items[slot].originalPart;
               if (item.projectileConfig?.enabled || item.aiDamage || item.name.toLowerCase().includes("sword") || item.name.toLowerCase().includes("gun")) {
                 return true;
               }
             }
             return false;
          })();
          
          const isTakingDamage = modelInst.health !== undefined && modelInst.maxHealth !== undefined && modelInst.health < modelInst.maxHealth * 0.99;
          
          if (isTakingDamage && modelInst.aiReactionToDamage && modelInst.aiReactionToDamage !== 'Retaliate') {
              if (modelInst.aiReactionToDamage === 'Flee') activeAiMode = 'Flee';
              else if (modelInst.aiReactionToDamage === 'Panic') activeAiMode = 'Wander'; // erratically wander
              else if (modelInst.aiReactionToDamage === 'Enrage') activeAiMode = 'Attack';
          } else if (isAwareOfPlayer && isPlayerArmed && modelInst.aiReactionToThreat && modelInst.aiReactionToThreat !== 'Ignore') {
              if (modelInst.aiReactionToThreat === 'Flee') activeAiMode = 'Flee';
              else if (modelInst.aiReactionToThreat === 'Attack') activeAiMode = 'Attack';
              else if (modelInst.aiReactionToThreat === 'Cower') activeAiMode = 'Idle';
          }
`;

code = code.replace(targetStr, replaceStr);
fs.writeFileSync('src/components/Viewport.tsx', code);
