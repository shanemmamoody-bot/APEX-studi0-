const fs = require('fs');
let code = fs.readFileSync('src/components/NpcChatOverlay.tsx', 'utf-8');

const apiCall = `        body: JSON.stringify({
          npcName: npc.npcName || 'NPC',
          npcPrompt: npc.npcPrompt || 'You are a helpful NPC.',
          playerName: currentUser?.username || 'Player',
          history: newHistory
        })`;

const newApiCall = `        body: JSON.stringify({
          npcName: npc.npcName || 'NPC',
          npcPrompt: npc.npcPrompt || 'You are a helpful NPC.',
          playerName: currentUser?.username || 'Player',
          history: newHistory,
          npcHealth: npc.health,
          npcMaxHealth: npc.maxHealth,
          aiMode: npc.aiMode,
          environmentInfo: "Current environment: " + (npc.health < (npc.maxHealth || 100) * 0.3 ? "You are heavily injured! " : "You are healthy.")
        })`;

code = code.replace(apiCall, newApiCall);
fs.writeFileSync('src/components/NpcChatOverlay.tsx', code);
