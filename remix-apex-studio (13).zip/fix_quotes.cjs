const fs = require('fs');
let code = fs.readFileSync('src/server/adex/modelInstructions.ts', 'utf-8');

code = code.replace(/1\. \*\*Interactive UIs\*\*: \`local/g, '1. **Interactive UIs**: \\`local');
code = code.replace(/end\)\`/g, 'end)\\`');
code = code.replace(/2\. \*\*Touch Events\*\*: \`local/g, '2. **Touch Events**: \\`local');
code = code.replace(/3\. \*\*Advanced VFX\*\*: \`Instance/g, '3. **Advanced VFX**: \\`Instance');
code = code.replace(/("Explosion")\`, \`/g, '("Explosion")\\`, \\`');
code = code.replace(/("ParticleEmitter")\`, \`/g, '("ParticleEmitter")\\`, \\`');
code = code.replace(/("Fire")\`, \`/g, '("Fire")\\`, \\`');
code = code.replace(/("Sparkles")\`/g, '("Sparkles")\\`');
code = code.replace(/4\. \*\*Audio\*\*: \`local/g, '4. **Audio**: \\`local');
code = code.replace(/:Play\(\)\`/g, ':Play()\\`');
code = code.replace(/5\. \*\*Services\*\*: \`QuestService\`, \`/g, '5. **Services**: \\`QuestService\\`, \\`');
code = code.replace(/RatingService\`, \`/g, 'RatingService\\`, \\`');
code = code.replace(/HappinessService\`, \`/g, 'HappinessService\\`, \\`');
code = code.replace(/DataStoreService\`, \`/g, 'DataStoreService\\`, \\`');
code = code.replace(/TweenService\`, \`/g, 'TweenService\\`, \\`');
code = code.replace(/GamepassService\`, \`/g, 'GamepassService\\`, \\`');
code = code.replace(/SoundService\`, \`/g, 'SoundService\\`, \\`');
code = code.replace(/HttpService\`\./g, 'HttpService\\`.');

fs.writeFileSync('src/server/adex/modelInstructions.ts', code);
