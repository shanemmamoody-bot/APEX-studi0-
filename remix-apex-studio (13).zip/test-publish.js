fetch("http://localhost:3000/api/publish", {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({
    creator: "testuser",
    title: "Test UI Game",
    guiObjects: [
      { id: "gui-1", className: "ScreenGui", visible: true },
      { id: "gui-2", parentId: "gui-1", className: "Frame", visible: true, size: { scaleX: 0.5, scaleY: 0.5 } }
    ]
  })
}).then(r => r.json()).then(console.log);
