const fs = require('fs');
let code = fs.readFileSync('src/components/Viewport.tsx', 'utf-8');

const targetStr = `  const [equippedSlot, setEquippedSlot] = useState<number | null>(() =>
    starterPackItems.length > 0 ? 0 : null,
  );`;

const replaceStr = `  const [equippedSlot, setEquippedSlot] = useState<number | null>(() =>
    starterPackItems.length > 0 ? 0 : null,
  );
  const equippedSlotRef = useRef<number | null>(equippedSlot);
  const starterPackItemsRef = useRef(starterPackItems);
  useEffect(() => { equippedSlotRef.current = equippedSlot; }, [equippedSlot]);
  useEffect(() => { starterPackItemsRef.current = starterPackItems; }, [starterPackItems]);`;

code = code.replace(targetStr, replaceStr);
fs.writeFileSync('src/components/Viewport.tsx', code);
