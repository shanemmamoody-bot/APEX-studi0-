const fs = require('fs');

const gunScript = `local Players = game:GetService("Players")
local DataStore = game:GetService("DataStoreService")
local store = DataStore:GetStore("GunGameData")

local GUNS = {
    { id = "Pistol", name = "Pistol", damage = 25, price = 0, fireRate = 0.5, speed = 80, color = "gray", size = Vector3.new(0.4, 0.4, 1.2) },
    { id = "SMG", name = "SMG", damage = 15, price = 250, fireRate = 0.15, speed = 100, color = "black", size = Vector3.new(0.5, 0.5, 1.5) },
    { id = "Rifle", name = "Rifle", damage = 40, price = 750, fireRate = 0.25, speed = 150, color = "brown", size = Vector3.new(0.5, 0.6, 2.5) },
    { id = "Shotgun", name = "Shotgun", damage = 80, price = 1200, fireRate = 1.0, speed = 90, color = "darkgray", size = Vector3.new(0.6, 0.6, 2.2) }
}

-- Spawn some zombies continuously
task.spawn(function()
    while true do
        local zcount = 0
        for _, p in ipairs(workspace:GetChildren()) do
            if p.Name == "ZombieNPC" then zcount = zcount + 1 end
        end
        if zcount < 10 then
            local px = math.random(-80, 80)
            local pz = math.random(-80, 80)
            local z = Instance.new("Part")
            z.Name = "ZombieNPC"
            z.Size = Vector3.new(4, 6, 4)
            z.Position = Vector3.new(px, 3, pz)
            z.Color = "green"
            z.Anchored = false
            z.Parent = workspace
            
            local hum = Instance.new("Humanoid")
            hum.Parent = z
            hum.MaxHealth = 50
            hum.Health = 50
            
            -- Basic wander
            z.AssemblyLinearVelocity = Vector3.new(math.random(-5, 5), 0, math.random(-5, 5))
        end
        task.wait(2)
    end
end)

local function giveGun(player, gunData)
    local bp = player:FindFirstChild("Backpack")
    if not bp then return end
    
    -- Remove old gun if same type
    for _, t in ipairs(bp:GetChildren()) do
        if t.Name == gunData.name then t:Destroy() end
    end
    for _, t in ipairs(player.Character:GetChildren()) do
        if t.Name == gunData.name then t:Destroy() end
    end
    
    local tool = Instance.new("Tool")
    tool.Name = gunData.name
    
    local handle = Instance.new("Part")
    handle.Name = "Handle"
    handle.Size = gunData.size
    handle.Color = gunData.color
    handle.CanCollide = false
    handle.Parent = tool
    
    tool.Parent = bp
    
    local lastFire = 0
    
    tool.Activated:Connect(function()
        local now = os.clock()
        if now - lastFire < gunData.fireRate then return end
        lastFire = now
        
        local char = player.Character
        if not char then return end
        local hrp = char:FindFirstChild("HumanoidRootPart")
        if not hrp then return end
        
        local bullet = Instance.new("Part")
        bullet.Name = "Bullet"
        bullet.Size = Vector3.new(0.5, 0.5, 1.5)
        bullet.Color = "yellow"
        bullet.Material = "neon"
        -- We will shoot generally forward relative to world -Z for now
        bullet.Position = hrp.Position + Vector3.new(0, 0, -3)
        bullet.CanCollide = true
        bullet.Anchored = false
        bullet.Parent = workspace
        
        bullet.AssemblyLinearVelocity = Vector3.new(0, 0, -gunData.speed)
        
        task.delay(2, function()
            if bullet and bullet.Parent then bullet:Destroy() end
        end)
        
        local hasHit = false
        local hitConn = nil
        hitConn = bullet.Touched:Connect(function(hit)
            if hasHit then return end
            if hit:IsDescendantOf(char) or hit.Name == "Bullet" or hit.Name == "Handle" or hit.Parent == tool then return end
            
            local hitHum = hit.Parent and hit.Parent:FindFirstChild("Humanoid")
            if hitHum then
                hasHit = true
                hitHum:TakeDamage(gunData.damage)
                if hitHum.Health <= 0 then
                    local cash = player:FindFirstChild("Cash")
                    if cash then cash.Value = cash.Value + 10 end
                    if hit.Parent and hit.Parent.Name == "ZombieNPC" then
                        hit.Parent:Destroy()
                    end
                end
                bullet:Destroy()
                if hitConn then hitConn:Disconnect() end
            elseif hit.Name ~= "Baseplate" and hit.CanCollide then
                hasHit = true
                bullet:Destroy()
                if hitConn then hitConn:Disconnect() end
            end
        end)
    end)
end

Players.PlayerAdded:Connect(function(player)
    local saved = store:GetAsync(player.Name .. "_Save") or {}
    
    local cash = Instance.new("NumberValue")
    cash.Name = "Cash"
    cash.Value = saved.cash or 0
    cash.Parent = player
    
    local ownedGuns = saved.ownedGuns or { Pistol = true }
    
    local function save()
        store:SetAsync(player.Name .. "_Save", {
            cash = cash.Value,
            ownedGuns = ownedGuns
        })
    end
    
    -- UI
    local function createShop()
        local gui = player:FindFirstChild("PlayerGui")
        if not gui then
            gui = Instance.new("Folder")
            gui.Name = "PlayerGui"
            gui.Parent = player
        end
        
        local screen = gui:FindFirstChild("GunUI")
        if not screen then
            screen = Instance.new("ScreenGui")
            screen.Name = "GunUI"
            screen.Parent = gui
            
            local topBar = Instance.new("TextLabel")
            topBar.Name = "TopBar"
            topBar.Size = UDim2.new(1, 0, 0, 40)
            topBar.Position = UDim2.new(0, 0, 0, 0)
            topBar.BackgroundColor3 = Color3.new(0.1, 0.1, 0.1)
            topBar.TextColor3 = Color3.new(1, 0.8, 0)
            topBar.TextSize = 20
            topBar.Parent = screen
            
            local shopBtn = Instance.new("TextButton")
            shopBtn.Name = "ShopBtn"
            shopBtn.Size = UDim2.new(0, 150, 0, 40)
            shopBtn.Position = UDim2.new(0, 10, 0, 50)
            shopBtn.BackgroundColor3 = Color3.new(0.2, 0.6, 0.2)
            shopBtn.TextColor3 = Color3.new(1, 1, 1)
            shopBtn.Text = "OPEN SHOP"
            shopBtn.Parent = screen
            
            local shopFrame = Instance.new("Frame")
            shopFrame.Name = "ShopFrame"
            shopFrame.Size = UDim2.new(0, 400, 0, 300)
            shopFrame.Position = UDim2.new(0.5, -200, 0.5, -150)
            shopFrame.BackgroundColor3 = Color3.new(0.15, 0.15, 0.2)
            shopFrame.Visible = false
            shopFrame.Parent = screen
            
            shopBtn.MouseButton1Click:Connect(function()
                shopFrame.Visible = not shopFrame.Visible
            end)
            
            -- Populate shop
            for i, gun in ipairs(GUNS) do
                local item = Instance.new("Frame")
                item.Size = UDim2.new(1, -20, 0, 50)
                item.Position = UDim2.new(0, 10, 0, 10 + (i-1)*60)
                item.BackgroundColor3 = Color3.new(0.25, 0.25, 0.3)
                item.Parent = shopFrame
                
                local nameLbl = Instance.new("TextLabel")
                nameLbl.Size = UDim2.new(0, 150, 1, 0)
                nameLbl.Position = UDim2.new(0, 10, 0, 0)
                nameLbl.BackgroundTransparency = 1
                nameLbl.TextColor3 = Color3.new(1, 1, 1)
                nameLbl.Text = gun.name
                nameLbl.Parent = item
                
                local actionBtn = Instance.new("TextButton")
                actionBtn.Size = UDim2.new(0, 100, 0, 30)
                actionBtn.Position = UDim2.new(1, -110, 0, 10)
                actionBtn.BackgroundColor3 = Color3.new(0, 0.5, 0.8)
                actionBtn.TextColor3 = Color3.new(1, 1, 1)
                actionBtn.Parent = item
                
                local function updateBtn()
                    if ownedGuns[gun.id] then
                        actionBtn.Text = "EQUIP"
                        actionBtn.BackgroundColor3 = Color3.new(0.2, 0.5, 0.2)
                    else
                        actionBtn.Text = "BUY: " .. tostring(gun.price)
                        actionBtn.BackgroundColor3 = Color3.new(0.8, 0.4, 0)
                    end
                end
                updateBtn()
                
                actionBtn.MouseButton1Click:Connect(function()
                    if ownedGuns[gun.id] then
                        giveGun(player, gun)
                        shopFrame.Visible = false
                    else
                        if cash.Value >= gun.price then
                            cash.Value = cash.Value - gun.price
                            ownedGuns[gun.id] = true
                            save()
                            updateBtn()
                            giveGun(player, gun)
                        end
                    end
                end)
            end
        end
        
        local topBar = screen:FindFirstChild("TopBar")
        if topBar then
            topBar.Text = " 💰 Coins: " .. tostring(cash.Value) .. " | Defeat zombies to earn coins!"
        end
    end
    
    cash.Changed:Connect(createShop)
    createShop()
    
    player.CharacterAdded:Connect(function(char)
        giveGun(player, GUNS[1]) -- Give pistol on spawn
        createShop()
    end)
end)

Players.PlayerRemoving:Connect(function(player)
    local cash = player:FindFirstChild("Cash")
    if cash then
        local saved = store:GetAsync(player.Name .. "_Save") or {}
        saved.cash = cash.Value
        store:SetAsync(player.Name .. "_Save", saved)
    end
end)`;

fs.writeFileSync('gun_script.lua', gunScript);
