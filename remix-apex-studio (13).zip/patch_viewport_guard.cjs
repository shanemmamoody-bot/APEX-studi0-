const fs = require('fs');
let code = fs.readFileSync('src/components/Viewport.tsx', 'utf-8');

const targetStr = `          } else if (modelInst.aiMode === 'Wander') {
            behaviors.push({ type: 'Wander', speed: modelInst.aiWalkSpeed ?? 16, wanderDistance: modelInst.aiPatrolRadius ?? 15 });
          } else if (modelInst.aiMode === 'Flee') {`;

const replaceStr = `          } else if (modelInst.aiMode === 'Wander') {
            behaviors.push({ type: 'Wander', speed: modelInst.aiWalkSpeed ?? 16, wanderDistance: modelInst.aiPatrolRadius ?? 15 });
          } else if (modelInst.aiMode === 'Guard') {
            behaviors.push({ type: 'Guard Area', speed: modelInst.aiWalkSpeed ?? 16, guardRadius: modelInst.aiPatrolRadius ?? 12 });
          } else if (modelInst.aiMode === 'Flee') {`;

code = code.replace(targetStr, replaceStr);
fs.writeFileSync('src/components/Viewport.tsx', code);
