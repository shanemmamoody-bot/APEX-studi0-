const fact = {
    subject: 'my game speed',
    relationship: 'is',
    object: '19'
};
const cleanQuery = 'what is my game speed';
const s = fact.subject.toLowerCase();
if (cleanQuery.match(new RegExp(`^(what|who|where)\\s+(is|are)\\s+(the\\s+)?${s}`, 'i')) || cleanQuery === s || cleanQuery.includes(`${s} name`)) {
    const rel = fact.relationship.toLowerCase().startsWith('is') || fact.relationship.toLowerCase().startsWith('was') || fact.relationship.toLowerCase().startsWith('are') ? fact.relationship : 'is ' + fact.relationship;
    let ans = `${fact.subject} ${rel} ${fact.object}.`; 
    console.log(ans.charAt(0).toUpperCase() + ans.slice(1));
}
