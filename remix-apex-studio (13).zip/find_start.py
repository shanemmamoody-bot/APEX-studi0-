with open('server.ts', 'r') as f:
    lines = f.readlines()

depth = 0
start_idx = 4238 - 1
start_depth = 0
found_start = False
for i in range(len(lines)):
    line = lines[i]
    for char in line:
        if char == '{':
            depth += 1
            if i == start_idx:
                start_depth = depth
                found_start = True
        elif char == '}':
            depth -= 1
            if found_start and depth == start_depth - 1:
                print("start() closes at line:", i+1)
                break
    if found_start and depth == start_depth - 1:
        break
