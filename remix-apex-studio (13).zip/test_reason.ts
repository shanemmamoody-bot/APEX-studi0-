import { ReasoningEngine } from "./src/server/adex/adex3Engine";
import { LearnedKnowledge } from "./src/server/adex/nlpBrain";

const db = LearnedKnowledge.getDb();
LearnedKnowledge.ensureKB(db);
console.log(ReasoningEngine.solve("spell dog", db));
console.log(ReasoningEngine.solve("what year was after 2011", db));
