const fs = require('fs');
let code = fs.readFileSync('src/types.ts', 'utf-8');

code = code.replace(
  "  aiJumpPower?: number;\\n  aiCanClimb?: boolean;`",
  `  aiJumpPower?: number;
  aiCanClimb?: boolean;
  
  // --- 40 ADVANCED BLUEPRINT AI SYSTEMS ---
  aiCanJump?: boolean;
  aiCanSwim?: boolean;
  aiAvoidWater?: boolean;
  aiAvoidFire?: boolean;
  aiTargetPriority?: 'Player' | 'Nearest' | 'Weakest' | 'Random';
  aiRegenRate?: number;
  aiRegenDelay?: number;
  aiRoamRadius?: number;
  aiRoamDelay?: number;
  aiFollowOffsetX?: number;
  aiFollowOffsetY?: number;
  aiFollowOffsetZ?: number;
  aiLootDropChance?: number;
  aiLootDropAmount?: number;
  aiIsBoss?: boolean;
  aiBossMusicUrl?: string;
  aiSpawnOnDeathId?: string;
  aiSpawnCount?: number;
  aiDamageType?: 'Physical' | 'Magical' | 'Fire' | 'Poison' | 'Ice';
  aiArmorRating?: number;
  aiMagicResist?: number;
  aiFireResist?: number;
  aiPoisonResist?: number;
  aiIceResist?: number;
  aiImmuneToCC?: boolean;
  aiKnockbackResist?: number;
  aiKnockbackPower?: number;
  aiAttackRange?: number;
  aiAttackAngle?: number;
  aiAttackCooldown?: number;
  aiAttackWindup?: number;
  aiProjectileId?: string;
  aiProjectileSpeed?: number;
  aiFlySpeed?: number;
  aiHoverHeight?: number;
  aiIsFlying?: boolean;
  aiVocalizeInterval?: number;
  aiDeathSoundUrl?: string;
  aiAggroSoundUrl?: string;
  aiCanOpenDoors?: boolean;\``
);

fs.writeFileSync('src/types.ts', code);
