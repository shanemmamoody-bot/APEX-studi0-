const fs = require('fs');
let code = fs.readFileSync('src/components/Viewport.tsx', 'utf-8');

code = code.replace(
  "  CreatureType,\n} from \"../utils/creatureAiEngine\";",
  "  CreatureType,\n  dispatchCreatureAiEvent\n} from \"../utils/creatureAiEngine\";"
);

fs.writeFileSync('src/components/Viewport.tsx', code);
