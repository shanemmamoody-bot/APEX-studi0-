const assert = require('assert');
let a = 1;
assert(a === 1);
