const fs = require('fs');
let content = fs.readFileSync('src/server/adex/adex3Engine.ts', 'utf-8');
const fcStart = content.indexOf('static findConceptFuzzy(query: string, db: any)');
console.log(content.substring(fcStart, fcStart + 1000));
