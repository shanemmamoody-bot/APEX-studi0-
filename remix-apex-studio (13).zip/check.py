with open('server.ts', 'r') as f:
    content = f.read()

# remove string literals and comments to accurately count braces
import re
# remove string literals (simplistic)
s = re.sub(r'".*?"|\'.*?\'|`.*?`', '', content, flags=re.DOTALL)
# remove single line comments
s = re.sub(r'//.*', '', s)
# remove multi line comments
s = re.sub(r'/\*.*?\*/', '', s, flags=re.DOTALL)

depth = 0
for i, char in enumerate(s):
    if char == '{':
        depth += 1
    elif char == '}':
        depth -= 1
        if depth < 0:
            print("Unbalanced at line:", content[:i].count('\n') + 1)
            break
print("Final depth:", depth)
