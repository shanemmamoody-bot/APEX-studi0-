const fs = require('fs');
const db = JSON.parse(fs.readFileSync('./adex_db.json', 'utf8'));
const rules = db.knowledgeBase.rules.filter(r => r.category === 'fact_structured');
const cleanQuery = "remember my game speed is 19";

for (const fact of rules) {
    const s = fact.subject.toLowerCase();
    
    if (cleanQuery.match(new RegExp(`^(what|who|where)\\s+(is|are)\\s+(the\\s+)?${s}(?:\\s|$)`, 'i')) || cleanQuery === s || cleanQuery.includes(`${s} name`)) {
        console.log("Matched 1 on:", s);
    }
    const relWords = fact.relationship.toLowerCase().replace(/^(is|was|are|the|a|an|of)\s+/g, '').replace(/\s+(of|in|to|for)$/g, '').trim().split(' ');
    let hasRelWord = false;
    for (const w of relWords) {
        if (w.length > 2 && cleanQuery.includes(w)) {
            hasRelWord = true;
            break;
        }
    }
    if (cleanQuery.includes(s) && hasRelWord) {
        console.log("Matched 2 on:", s);
    }
}
