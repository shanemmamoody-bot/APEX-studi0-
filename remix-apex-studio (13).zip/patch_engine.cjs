const fs = require('fs');
let code = fs.readFileSync('src/utils/luaEngine.ts', 'utf-8');

const triggerExplosionCode = `
    lua.lua_pushjsfunction(this.L, (LState: any) => {
      const x = lua.lua_tonumber(LState, 1);
      const y = lua.lua_tonumber(LState, 2);
      const z = lua.lua_tonumber(LState, 3);
      const radius = lua.lua_tonumber(LState, 4);
      const damage = lua.lua_tonumber(LState, 5);
      
      try {
        if (typeof window !== 'undefined') {
          const event = new CustomEvent("apex:model_explode", {
            detail: {
              x, y, z,
              radius: radius || 10,
              damage: damage || 50
            }
          });
          window.dispatchEvent(event);
        }
      } catch(e) {
        console.error('Failed to trigger explosion:', e);
      }
      return 0;
    });
    lua.lua_setglobal(this.L, to_luastring('__js_triggerExplosion_raw'));
`;

// Inject into luaEngine before '__js_updateGui_raw'
code = code.replace(/    \/\/ 6\. GUI update bridge/, match => triggerExplosionCode + '\n' + match);

fs.writeFileSync('src/utils/luaEngine.ts', code);
