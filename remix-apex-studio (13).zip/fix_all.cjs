const fs = require('fs');
let code = fs.readFileSync('src/server/adex/modelInstructions.ts', 'utf-8');
const lines = code.split('\n');

for (let i = 0; i < lines.length; i++) {
  if (lines[i].includes('1. **Interactive UIs**')) {
    lines[i] = '1. **Interactive UIs**: \\`local btn = Instance.new("TextButton") btn.MouseButton1Click:Connect(function() print("Clicked!") end)\\`';
  }
  if (lines[i].includes('2. **Touch Events**')) {
    lines[i] = '2. **Touch Events**: \\`local part = Instance.new("Part") part.Touched:Connect(function(hit) print(hit.Name) end)\\`';
  }
  if (lines[i].includes('4. **Audio**')) {
    lines[i] = '4. **Audio**: \\`local s = Instance.new("Sound") s.SoundId = "Explosion" s:Play()\\`';
  }
}

fs.writeFileSync('src/server/adex/modelInstructions.ts', lines.join('\n'));
