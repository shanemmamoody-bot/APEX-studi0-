const fs = require('fs');
let code = fs.readFileSync('src/components/NpcChatOverlay.tsx', 'utf-8');

const targetStr = `      const data = await response.json();
      if (data.reply) {
        setMessages([...newHistory, { role: 'npc', text: data.reply }]);
      } else {
        setMessages([...newHistory, { role: 'system', text: "Error: No response from NPC." }]);
      }`;

const replaceStr = `      const data = await response.json();
      if (data.reply) {
        setMessages([...newHistory, { role: 'npc', text: data.reply }]);
        if (data.action) {
          window.dispatchEvent(new CustomEvent('UPDATE_NPC_STATE', { detail: { id: npc.id, mode: data.action } }));
          setTimeout(() => {
            setMessages(prev => [...prev, { role: 'system', text: \`[System] NPC changed mode to \${data.action}\` }]);
          }, 500);
        }
      } else {
        setMessages([...newHistory, { role: 'system', text: "Error: No response from NPC." }]);
      }`;

code = code.replace(targetStr, replaceStr);
fs.writeFileSync('src/components/NpcChatOverlay.tsx', code);
