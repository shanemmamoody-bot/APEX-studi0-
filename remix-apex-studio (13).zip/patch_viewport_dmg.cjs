const fs = require('fs');
let code = fs.readFileSync('src/components/Viewport.tsx', 'utf-8');

code = code.replace(
  "                    const prevHp = playerHealthRef.current;",
  "                    const prevHp = playerHealthRef.current;\n                    dispatchCreatureAiEvent(modelInst.id, 'onAttack');"
);

code = code.replace(
  "                    const nextHp = Math.min(100, playerHealthRef.current + healAmt);",
  "                    const nextHp = Math.min(100, playerHealthRef.current + healAmt);\n                    dispatchCreatureAiEvent(modelInst.id, 'onHeal');"
);

fs.writeFileSync('src/components/Viewport.tsx', code);
