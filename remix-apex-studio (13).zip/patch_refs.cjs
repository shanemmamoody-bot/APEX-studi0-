const fs = require('fs');
let code = fs.readFileSync('src/components/Viewport.tsx', 'utf-8');

code = code.replace(
  "  const creatureStatesRef = useRef<Map<string, CreatureRuntimeState>>(new Map());",
  "  const creatureStatesRef = useRef<Map<string, CreatureRuntimeState>>(new Map());\n  const modelLastAiModeRef = useRef<Map<string, string>>(new Map());"
);

code = code.replace(
  "      creatureStatesRef.current.clear();",
  "      creatureStatesRef.current.clear();\n      modelLastAiModeRef.current.clear();"
);

fs.writeFileSync('src/components/Viewport.tsx', code);
