const fs = require('fs');
let code = fs.readFileSync('src/server/aiChatServer.ts', 'utf8');

const targetCatch = `  } catch (err: any) {
    console.error("AI Chat Error:", err);
    // If Gemini fails, fallback gracefully (important for preview env if keys are missing)
    const fallbackReply = "I am currently disconnected from my core logic servers and unable to generate a detailed response. Please try again later.";
    chat.messages.push({ role: 'model', content: fallbackReply });
    saveChatData();
    res.json({ reply: fallbackReply });
  }`;

const replaceCatch = `  } catch (err: any) {
    console.error("AI Chat Error:", err);
    let fallbackReply = "I am currently disconnected from my core logic servers and unable to generate a detailed response. Please try again later.";
    if (err.message && (err.message.includes('API_KEY_INVALID') || err.message.includes('API key not valid'))) {
      fallbackReply = "API key not valid. Please configure a valid GEMINI_API_KEY in your app settings.";
    } else if (err.message && err.message.includes('environment variable is missing')) {
      fallbackReply = "GEMINI_API_KEY is missing. Please configure it in your app settings.";
    }
    chat.messages.push({ role: 'model', content: fallbackReply });
    saveChatData();
    res.json({ reply: fallbackReply });
  }`;

// The second catch block might not have the "// If Gemini fails..." comment exactly, let's just use regex for both catch blocks

code = code.replace(/\} catch \(err: any\) \{[\s\S]*?res\.json\(\{ reply: fallbackReply \}\);\n  \}/g, replaceCatch);

fs.writeFileSync('src/server/aiChatServer.ts', code);
console.log("Updated catch blocks.");
