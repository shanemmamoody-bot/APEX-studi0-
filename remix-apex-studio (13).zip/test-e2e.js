const fs = require('fs');

async function test() {
  const publishPayload = {
    creator: "testuser",
    title: "E2E UI Test",
    name: "E2E UI Test",
    workspace: [],
    scripts: [],
    guiObjects: [
      { id: "gui-screen", className: "ScreenGui", visible: true, position: { scaleX:0, offsetX:0, scaleY:0, offsetY:0 }, size: { scaleX:1, offsetX:0, scaleY:1, offsetY:0 } },
      { id: "gui-btn", parentId: "gui-screen", className: "TextButton", visible: true, text: "Click Me", position: { scaleX:0.5, offsetX:0, scaleY:0.5, offsetY:0 }, size: { scaleX:0.2, offsetX:0, scaleY:0.1, offsetY:0 } }
    ]
  };

  const pubRes = await fetch("http://localhost:3000/api/publish", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(publishPayload)
  });
  const pubData = await pubRes.json();
  console.log("Published game:", pubData.id);

  const gamesRes = await fetch("http://localhost:3000/api/games");
  const games = await gamesRes.json();
  const found = games.find(g => g.id === pubData.id);
  console.log("Fetched from API. Has guiObjects?", found?.guiObjects?.length > 0);
  console.log("guiObjects contents:", JSON.stringify(found?.guiObjects));
}
test();
