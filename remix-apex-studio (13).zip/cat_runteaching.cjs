const fs = require('fs');
let content = fs.readFileSync('src/server/adex/adex3Engine.ts', 'utf-8');
const runTeachingCycleStart = content.indexOf('static runTeachingCycle(db: any)');
console.log(content.substring(runTeachingCycleStart, runTeachingCycleStart + 2000));
