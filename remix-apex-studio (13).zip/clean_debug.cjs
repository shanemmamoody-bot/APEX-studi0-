const fs = require('fs');
const file = 'src/server/adex/adex3Engine.ts';
let content = fs.readFileSync(file, 'utf-8');

content = content.replace("console.log('[DEBUG] cleanQuery:', cleanQuery, '| query:', query);", "");
content = content.replace("console.log('[DEBUG-FACT]', s, 'regex:', `^(what|who|where)\\\\s+(is|are)\\\\s+(the\\\\s+)?${s}`, 'match:', cleanQuery.match(new RegExp(`^(what|who|where)\\\\s+(is|are)\\\\s+(the\\\\s+)?${s}`, 'i')));", "");

fs.writeFileSync(file, content);
