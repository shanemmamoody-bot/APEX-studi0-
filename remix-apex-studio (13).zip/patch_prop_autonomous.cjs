const fs = require('fs');
let code = fs.readFileSync('src/components/PropertiesPanel.tsx', 'utf-8');

const aiModeSelectTarget = `<option value="Wander">Wander (Random Path)</option>
                        <option value="Guard">Guard Area</option>
                        <option value="Flee">Flee Player</option>
                        <option value="Attack">Aggressive / Attack</option>
                      </select>`;

const aiModeSelectReplace = `<option value="Wander">Wander (Random Path)</option>
                        <option value="Guard">Guard Area</option>
                        <option value="Flee">Flee Player</option>
                        <option value="Attack">Aggressive / Attack</option>
                        <option value="Autonomous">Autonomous (Smart State Machine)</option>
                      </select>`;

code = code.replace(aiModeSelectTarget, aiModeSelectReplace);
fs.writeFileSync('src/components/PropertiesPanel.tsx', code);
