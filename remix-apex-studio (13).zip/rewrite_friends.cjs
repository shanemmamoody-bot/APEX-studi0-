const fs = require('fs');
const file = 'src/components/FriendsAndMessagingModal.tsx';
let code = fs.readFileSync(file, 'utf8');

// Use string split and join instead of exact matching for large blocks
const startMatch = '<div className="flex bg-[#0A0A0C] p-1 rounded-xl border border-[#1E1E24]">';
const endMatch = '            </div>\n          </div>\n          <button';

const startIndex = code.indexOf(startMatch);
const endIndex = code.indexOf(endMatch, startIndex);

if (startIndex !== -1 && endIndex !== -1) {
    const newNav = `<div className="flex space-x-6 px-2">
              <button
                onClick={() => handleTabChange("friends")}
                className={\`py-3 text-sm font-bold transition-all flex items-center space-x-2 border-b-2 cursor-pointer \${
                  currentSubTab === "friends"
                    ? "border-[#3B82F6] text-white"
                    : "border-transparent text-gray-400 hover:text-gray-200"
                }\`}
              >
                <Users className="h-4 w-4" />
                <span>Friends ({actualFriends.length})</span>
              </button>
              <button
                onClick={() => handleTabChange("messages")}
                className={\`py-3 text-sm font-bold transition-all flex items-center space-x-2 border-b-2 cursor-pointer \${
                  currentSubTab === "messages"
                    ? "border-[#3B82F6] text-white"
                    : "border-transparent text-gray-400 hover:text-gray-200"
                }\`}
              >
                <MessageSquare className="h-4 w-4" />
                <span>Messages</span>
              </button>
              <button
                onClick={() => handleTabChange("requests")}
                className={\`py-3 text-sm font-bold transition-all flex items-center space-x-2 border-b-2 cursor-pointer \${
                  currentSubTab === "requests"
                    ? "border-amber-500 text-amber-500"
                    : "border-transparent text-gray-400 hover:text-gray-200"
                }\`}
              >
                <UserPlus className="h-4 w-4" />
                <span>Friend Requests</span>
                {pendingRequests.length > 0 && (
                  <span className="bg-rose-500 text-white font-black text-[10px] px-1.5 py-0.5 rounded-full ml-1">
                    {pendingRequests.length}
                  </span>
                )}
              </button>
`;
    code = code.substring(0, startIndex) + newNav + code.substring(endIndex);
    fs.writeFileSync(file, code);
    console.log("Nav replaced.");
} else {
    console.log("Could not find boundaries.");
}
