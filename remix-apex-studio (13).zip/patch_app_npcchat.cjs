const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf-8');

const effectTarget = `  useEffect(() => {
    window.addEventListener('resize', updateGridLines);`;

const effectReplace = `  useEffect(() => {
    const handleOpenNpcChat = (e: any) => {
      setActiveNpcChat(e.detail);
    };
    window.addEventListener('OPEN_NPC_CHAT', handleOpenNpcChat);
    return () => {
      window.removeEventListener('OPEN_NPC_CHAT', handleOpenNpcChat);
    };
  }, []);

  useEffect(() => {
    window.addEventListener('resize', updateGridLines);`;

code = code.replace(effectTarget, effectReplace);
fs.writeFileSync('src/App.tsx', code);
