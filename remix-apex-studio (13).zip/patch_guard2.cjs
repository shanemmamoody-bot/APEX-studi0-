const fs = require('fs');
let code = fs.readFileSync('src/components/Viewport.tsx', 'utf-8');

const targetStr = `              } else if (b.type === "Guard Area") {
                const guardRad = b.guardRadius || 12;
                const spd = b.speed || 4;
                const origin =
                  modelInitialPositionsRef.current.get(modelInst.id) || mPos;
                const playerDistToOrigin = Math.hypot(
                  curPlayerPos.x - origin.x,
                  curPlayerPos.z - origin.z,
                );
                if (playerDistToOrigin <= guardRad) {
                  // Player entered guarded territory: attack/pursue!
                  stepMoveRigid(curPlayerPos.x, curPlayerPos.z, spd, true);
                } else {
                  // Return to origin post
                  const modelDistToOrigin = Math.hypot(
                    mPos.x - origin.x,
                    mPos.z - origin.z,
                  );
                  if (modelDistToOrigin > 0.6) {
                    stepMoveRigid(origin.x, origin.z, spd * 0.8, true);
                  }
                }`;

const replaceStr = `              } else if (b.type === "Guard Area") {
                const guardRad = b.guardRadius || 12;
                const spd = b.speed || 4;
                const origin =
                  modelInitialPositionsRef.current.get(modelInst.id) || mPos;
                const playerDistToOrigin = Math.hypot(
                  curPlayerPos.x - origin.x,
                  curPlayerPos.z - origin.z,
                );

                // Vision & Hearing Check
                const playerAngle = Math.atan2(dx, dz) * (180 / Math.PI);
                const viewDiff = Math.abs((playerAngle - mainPart.rotation.y + 360 + 180) % 360 - 180);
                const isAware = viewDiff <= 75 || dist < 4; // 150 degree FOV or within 4 studs (hearing)

                if (playerDistToOrigin <= guardRad && isAware) {
                  // Player entered guarded territory and AI is aware: attack/pursue!
                  stepMoveRigid(curPlayerPos.x, curPlayerPos.z, spd, true);
                } else {
                  // Return to origin post and scan
                  const modelDistToOrigin = Math.hypot(
                    mPos.x - origin.x,
                    mPos.z - origin.z,
                  );
                  if (modelDistToOrigin > 0.6) {
                    stepMoveRigid(origin.x, origin.z, spd * 0.8, true);
                  } else {
                    // Scan environment by slowly turning
                    mainPart.rotation.y += 0.5;
                  }
                }`;

code = code.replace(targetStr, replaceStr);
fs.writeFileSync('src/components/Viewport.tsx', code);
