const fs = require('fs');
const content = fs.readFileSync('src/server/adex/adex3Engine.ts', 'utf8');
const lines = content.split('\n');
let depth = 0;
for(let i = 796; i < 905; i++) {
    const line = lines[i];
    depth += (line.match(/\{/g) || []).length;
    depth -= (line.match(/\}/g) || []).length;
    if (depth === 1 && line.trim().startsWith('if')) console.log("If at line", i+1);
    if (depth === 1 && line.trim().startsWith('}')) console.log("End block at line", i+1);
}
