const fs = require('fs');

let oldPhysics = fs.readFileSync('old_physics.txt', 'utf-8');
let newPhysics = fs.readFileSync('extract_patched.ts', 'utf-8');

let viewport = fs.readFileSync('src/components/Viewport.tsx', 'utf-8');

// The original file ends with requestAnimationFrame(physicsLoop);\n    };\n    const animId = requestAnimationFrame(physicsLoop);\n
// Let's locate the exact string bounds of oldPhysics in viewport.

// Because formatting might be slightly different or requestAnimationFrame part was omitted from old_physics.txt end, let's do a substring replace.

const searchStart = "    const physicsLoop = () => {\n      if (!isMounted || !isTesting) return;";
const searchEnd = "      requestAnimationFrame(physicsLoop);\n    };\n\n    const animId = requestAnimationFrame(physicsLoop);";

const startIdx = viewport.indexOf(searchStart);
if (startIdx === -1) throw new Error("Could not find start");

// Find end of physicsLoop function
let endIdx = viewport.indexOf(searchEnd, startIdx);
if (endIdx === -1) throw new Error("Could not find end");

// We need to replace everything from startIdx to endIdx (exclusive of requestAnimationFrame call outside the function)
// Actually newPhysics HAS `requestAnimationFrame(physicsLoop);\n    };` at the end since we added `};`.

const originalFragment = viewport.substring(startIdx, endIdx + searchEnd.indexOf("    };\n") + 7);

viewport = viewport.replace(originalFragment, newPhysics);

fs.writeFileSync('src/components/Viewport.tsx', viewport);
console.log("Replaced successfully!");
