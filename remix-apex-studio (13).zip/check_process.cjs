const fs = require('fs');
let content = fs.readFileSync('src/server/adex/adex3Engine.ts', 'utf-8');
const pStart = content.indexOf('// SYSTEM 2 Check: Can the Reasoning Engine solve this?');
console.log(content.substring(pStart, pStart + 1000));
