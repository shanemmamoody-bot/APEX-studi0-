const fs = require('fs');
let code = fs.readFileSync('src/components/PropertiesPanel.tsx', 'utf-8');

const targetStr = `                    {/* Patrol Distance */}
                    {(selectedPart.aiMode === 'Patrol' || selectedPart.aiMode === 'Wander' || selectedPart.aiMode === 'Guard') && (
                      <div className="flex items-center justify-between gap-2 text-gray-400">
                        <span className="shrink-0 font-medium text-xs">Distance/Radius</span>
                        <input
                          type="number"
                          value={selectedPart.aiPatrolRadius ?? 15}
                          onChange={(e) => handlePartChange("aiPatrolRadius", parseFloat(e.target.value) || 0)}
                          className="bg-[#0d0810] text-white border border-[#3b1119] rounded px-2 py-1 text-xs w-20 focus:outline-none focus:border-red-500"
                        />
                      </div>
                    )}`;

const replaceStr = targetStr + `
                    
                    <div className="pt-2 mt-2 border-t border-gray-800">
                      <span className="text-amber-500 font-bold text-xs block mb-2">ADVANCED SYSTEMS & BLUEPRINTS</span>
                      
                      {/* Reaction To Threat */}
                      <div className="space-y-1 mb-2">
                        <span className="text-gray-400 font-medium text-xs block">Reaction To Armed/Threat</span>
                        <select
                          value={selectedPart.aiReactionToThreat || 'Ignore'}
                          onChange={(e) => handlePartChange("aiReactionToThreat", e.target.value)}
                          className="bg-[#0d0810] text-white border border-[#3b1119] rounded px-2 py-1 text-xs w-full focus:outline-none focus:border-amber-500"
                        >
                          <option value="Ignore">Ignore</option>
                          <option value="Flee">Flee (Run Away)</option>
                          <option value="Attack">Attack (Aggro)</option>
                          <option value="Cower">Cower (Freeze)</option>
                          <option value="CallHelp">Call For Help</option>
                        </select>
                      </div>

                      {/* Reaction To Damage */}
                      <div className="space-y-1 mb-2">
                        <span className="text-gray-400 font-medium text-xs block">Reaction To Damage</span>
                        <select
                          value={selectedPart.aiReactionToDamage || 'Retaliate'}
                          onChange={(e) => handlePartChange("aiReactionToDamage", e.target.value)}
                          className="bg-[#0d0810] text-white border border-[#3b1119] rounded px-2 py-1 text-xs w-full focus:outline-none focus:border-amber-500"
                        >
                          <option value="Retaliate">Retaliate (Fight Back)</option>
                          <option value="Flee">Flee (Run Away)</option>
                          <option value="Enrage">Enrage (Damage Buff)</option>
                          <option value="Panic">Panic (Erratic)</option>
                          <option value="CallHelp">Call For Help</option>
                        </select>
                      </div>

                      {/* Combat Style */}
                      <div className="space-y-1 mb-2">
                        <span className="text-gray-400 font-medium text-xs block">Combat Style Blueprint</span>
                        <select
                          value={selectedPart.aiCombatStyle || 'Melee'}
                          onChange={(e) => handlePartChange("aiCombatStyle", e.target.value)}
                          className="bg-[#0d0810] text-white border border-[#3b1119] rounded px-2 py-1 text-xs w-full focus:outline-none focus:border-amber-500"
                        >
                          <option value="Melee">Direct Melee</option>
                          <option value="HitAndRun">Hit and Run</option>
                          <option value="Strafe">Strafe/Circle</option>
                          <option value="Charge">Charge (Bull rush)</option>
                        </select>
                      </div>

                      {/* Senses */}
                      <div className="flex items-center justify-between gap-2 text-gray-400 mb-1">
                        <span className="shrink-0 font-medium text-xs">Vision Range (Studs)</span>
                        <input
                          type="number"
                          value={selectedPart.aiVisionRange ?? 60}
                          onChange={(e) => handlePartChange("aiVisionRange", parseFloat(e.target.value) || 0)}
                          className="bg-[#0d0810] text-white border border-[#3b1119] rounded px-2 py-1 text-xs w-16 focus:outline-none focus:border-amber-500"
                        />
                      </div>
                      <div className="flex items-center justify-between gap-2 text-gray-400 mb-2">
                        <span className="shrink-0 font-medium text-xs">Hearing Range (Studs)</span>
                        <input
                          type="number"
                          value={selectedPart.aiHearingRange ?? 30}
                          onChange={(e) => handlePartChange("aiHearingRange", parseFloat(e.target.value) || 0)}
                          className="bg-[#0d0810] text-white border border-[#3b1119] rounded px-2 py-1 text-xs w-16 focus:outline-none focus:border-amber-500"
                        />
                      </div>

                      {/* Mentality */}
                      <label className="flex items-center gap-2 cursor-pointer mb-1 group">
                        <input
                          type="checkbox"
                          checked={selectedPart.aiPackMentality || false}
                          onChange={(e) => handlePartChange("aiPackMentality", e.target.checked)}
                          className="w-3 h-3 accent-amber-600 rounded bg-[#090d18] border border-gray-600 cursor-pointer"
                        />
                        <span className="text-gray-300 font-medium text-xs group-hover:text-white transition-colors">
                          Pack Mentality (Call nearby allies)
                        </span>
                      </label>
                      <label className="flex items-center gap-2 cursor-pointer mb-2 group">
                        <input
                          type="checkbox"
                          checked={selectedPart.aiSleepAtNight || false}
                          onChange={(e) => handlePartChange("aiSleepAtNight", e.target.checked)}
                          className="w-3 h-3 accent-amber-600 rounded bg-[#090d18] border border-gray-600 cursor-pointer"
                        />
                        <span className="text-gray-300 font-medium text-xs group-hover:text-white transition-colors">
                          Sleeps At Night
                        </span>
                      </label>
                    </div>`;

code = code.replace(targetStr, replaceStr);
fs.writeFileSync('src/components/PropertiesPanel.tsx', code);
