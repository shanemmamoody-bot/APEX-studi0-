import express from 'express';
import fs from 'fs';
import path from 'path';
import { adexRuntime, AdexModelType } from "./adex/inference";

const router = express.Router();

const CHAT_DATA_FILE = path.join(process.cwd(), "ai_chat_data.json");
let chatData: { [username: string]: Conversation[] } = {};

interface Message {
  role: 'user' | 'model';
  content: string;
}

interface Conversation {
  id: string;
  title: string;
  createdAt: number;
  messages: Message[];
}

if (fs.existsSync(CHAT_DATA_FILE)) {
  try {
    chatData = JSON.parse(fs.readFileSync(CHAT_DATA_FILE, "utf-8"));
  } catch (err) {
    console.error("Failed to parse ai_chat_data.json", err);
  }
}

function saveChatData() {
  fs.writeFileSync(CHAT_DATA_FILE, JSON.stringify(chatData, null, 2), "utf-8");
}

// Get all conversations for a user
router.get('/conversations/:username', (req, res) => {
  const { username } = req.params;
  const userChats = chatData[username] || [];
  res.json(userChats.map(c => ({ id: c.id, title: c.title, createdAt: c.createdAt })));
});

// Get a specific conversation
router.get('/conversations/:username/:conversationId', (req, res) => {
  const { username, conversationId } = req.params;
  const userChats = chatData[username] || [];
  const chat = userChats.find(c => c.id === conversationId);
  if (!chat) return res.status(404).json({ error: "Conversation not found" });
  res.json(chat);
});

// Create a new conversation
router.post('/conversations/:username', (req, res) => {
  const { username } = req.params;
  if (!chatData[username]) chatData[username] = [];
  const newChat: Conversation = {
    id: 'chat-' + Math.random().toString(36).substr(2, 9),
    title: 'New Conversation',
    createdAt: Date.now(),
    messages: []
  };
  chatData[username].push(newChat);
  saveChatData();
  res.json(newChat);
});

// Delete a conversation
router.delete('/conversations/:username/:conversationId', (req, res) => {
  const { username, conversationId } = req.params;
  if (!chatData[username]) return res.json({ success: true });
  chatData[username] = chatData[username].filter(c => c.id !== conversationId);
  saveChatData();
  res.json({ success: true });
});

// Rename a conversation
router.put('/conversations/:username/:conversationId', (req, res) => {
  const { username, conversationId } = req.params;
  const { title } = req.body;
  const userChats = chatData[username] || [];
  const chat = userChats.find(c => c.id === conversationId);
  if (chat && title) {
    chat.title = title;
    saveChatData();
  }
  res.json({ success: true });
});

// Send a message
router.post('/message', async (req, res) => {
  const { username, conversationId, message, modelId } = req.body;
  if (!username || !conversationId || !message || !modelId) {
    return res.status(400).json({ error: "Missing required fields" });
  }

  if (!chatData[username]) chatData[username] = [];
  const chat = chatData[username].find(c => c.id === conversationId);
  if (!chat) return res.status(404).json({ error: "Conversation not found" });

  chat.messages.push({ role: 'user', content: message });

  if (chat.messages.length === 1) {
    chat.title = message.substring(0, 30) + (message.length > 30 ? '...' : '');
  }

  try {
    const promptContext = chat.messages.map(m => m.content).join("\n\n");
    const replyText = await adexRuntime.generateText(modelId as AdexModelType, promptContext);
    
    chat.messages.push({ role: 'model', content: replyText });
    saveChatData();

    res.json({ reply: replyText, title: chat.title });
  } catch (err: any) {
    console.error("AI Chat Error:", err);
    let fallbackReply = "I am currently disconnected from my core logic servers and unable to generate a detailed response. Please try again later.";
    chat.messages.push({ role: 'model', content: fallbackReply });
    saveChatData();
    res.json({ reply: fallbackReply });
  }
});

// Regenerate last message
router.post('/regenerate', async (req, res) => {
  const { username, conversationId, modelId } = req.body;
  if (!username || !conversationId || !modelId) return res.status(400).json({ error: "Missing required fields" });

  const chat = chatData[username]?.find(c => c.id === conversationId);
  if (!chat) return res.status(404).json({ error: "Conversation not found" });

  if (chat.messages.length > 0 && chat.messages[chat.messages.length - 1].role === 'model') {
    chat.messages.pop();
  }

  if (chat.messages.length === 0) return res.status(400).json({ error: "No user message to regenerate from" });

  const lastUserMessage = chat.messages[chat.messages.length - 1].content;
  chat.messages.pop();

  try {
    chat.messages.push({ role: 'user', content: lastUserMessage });
    const promptContext = chat.messages.map(m => m.content).join("\n\n");
    const replyText = await adexRuntime.generateText(modelId as AdexModelType, promptContext);

    chat.messages.push({ role: 'model', content: replyText });
    saveChatData();

    res.json({ reply: replyText });
  } catch (err: any) {
    console.error("AI Chat Error:", err);
    let fallbackReply = "I am currently disconnected from my core logic servers and unable to generate a detailed response. Please try again later.";
    chat.messages.push({ role: 'model', content: fallbackReply });
    saveChatData();
    res.json({ reply: fallbackReply });
  }
});

export default router;
