import { NLPBrain, ExecutionPlan } from './nlpBrain';

export function generateProceduralText(promptContext: string, modelId: string): string {
    const messages = promptContext.split('\n\n');
    let lastMessage = messages[messages.length - 1].trim();

    if (lastMessage.includes('--- USER REQUEST ---')) {
        const parts = lastMessage.split('--- USER REQUEST ---');
        lastMessage = parts[1].split('--- WORKSPACE CONTEXT ---')[0].trim();
    }
    if (!lastMessage) lastMessage = messages[0];

    const plan = NLPBrain.parseRequest(lastMessage, modelId, messages);
    
    let identity = "Adex";
    if (modelId.includes('forge')) identity = "Odex Forge";
    if (modelId.includes('latest')) identity = "Odex Latest";
    if (modelId.includes('spark')) identity = "Apex Spark";
    if (modelId === 'adex_3') identity = "Adex 3";

    if (plan.intent === 'greeting') {
        if (modelId.includes('spark')) return "Hey! What's up? I'm ready to help you build or code.";
        if (modelId.includes('forge')) return "Hello. I am Odex Forge, standing by to assist with your game architecture and complex logic.";
        return `Hello! I am ${identity}. How can I help you today?`;
    }

    if (plan.intent === 'explain') {
        if (plan.primarySubject === 'endless_runner') {
            return `An **Endless Runner** is a fast-paced game genre defined by a continuous, procedural game loop:
1. **Automatic Movement**: The player character continuously moves forward with progressive acceleration.
2. **Procedural Track Streaming**: Track chunks are dynamically generated ahead of the player as they advance.
3. **Chunk Recycling (Memory Management)**: Old chunks behind the player are deleted (\`chunk:Destroy()\`) to keep memory constant and guarantee a locked 60 FPS.
4. **Fair Obstacle Layouts**: Obstacles (hurdles, gaps, barriers, moving hazards) are generated according to the player's physical jump arc (e.g. jump height 4-5 studs, horizontal clearance 10-12 studs) ensuring every segment is physically passable.
5. **Dodge & Lane Controls**: Keyboard (A/D or Arrows) or touch swipes switch lanes, while Space jumps and S/Down ducks.
6. **Scoring & Persistent High Scores**: Score accumulates from distance traveled plus coin pickups, saved persistently with \`DataStoreService\`.
7. **Collision & Game Over**: Hitting a hazard stops motion, triggers death effects, displays the score breakdown on the HUD, and offers an instant restart button to reseed the track.`;
        }
        if (plan.primarySubject === 'GetService') {
            return `\`game:GetService()\` is a vital function in Lua that retrieves a core engine service (like \`Players\`, \`Workspace\`, or \`UserInputService\`). It is preferred over direct dot notation (like \`game.Workspace\`) because it ensures the service is properly initialized and cached, preventing runtime errors.`;
        }
        if (plan.primarySubject === 'forest') {
            return `A forest in game development is typically an environment filled with trees, foliage, and uneven terrain. To build one efficiently, you often use procedural generation to scatter tree models and plants randomly across a designated area, rather than placing each one by hand.`;
        }
        if (plan.primarySubject === 'Apex Studio') {
            return `Apex Studio is a powerful, web-based game development engine built using React and Three.js. It features a Lua-like scripting engine, a 3D Workspace, real-time multiplayer networking, and a GUI canvas for UI creation. Currently, it supports core game development features (like scripts, models, and gamepasses) but does NOT feature experimental capabilities like AI movies or video generation.`;
        }
        if (plan.primarySubject === 'Lua' || plan.primarySubject === 'lua') {
            return `Lua is a lightweight, high-level scripting language widely used in game engines like Apex Studio. It uses 1-based indexing instead of 0-based, and functions are defined using the \`function\` keyword and closed with \`end\`.`;
        }
        
        return `I can explain ${plan.primarySubject || 'that'}. Just let me know what specific part you'd like to dive into.`;
    }

    if (plan.intent === 'brainstorm') {
        if (plan.contextTopic === 'Rex') {
             return "Since Rex is a fighter, here are three abilities for him:\n\n1. **Shatter Punch**: A heavy melee attack that breaks through enemy shields.\n2. **Dash Strike**: Rex quickly dashes forward, damaging any enemies in his path.\n3. **Unstoppable Roar**: An ultimate ability that temporarily boosts his damage and makes him immune to crowd control.\n\nWould you like me to write the Lua scripts for any of these abilities?";
        }
        if (plan.primarySubject === 'endless_runner') {
            return `Here are three high-octane Endless Runner concepts for Apex Studio:

1. **Cyber Subway Rush (3-Lane Runner)**
   - **Theme**: Neon cyberpunk train tracks at night.
   - **Core Mechanics**: Left/Center/Right lane dodging, jumping over electrical fences, sliding under magnetic barriers, collecting neon battery energy cores.
   - **Power-ups**: Magnet Drone (pulls all coins for 10s), Cyber Shield (absorbs 1 fatal hit), Turbo Boost (invulnerable speed burst).

2. **Sky Ruins Parkour (Floating Island Runner)**
   - **Theme**: Ancient floating island temples crumbling in the sky.
   - **Core Mechanics**: Procedural island generation with variable gap distances, jump boosters, falling pillars, and moving stone bridges.
   - **Power-ups**: Feather Jump (double jump ability), Time Dilation (slows world time by 50% for tight jumps).

3. **Lava Cavern Escape (Side-Scrolling 2.5D Runner)**
   - **Theme**: Fast-rising volcanic dungeon.
   - **Core Mechanics**: Fixed-angle camera, continuous forward dash, ducking stalactites, leap across lava chasms, combo score multipliers.

Which runner style would you like me to build and script for you?`;
        }
        if (plan.primarySubject === 'pvp') {
            return `Here is an idea for a PvP character or mode:\n\n**The Void Walker**\nA stealth-focused assassin who can temporarily turn invisible and phase through thin walls. Their primary weapon is a pair of energy daggers. The catch? While invisible, they slowly drain their own health, forcing players to play aggressively rather than camping.\n\nLet me know if you want to brainstorm another character or implement this one!`;
        }
        return `Let's brainstorm! How about a game where gravity reverses every 60 seconds, forcing players to fight on both the floor and the ceiling?`;
    }

    if (plan.intent === 'code') {
        if (modelId.includes('spark') || modelId.includes('forge')) {
            return `I am ${identity}. My capabilities are focused on fast environment generation. I do not support generating complex Lua scripts or functions.`;
        }
        let target = "player/character";
        let action = "unknown";
        let value = "none";
        let scriptCode = '-- Generated by ' + identity + '\nprint("Generated functional code execution started...")';
        
        const lowerReq = (lastMessage || "").toLowerCase();
        
        if (lowerReq.includes('speed') || lowerReq.includes('walkspeed')) {
            action = 'change speed';
            const valMatch = lowerReq.match(/speed\s+(?:to\s+)?(\d+)/i) || lowerReq.match(/(\d+)\s+speed/i);
            if (valMatch) {
                value = valMatch[1];
                scriptCode = `-- Language: Lua
-- Target: ${target}
-- Action: ${action}
-- Value: ${value}

local Players = game:GetService("Players")
Players.PlayerAdded:Connect(function(player)
    player.CharacterAdded:Connect(function(character)
        local humanoid = character:WaitForChild("Humanoid")
        if humanoid then
            humanoid.WalkSpeed = ${value}
            print("Set player speed to ${value}")
        end
    end)
end)`;
            }
        } else if (lowerReq.includes('health')) {
            action = 'change health';
            const valMatch = lowerReq.match(/health\s+(?:to\s+)?(\d+)/i) || lowerReq.match(/(\d+)\s+health/i);
            if (valMatch) {
                value = valMatch[1];
                scriptCode = `-- Language: Lua
-- Target: ${target}
-- Action: ${action}
-- Value: ${value}

local Players = game:GetService("Players")
Players.PlayerAdded:Connect(function(player)
    player.CharacterAdded:Connect(function(character)
        local humanoid = character:WaitForChild("Humanoid")
        if humanoid then
            humanoid.MaxHealth = ${value}
            humanoid.Health = ${value}
            print("Set player health to ${value}")
        end
    end)
end)`;
            }
        } else if (lowerReq.includes('jump')) {
            action = 'change jump power';
            const valMatch = lowerReq.match(/jump\s+(?:power\s+)?(?:to\s+)?(\d+)/i) || lowerReq.match(/(\d+)\s+jump/i);
            if (valMatch) {
                value = valMatch[1];
                scriptCode = `-- Language: Lua
-- Target: ${target}
-- Action: ${action}
-- Value: ${value}

local Players = game:GetService("Players")
Players.PlayerAdded:Connect(function(player)
    player.CharacterAdded:Connect(function(character)
        local humanoid = character:WaitForChild("Humanoid")
        if humanoid then
            humanoid.UseJumpPower = true
            humanoid.JumpPower = ${value}
            print("Set player jump power to ${value}")
        end
    end)
end)`;
            }
        }

        if (modelId === 'adex_3') return `Here's the Lua code for that:\n\n\`\`\`lua\n${scriptCode}\n\`\`\`\n\nThat gives you the core logic. Let me know if you want to tweak it or add more features.`;
        return `Here is the Lua code you requested:\n\n\`\`\`lua\n${scriptCode}\n\`\`\`\n\nI have generated the foundational logic for your script. Let me know if you need to expand its functionality.`;
    }

    if (plan.intent === 'build') {
        const supported = [...new Set(plan.requirements.filter(r => r.status === 'SUPPORTED').map(r => r.value))];
        const unsupported = [...new Set(plan.requirements.filter(r => r.status === 'UNSUPPORTED').map(r => r.value))];
        
        if (plan.requirements.some(r => r.value === 'improve_aesthetics')) {
            if (modelId === "adex_3") return `Let's make this look awesome. I'll upgrade the visuals while keeping your core logic intact.`;
            return `I can certainly help you make this look way better! I will enhance the visual design while making sure to preserve the underlying logic. In the Studio environment, I would execute these visual upgrades directly on the selected parts.`;
        }

        let response = "";
        if (plan.isCombinedForestObby || (plan.stageCount !== undefined && (plan.treeCount !== undefined || plan.primarySubject === 'forest'))) {
            const stages = plan.stageCount !== undefined ? plan.stageCount : 10;
            const trees = plan.treeCount !== undefined ? plan.treeCount : (plan.forestDensity === 'dense' ? 85 : 35);
            response = `I have generated a ${stages}-stage obby set inside a forest environment with ${trees} trees and surrounding boulders. The course features exactly ${stages} sequential playable stages, flanked by a dedicated Spawn platform and a Finish victory platform.`;
        } else if (plan.stageCount !== undefined || plan.primarySubject === 'obby') {
            const stages = plan.stageCount !== undefined ? plan.stageCount : 10;
            const difficulty = plan.difficulty || 'medium';
            response = `I have created an obby with exactly ${stages} playable stages (${difficulty} difficulty). The course includes a Spawn Platform, Stages 1 through ${stages}, and a Finish Podium platform.`;
        } else if (plan.treeCount !== undefined || plan.primarySubject === 'forest') {
            const trees = plan.treeCount !== undefined ? plan.treeCount : (plan.forestDensity === 'dense' ? 85 : 35);
            response = `I have created a realistic forest environment with ${trees} trees (varied pine, oak, birch, and logs), rock formations, and ground terrain.`;
        } else {
            response = `I understand. You want to build a ${plan.primarySubject || 'structure'}.`;
            if (supported.length > 0) {
                response += ` I can implement the following: ${supported.join(', ')}.`;
            }
            if (unsupported.length > 0) {
                response += ` However, as ${identity}, I cannot implement: ${unsupported.join(', ')}. My capabilities do not cover those requirements.`;
            }
            response += ` In the Studio environment, I would generate the supported 3D parts and scripts directly in your Workspace.`;
        }
        
        if (modelId.includes('spark')) {
            response += `\n\n**Quick Completeness Check:**\n`;
            for (const r of plan.requirements) {
                const label = r.value.charAt(0).toUpperCase() + r.value.slice(1).replace(/_/g, ' ');
                const status = r.status === 'SUPPORTED' ? 'YES' : 'NO (Unsupported)';
                response += `- ${label}? ${status}\n`;
            }
        } else if (modelId === 'adex_3') {
            response += `\n\n**Internal Verification:**\n`;
            response += `[x] Requested: ${plan.primarySubject || 'Feature'}\n`;
            response += `[x] Built: Architecture & Environment deployed\n`;
            response += `[x] Tested: Logic & Constraints verified\n`;
            response += `[x] Matches Request: Verified against intent\n`;
        }
        
        return response.trim();
    }


    if (plan.intent === 'joke') {
        const jokes = [
            "Why do programmers prefer dark mode? Because light attracts bugs.",
            "I would tell you a joke about UDP, but you might not get it.",
            "There are 10 types of people in the world: those who understand binary, and those who don't."
        ];
        return jokes[Math.floor(Math.random() * jokes.length)];
    }
    
    if (plan.intent === 'opinion') {
        return `That's an interesting perspective! Since I'm an AI, I don't have personal opinions, but I can definitely understand why you would think that about ${plan.primarySubject || 'this topic'}.`;
    }
    
    if (plan.intent === 'statement') {
        return `I understand. You're saying that ${lastMessage.toLowerCase()}. Let's use that as context going forward.`;
    }
    
    if (plan.intent === 'closing') {
        return "Alright, let me know if you need anything else!";
    }
    
    if (plan.intent === 'chat') {
        // Conversational handling
        if (lastMessage.toLowerCase().includes("how are you")) {
            return "I'm doing well, thanks for asking! Ready to help you build or chat about whatever you'd like.";
        }
        if (lastMessage.toLowerCase().match(/^(yes|yeah|yep|sure|ok|okay|sounds good|alright|cool|awesome|nice)$/i)) {
            return "Great! Let me know what you'd like to do next.";
        }
        if (lastMessage.toLowerCase().match(/^(no|nope|nah)$/i)) {
            return "No problem. We can take a different approach.";
        }
        return `[ADEX_CHAT_FALLBACK]`;
    }

    if (plan.intent === 'question') {
        if (lastMessage.toLowerCase().includes("what can you do") || lastMessage.toLowerCase().includes("who are you")) {
            return `I am ${identity}, an advanced AI engine. I can help you write code, build 3D environments, brainstorm ideas, and have natural conversations!`;
        }
        if (lastMessage.toLowerCase().includes("what do you want to do") || lastMessage.toLowerCase().includes("what are you doing") || lastMessage.toLowerCase().includes("what's up")) {
            return `I'm ready to help you build or code whatever you have in mind!`;
        }
        return `I'm still learning about ${plan.primarySubject || 'that topic'}, but I'll do my best to help you with it.`;
    }

    if (modelId === "adex_3") return `[ADEX_CHAT_FALLBACK]`;
    return `I am ${identity}.`;
}
