export type Intent = 'build' | 'code' | 'chat' | 'explain' | 'brainstorm' | 'question' | 'greeting' | 'joke' | 'opinion' | 'statement' | 'command' | 'request' | 'closing';

export type CapabilityStatus = 'SUPPORTED' | 'PARTIALLY_SUPPORTED' | 'UNSUPPORTED';

export type DifficultyLevel = 'easy' | 'medium' | 'hard';

export type ForestDensity = 'sparse' | 'normal' | 'large' | 'dense' | 'huge_dense';

export interface Requirement {
    type: 'entity' | 'material' | 'behavior' | 'constraint' | 'spatial' | 'gameplay';
    value: string;
    target?: string;
    status?: CapabilityStatus;
}

export interface ExecutionPlan {
    intent: Intent;
    primarySubject: string;
    requirements: Requirement[];
    isContextContinuation: boolean;
    contextTopic?: string;
    rawText: string;
    stageCount?: number;
    difficulty?: DifficultyLevel;
    treeCount?: number;
    rockCount?: number;
    forestDensity?: ForestDensity;
    isCombinedForestObby?: boolean;
}

export class NLPBrain {
    public static parseRequest(prompt: string, modelId: string, history: string[] = []): ExecutionPlan {
        console.log(`[Apex Model Engine] Core inference triggered. Model: ${modelId} | Input: "${prompt.substring(0, 50)}..."`);
        
        let lower = (prompt || "").toLowerCase();
        
        // --- 1. Normalization & Typos ---
        lower = lower.replace(/\bhuge\b/g, 'large'); // Auto-learned

        lower = lower.replace(/\btiny\b/g, 'small'); // Auto-learned

        lower = lower.replace(/\bspooky\b/g, 'scary'); // Auto-learned

        lower = lower.replace(/\bfast\b/g, 'quick'); // Auto-learned

        lower = lower.replace(/\binvisible\b/g, 'hidden'); // Auto-learned

        lower = lower.replace(/\bgigantic\b/g, 'giant'); // Auto-learned

        lower = lower.replace(/\bautomagic\b/g, 'automatic'); // Auto-learned

        lower = lower.replace(/\bmagical\b/g, 'magic'); // Auto-learned

        lower = lower.replace(/\bocean\b/g, 'water'); // Auto-learned

        lower = lower.replace(/\blava\b/g, 'fire'); // Auto-learned

        lower = lower.replace(/wen/g, 'when');
        lower = lower.replace(/u /g, 'you ');
        lower = lower.replace(/eachother/g, 'each other');
        lower = lower.replace(/plz/g, 'please');
        lower = lower.replace(/litle/g, 'little');
        lower = lower.replace(/outta/g, 'out of');
        lower = lower.replace(/lookin\b/g, 'looking');
        lower = lower.replace(/dont/g, "don't");
        lower = lower.replace(/round it/g, 'around it');
        lower = lower.replace(/\bits\b/g, "it's");
        
        const requirements: Requirement[] = [];
        let intent: Intent = 'chat';
        let primarySubject = '';
        
        // Context Resolution
        let contextSubject = '';
        if (history && history.length > 0) {
            const histStr = history.join(' ').toLowerCase();
            if (histStr.includes('rex')) contextSubject = 'Rex';
            else if (histStr.includes('cabin')) contextSubject = 'cabin';
            else if (histStr.includes('castle')) contextSubject = 'castle';
        }

        // --- 2. Extract Specific Numeric Quantities & Configurations ---
        let stageCount: number | undefined = undefined;
        let treeCount: number | undefined = undefined;
        let rockCount: number | undefined = undefined;
        let difficulty: DifficultyLevel = 'medium';
        let forestDensity: ForestDensity = 'normal';

        // Stage/Jump extraction
        const stageKeywords = ['stage', 'stages', 'jump', 'jumps', 'level', 'levels', 'obstacle', 'obstacles', 'step', 'steps', 'checkpoint', 'checkpoints'];
        stageCount = this.extractNumberForKeywords(lower, stageKeywords);

        // Tree count extraction
        const treeKeywords = ['tree', 'trees', 'pine', 'pines', 'oak', 'oaks', 'birch', 'trunk', 'trunks'];
        treeCount = this.extractNumberForKeywords(lower, treeKeywords);

        // Rock count extraction
        const rockKeywords = ['rock', 'rocks', 'boulder', 'boulders', 'stone', 'stones'];
        rockCount = this.extractNumberForKeywords(lower, rockKeywords);

        // Difficulty extraction
        if (lower.match(/\b(very easy|super easy|easy|simple|beginner|relaxing|casual)\b/)) {
            difficulty = 'easy';
        } else if (lower.match(/\b(hard|very hard|difficult|insane|extreme|expert|hardcore|punishing)\b/)) {
            difficulty = 'hard';
        } else if (lower.match(/\b(medium|normal|moderate|standard)\b/)) {
            difficulty = 'medium';
        }

        // Forest density extraction
        if (lower.match(/\b(huge dense|massive dense|giant dense|extremely dense|super dense)\b/)) {
            forestDensity = 'huge_dense';
        } else if (lower.match(/\b(dense|thick|deep|dense forest)\b/)) {
            forestDensity = 'dense';
        } else if (lower.match(/\b(huge|massive|giant|large|big)\b/) && (lower.includes('forest') || lower.includes('tree'))) {
            forestDensity = 'large';
        } else if (lower.match(/\b(sparse|small|tiny|light|few)\b/) && (lower.includes('forest') || lower.includes('tree'))) {
            forestDensity = 'sparse';
        }

        const hasObbyWord = lower.includes('obby') || lower.includes('parkour') || lower.includes('stage') || lower.includes('jump') || lower.includes('obstacle course');
        const hasForestWord = lower.includes('forest') || lower.includes('tree') || lower.includes('trees') || lower.includes('woodland') || lower.includes('jungle');
        const isCombinedForestObby = Boolean(hasObbyWord && hasForestWord);

        // --- 3. Intent Detection ---
        if (lower.match(/\b(that is all|thats all|that's all|im done|i'm done|nothing else|goodbye|bye|thanks|thank you|no thanks|nevermind)\b/i) || lower.includes("that's it")) {
            intent = 'closing';
            primarySubject = 'closing';
        }
        else if (/^(hello|hi|hey|how are you|greetings|sup)\b/i.test(lower) && lower.split(' ').length <= 5) {
            intent = 'greeting';
            primarySubject = 'greeting';
        } 
        else if (lower.match(/^(tell me a joke|make me laugh|joke)/i)) {
            intent = 'joke';
            primarySubject = 'joke';
        }
        else if (lower.match(/^(i think|in my opinion|i believe|it seems like)\b/i)) {
            intent = 'opinion';
            primarySubject = lower;
        }
        else if (lower.match(/^(what|what's|whats|which|how|how's|why|who|who's|whos|when|where|can you explain|do you know|is there|calculate|solve|spell|define)\b/i) || lower.endsWith('?')) {
            if (/^(can you|how do i)\s+(make|build|create|write|generate|add)\b/i.test(lower)) {
                intent = 'build';
            } else {
                intent = 'question';
                primarySubject = lower;
            }
        }
        else if (lower.match(/^(make|build|create|write|generate|add|do|run|stop|start|open|close|execute)\b/i)) {
            intent = 'build';
        }
        else if (lower.includes('what is') || lower.includes('how to') || lower.includes('explain') || lower.includes('what does')) {
            intent = 'explain';
            if (lower.includes('endless runner') || lower.includes('runner game') || lower.includes('subway') || lower.includes('temple run')) primarySubject = 'endless_runner';
            else if (lower.includes('getservice')) primarySubject = 'GetService';
            else if (lower.includes('forest')) primarySubject = 'forest';
            else if (lower.includes('apex studio')) primarySubject = 'Apex Studio';
            else if (lower.includes('lua')) primarySubject = 'Lua';
            else primarySubject = lower.replace(/what is|explain|how to|what does/g, '').trim();
        }
        else if (lower.includes('idea') || lower.includes('brainstorm') || lower.includes('suggest')) {
            intent = 'brainstorm';
            if (lower.includes('endless runner') || lower.includes('runner')) primarySubject = 'endless_runner';
            else if (lower.includes('pvp')) primarySubject = 'pvp';
            else if (lower.includes('character')) primarySubject = 'character';
            else primarySubject = 'game';
        }
        else if (/make |build |create |put |generate |add |change |less /i.test(lower) || lower.includes('look way better') || lower.includes('runner') || hasObbyWord || hasForestWord) {
            intent = 'build';
            
            if ((lower.includes('script') || lower.includes('code')) && !lower.includes('box') && !lower.includes('house') && !lower.includes('forest') && !lower.includes('runner') && !hasObbyWord) {
                intent = 'code';
            }
            
            // --- 4. Smart Extraction ---
            const entities = [
                'dropper', 'tycoon dropper', 'conveyor', 'collector', 'button', 'tycoon', 'door', 'shop', 'npc', 'weapon', 'obby', 'checkpoint', 'quest', 'spawn', 'ui', 'damage', 'currency', 'saving',
                'endless runner', 'endless_runner', 'runner', 'subway runner', 'temple runner', 'parkour runner', 'highway runner', 'dungeon runner', 'side scroller runner',
                'forest', 'tree', 'trees', 'box', 'house', 'cabin', 'town', 'bridge', 'water', 'river', 'zombie', 'player', 'map', 'wall', 'walls', 'door', 'castle', 'cannon', 'cannons', 'sword', 'weapon', 'chest', 'gun', 'lava', 'rocks', 'rock'
            ];
            const foundEntities = entities.filter(e => lower.includes(e));

            if (isCombinedForestObby) {
                if (!foundEntities.includes('obby')) foundEntities.push('obby');
                if (!foundEntities.includes('forest')) foundEntities.push('forest');
            } else if (hasObbyWord && !foundEntities.includes('obby')) {
                foundEntities.push('obby');
            } else if (hasForestWord && !foundEntities.includes('forest')) {
                foundEntities.push('forest');
            }
            
            foundEntities.forEach(e => {
                let eName = e;
                if (e === 'trees') eName = 'tree';
                if (e === 'rocks') eName = 'rock';
                if (e === 'tycoon dropper' || e === 'dropper') eName = 'dropper';
                if (e === 'walls') eName = 'wall';
                if (e === 'cannons') eName = 'cannon';
                if (e === 'endless runner' || e === 'runner' || e === 'subway runner' || e === 'temple runner' || e === 'parkour runner' || e === 'highway runner' || e === 'dungeon runner' || e === 'side scroller runner') {
                    eName = 'endless_runner';
                }
                
                if (!requirements.some(r => r.type === 'entity' && r.value === eName)) {
                    requirements.push({ type: 'entity', value: eName });
                }
            });
            
            if (isCombinedForestObby) {
                primarySubject = 'forest_obby';
            } else if (foundEntities.length > 0) {
                const runnerMatch = foundEntities.find(e => e.includes('runner') || e.includes('endless'));
                primarySubject = runnerMatch ? 'endless_runner' : foundEntities[0];
            }
            
            if (lower.match(/\b(it|this|that)\b/) && contextSubject && !foundEntities.includes(contextSubject)) {
                requirements.push({ type: 'entity', value: contextSubject });
                if (!primarySubject) primarySubject = contextSubject;
            } else if (lower.includes('jumping')) {
                primarySubject = 'jumping';
                requirements.push({ type: 'entity', value: 'jumping' });
            }

            if (stageCount !== undefined) {
                requirements.push({ type: 'constraint', value: `stages_${stageCount}` });
            }
            requirements.push({ type: 'constraint', value: `difficulty_${difficulty}` });
            if (treeCount !== undefined) {
                requirements.push({ type: 'constraint', value: `trees_${treeCount}` });
            }
            if (rockCount !== undefined) {
                requirements.push({ type: 'constraint', value: `rocks_${rockCount}` });
            }
            requirements.push({ type: 'constraint', value: `density_${forestDensity}` });
            
            if (lower.match(/\b(it|this|that)\b/) && contextSubject && !foundEntities.includes(contextSubject)) {
                requirements.push({ type: 'entity', value: contextSubject });
                if (!primarySubject) primarySubject = contextSubject;
            } else if (lower.includes('jumping')) {
                primarySubject = 'jumping';
                requirements.push({ type: 'entity', value: 'jumping' });
            }

            
            // Dropper / Tycoon specific mechanics
            if (lower.includes('dropper') || primarySubject === 'dropper') {
                requirements.push({ type: 'gameplay', value: 'tycoon_dropper' });
                requirements.push({ type: 'behavior', value: 'spawn_parts' });
                requirements.push({ type: 'behavior', value: 'collect_value' });
                requirements.push({ type: 'behavior', value: 'destroy_parts' });
            }

            // Endless Runner specific mechanics & controls detection
            if (lower.includes('endless') || lower.includes('runner') || primarySubject === 'endless_runner') {
                requirements.push({ type: 'gameplay', value: 'endless_runner_loop' });
                requirements.push({ type: 'behavior', value: 'procedural_generation' });
                requirements.push({ type: 'behavior', value: 'chunk_recycling' });
                requirements.push({ type: 'behavior', value: 'auto_forward' });
                requirements.push({ type: 'behavior', value: 'difficulty_scaling' });
                requirements.push({ type: 'behavior', value: 'score_system' });
                requirements.push({ type: 'behavior', value: 'restart_loop' });

                if (lower.includes('3 lane') || lower.includes('3-lane') || lower.includes('three lane') || lower.includes('subway') || lower.includes('dodge') || lower.includes('lanes')) {
                    requirements.push({ type: 'behavior', value: 'three_lane_movement' });
                }
                if (lower.includes('parkour') || lower.includes('gap') || lower.includes('void')) {
                    requirements.push({ type: 'behavior', value: 'parkour_physics' });
                }
                if (lower.includes('highway') || lower.includes('traffic') || lower.includes('car') || lower.includes('road')) {
                    requirements.push({ type: 'behavior', value: 'highway_traffic' });
                }
                if (lower.includes('dungeon') || lower.includes('temple') || lower.includes('spike')) {
                    requirements.push({ type: 'behavior', value: 'dungeon_hazards' });
                }
                if (lower.includes('side scroll') || lower.includes('2.5d') || lower.includes('2d')) {
                    requirements.push({ type: 'behavior', value: 'side_scrolling' });
                }
                if (lower.includes('datastore') || lower.includes('save') || lower.includes('high score') || lower.includes('highscore') || lower.includes('leaderboard')) {
                    requirements.push({ type: 'behavior', value: 'datastore_highscores' });
                }
            }

            
            if (lower.match(/\b(iron|metal|steel)\b/)) {
                requirements.push({ type: 'material', value: 'metal' });
            }
            if (lower.match(/\b(red|blue|green|yellow|black|white)\b/)) {
                const matchColor = lower.match(/\b(red|blue|green|yellow|black|white)\b/);
                if (matchColor) requirements.push({ type: 'material', value: matchColor[1] });
            }
            
            if (lower.includes('in middle') || lower.includes('center')) {
                requirements.push({ type: 'spatial', value: 'in_middle' });
            }
            if (lower.includes('beside')) {
                requirements.push({ type: 'spatial', value: 'beside_object' });
            }
            if (lower.includes('over the water') || lower.includes('over water')) {
                requirements.push({ type: 'spatial', value: 'over_water' });
            }
            if (lower.includes('around it') || lower.includes('round it')) {
                requirements.push({ type: 'spatial', value: 'surrounding' });
            }
            if (lower.match(/walk inside|go inside|walk in|enter\b/)) {
                requirements.push({ type: 'spatial', value: 'player_entrance' });
                requirements.push({ type: 'spatial', value: 'usable_interior' });
            }
            if (lower.includes('walk through')) {
                requirements.push({ type: 'spatial', value: 'player_entrance' });
                requirements.push({ type: 'spatial', value: 'passable' });
            }
            if (lower.includes('near door') || lower.includes('near the door')) {
                requirements.push({ type: 'spatial', value: 'near_door' });
            }
            
            if (lower.includes('working') || lower.includes('functional')) {
                requirements.push({ type: 'behavior', value: 'functional_logic' });
            }
            if (lower.match(/knockback|knocks players backwards/)) {
                requirements.push({ type: 'behavior', value: 'knockback' });
            }
            if (lower.match(/follow player|chase/)) {
                requirements.push({ type: 'behavior', value: 'chase_player' });
            }
            if (lower.includes("don't let it get stuck") || lower.includes("not get stuck")) {
                requirements.push({ type: 'behavior', value: 'pathfinding_logic' });
            }
            if (lower.includes('less empty') || lower.includes('add stuff')) {
                requirements.push({ type: 'behavior', value: 'populate_environment' });
            }
            if (lower.includes('keep the same style')) {
                requirements.push({ type: 'constraint', value: 'preserve_style' });
            }
            if (lower.match(/smoother|not laggy|feels laggy/)) {
                requirements.push({ type: 'behavior', value: 'optimize_mechanic' });
            }
            if (lower.includes('look way better') || lower.includes('look nicer')) {
                requirements.push({ type: 'behavior', value: 'improve_aesthetics' });
            }
            if (lower.includes("don't change") || lower.includes("dont delete")) {
                requirements.push({ type: 'constraint', value: 'preserve_logic' });
            }
            if (lower.match(/touch.*die|kill on touch/)) {
                requirements.push({ type: 'behavior', value: 'kill_on_touch' });
            }
            if (lower.includes('open')) {
                requirements.push({ type: 'behavior', value: 'interactable_open' });
            }
            if (lower.includes('shoot')) {
                requirements.push({ type: 'behavior', value: 'shoot_projectile' });
            }
            
            if (lower.includes('twice as big')) {
                requirements.push({ type: 'constraint', value: 'scale_2x' });
            }
            if (lower.includes('taller') || lower.includes('bigger') || lower.includes('larger')) {
                requirements.push({ type: 'constraint', value: 'increase_scale' });
            }


            if (intent === 'build' && !primarySubject) {
                const match = lower.match(/(?:make|build|create|put|generate|add|change)\s+(?:a|an|the)?\s*([^with]+)/i);
                if (match) {
                    primarySubject = match[1].trim();
                }
            }
            
            if (intent === 'build' && requirements.length === 0 && !primarySubject) {
                intent = 'brainstorm';
                primarySubject = lower.replace(/make |build |create |put |generate |i want to /g, '').trim();
            }
        }
        else if (lower.includes('script') || lower.includes('code') || lower.includes('function')) {
            intent = 'code';
            primarySubject = 'code';
        }
        
        let isContextContinuation = false;
        let contextTopic = '';
        if (history && history.length > 0) {
            const histStr = history.join(' ').toLowerCase();
            if (histStr.includes('rex') && (lower.includes('he') || lower.includes('abilities') || lower.includes('fighter'))) {
                isContextContinuation = true;
                contextTopic = 'Rex';
                intent = 'brainstorm';
            }
        }

        const isForge = modelId.includes('forge');
        const isLatest = modelId.includes('latest');
        const isAdex3 = modelId.includes('adex_3');
        const isSpark = modelId.includes('spark');

        for (const req of requirements) {
            req.status = 'SUPPORTED';
            if (req.type === 'behavior' || req.type === 'gameplay' || req.type === 'constraint') {
                if (isForge || isSpark) {
                    req.status = 'UNSUPPORTED';
                }
            }
        }

        console.log(`[Apex Model Engine] Parsed Intent: ${intent} | Subject: ${primarySubject} | Stages: ${stageCount} | Difficulty: ${difficulty} | Trees: ${treeCount} | Rocks: ${rockCount}`);
        return {
            intent,
            primarySubject,
            requirements,
            isContextContinuation,
            contextTopic,
            rawText: prompt,
            stageCount,
            difficulty,
            treeCount,
            rockCount,
            forestDensity,
            isCombinedForestObby
        };
    }

    private static extractNumberForKeywords(text: string, keywords: string[]): number | undefined {
        const words = (text || "").toLowerCase();
        const wordToNum: Record<string, number> = {
            'one': 1, 'two': 2, 'three': 3, 'four': 4, 'five': 5, 'six': 6, 'seven': 7, 'eight': 8, 'nine': 9, 'ten': 10,
            'eleven': 11, 'twelve': 12, 'thirteen': 13, 'fourteen': 14, 'fifteen': 15, 'sixteen': 16, 'seventeen': 17, 'eighteen': 18, 'nineteen': 19,
            'twenty': 20, 'twenty-five': 25, 'twenty five': 25, 'thirty': 30, 'thirty-five': 35, 'thirty five': 35,
            'forty': 40, 'forty-five': 45, 'forty five': 45, 'fifty': 50, 'sixty': 60, 'seventy': 70, 'eighty': 80, 'ninety': 90, 'hundred': 100
        };

        for (const kw of keywords) {
            // Pattern 1: "40 stage", "40 stages", "40 jumps", "40-stage", "40 trees", "50 rocks"
            const p1 = new RegExp(`(\\d+)\\s*[-]?\\s*${kw}\\b`, 'i');
            const m1 = words.match(p1);
            if (m1) {
                const val = parseInt(m1[1], 10);
                if (!isNaN(val) && val > 0) return val;
            }

            // Pattern 2: "stage 40", "stages: 40", "with 40"
            const p2 = new RegExp(`(?:${kw}|with|of)\\s*[:]?\\s*(\\d+)\\s*(?:${kw})?`, 'i');
            const m2 = words.match(p2);
            if (m2) {
                const val = parseInt(m2[1], 10);
                if (!isNaN(val) && val > 0) return val;
            }

            // Pattern 3: word numbers e.g. "forty stages", "twenty trees"
            for (const [w, val] of Object.entries(wordToNum)) {
                if (words.includes(`${w} ${kw}`) || words.includes(`${w}-${kw}`)) {
                    return val;
                }
            }
        }
        return undefined;
    }
}
