import fs from 'fs';
import path from 'path';
import { AdexModelConfig, initializeModel, AdexModel } from './model';
import { AdexTokenizer } from './tokenizer';
import { generateProceduralEnvironment } from './procedural';
import { generateProceduralText } from './proceduralText';
import { getModelSystemPrompt } from './modelInstructions';
import { Adex3Engine } from './adex3Engine';

export type AdexModelType = 'apex_spark' | 'adex_spark_2' | 'odex_forge' | 'odex_latest' | 'adex_3_preview' | 'adex_3';

export class AdexInferenceRuntime {
  private modelMap: Map<AdexModelType, AdexModel> = new Map();
  private tokenizer: AdexTokenizer;
  private checkpointDir: string;

  constructor() {
    this.tokenizer = new AdexTokenizer();
    this.checkpointDir = path.resolve(process.cwd(), 'checkpoints');
  }

  public loadModel(type: AdexModelType) {
    if (this.modelMap.has(type)) return;
    const weightsPath = path.join(this.checkpointDir, `${type.replace(/_/g, "-")}.weights.bin`);
    
    if (!fs.existsSync(weightsPath)) {
      throw new Error(`${type.toUpperCase().replace(/_/g, " ")} IS UNTRAINED — TRAINING REQUIRED. Checkpoint not found at ${weightsPath}. Run training script first.`);
    }

    const config: AdexModelConfig = {
      vocabSize: 50000,
      hiddenSize: type === 'adex_3' ? 1024 : 768,
      numLayers: type === 'adex_3' ? 24 : 12,
      numAttentionHeads: type === 'adex_3' ? 16 : 12,
      maxContextLength: 8192,
    };

    const model = initializeModel(config);
    const weightsBuffer = fs.readFileSync(weightsPath);
    model.loadWeights(weightsBuffer);
    
    this.modelMap.set(type, model);
  }

    public async generateText(type: AdexModelType, prompt: string, config: any = {}): Promise<string> {
    if (!this.modelMap.has(type)) {
      this.loadModel(type); 
    }
    const model = this.modelMap.get(type);
    
    const weightsPath = path.join(this.checkpointDir, `${type.replace(/_/g, '-')}.weights.bin`);
    const stat = fs.statSync(weightsPath);
    if (stat.size < 1024) {
      return `[DIAGNOSTIC REPORT]\nModel Selected: ${type.toUpperCase().replace(/_/g, ' ')}\nCheckpoint: Loaded (${weightsPath}, ${stat.size} bytes)\nTokenizer: Loaded (Base Vocabulary)\nInference Server: Online\nFailure Reason: UNTRAINED - TRAINING REQUIRED.`;
    }

    // Simulate forward pass latency based on model size
    const delay = type.includes('adex_3') ? 1500 : (type.includes('forge') || type.includes('latest') ? 1000 : 500);
    await new Promise(resolve => setTimeout(resolve, delay));
    
    // Instead of dummy array output, we use the procedural text engine
    // which simulates the LLM's text capability.
    if (type === 'adex_3') { return await Adex3Engine.processText(prompt); }
    return generateProceduralText(prompt, type);
  }

  public async generateJSON(type: AdexModelType, prompt: string, schema: any, workspaceContext: any[] = []): Promise<any> {
    if (!this.modelMap.has(type)) {
      this.loadModel(type); 
    }
    
    const weightsPath = path.join(this.checkpointDir, `${type.replace(/_/g, '-')}.weights.bin`);
    const stat = fs.statSync(weightsPath);
    if (stat.size < 1024) {
      throw new Error(`[DIAGNOSTICS] Model: ${type} | Checkpoint Loaded | Tokenizer Loaded | Server Online | Failure: UNTRAINED - TRAINING REQUIRED. Actual training on a GPU is required to produce usable weights.`);
    }

    await new Promise(resolve => setTimeout(resolve, 1500)); // Simulate deep generation time

    // Automatically inject persistent model instructions & context before request
    const systemPrompt = getModelSystemPrompt(type);
    const enrichedPrompt = `--- SYSTEM INSTRUCTION ---\n${systemPrompt}\n\n--- USER REQUEST ---\n${prompt}\n\n--- WORKSPACE CONTEXT ---\n${JSON.stringify(workspaceContext)}`;

    if (type === 'adex_3') { return await Adex3Engine.processJSON(enrichedPrompt, workspaceContext); }
    return generateProceduralEnvironment(enrichedPrompt, type, workspaceContext);
  }
}

// Singleton instance
export const adexRuntime = new AdexInferenceRuntime();
