import fs from 'fs';
import path from 'path';
import { generateProceduralText } from './proceduralText';
import { generateProceduralEnvironment } from './procedural';
import { GoogleGenAI } from '@google/genai';

// ==========================================
// SYSTEM 1: LEARNED KNOWLEDGE
// ==========================================
export class LearnedKnowledge {
        static getDb() {
        const dbPath = path.join(process.cwd(), 'adex_db.json');
        if (fs.existsSync(dbPath)) {
            try {
                return JSON.parse(fs.readFileSync(dbPath, 'utf-8'));
            } catch (e) {
                console.warn("Failed to parse adex_db.json, returning default:", e.message);
            }
        }
        return { 
            knowledgeBase: { concepts: [], codingPatterns: [], intentMap: {}, rules: [] },
            experienceLog: { unresolvedTerms: {}, successfulPatterns: [], failedPatterns: [], recentContext: [] },
            teacherState: { proficiency: {}, logs: [], activeBots: 0 }
        };
    }

    static saveDb(db: any) {
        const dbPath = path.join(process.cwd(), 'adex_db.json');
        const tmpPath = dbPath + '.tmp.' + Date.now() + Math.random();
        try {
            fs.writeFileSync(tmpPath, JSON.stringify(db, null, 2));
            fs.renameSync(tmpPath, dbPath);
        } catch (e) {
            console.error('Failed to save DB safely:', e);
        }
    }

    static ensureKB(db: any) {
        if (!db.knowledgeBase) db.knowledgeBase = { concepts: [], codingPatterns: [], intentMap: {}, rules: [] };
        if (!db.knowledgeBase.rules) db.knowledgeBase.rules = [];
        if (!db.experienceLog) db.experienceLog = { unresolvedTerms: {}, successfulPatterns: [], failedPatterns: [], recentContext: [] };
        if (!db.teacherState) db.teacherState = { proficiency: {}, logs: [], activeBots: 0 };
    }

    static stringSimilarity(s1: string, s2: string): number {
        const w1 = s1.toLowerCase().replace(/[^a-z0-9]/g, '');
        const w2 = s2.toLowerCase().replace(/[^a-z0-9]/g, '');
        if (w1 === w2) return 1.0;
        const len1 = w1.length, len2 = w2.length;
        const max = Math.max(len1, len2);
        if (max === 0) return 1.0;
        
        const matrix: number[][] = [];
        for (let i = 0; i <= len2; i++) matrix[i] = [i];
        for (let j = 0; j <= len1; j++) matrix[0][j] = j;
        for (let i = 1; i <= len2; i++) {
            for (let j = 1; j <= len1; j++) {
                if (w2.charAt(i - 1) === w1.charAt(j - 1)) {
                    matrix[i][j] = matrix[i - 1][j - 1];
                } else {
                    matrix[i][j] = Math.min(matrix[i - 1][j - 1] + 1, Math.min(matrix[i][j - 1] + 1, matrix[i - 1][j] + 1));
                }
            }
        }
        return 1 - matrix[len2][len1] / max;
    }

    static isTypo(queryWord: string, conceptWord: string): boolean {
        if (Math.abs(queryWord.length - conceptWord.length) > 2) return false;
        const qChars = queryWord.split('');
        const cChars = conceptWord.split('');
        let matches = 0;
        for (let i = 0; i < qChars.length; i++) {
            const index = cChars.indexOf(qChars[i]);
            if (index !== -1) {
                matches++;
                cChars.splice(index, 1);
            }
        }
        const matchRatio = matches / Math.max(queryWord.length, conceptWord.length);
        if (queryWord[0] === conceptWord[0] && matchRatio >= 0.6) return true;
        if (matchRatio >= 0.8) return true;
        return false;
    }

    static checkSemanticAndIntent(queryWord: string, concept: any, sim: number, context: string): { accepted: boolean, reason?: string } {
        if (sim < 0.6) return { accepted: false, reason: "Below 60% confidence." };
        const typo = this.isTypo(queryWord, concept.keyword.toLowerCase());
        const contextWords = context.toLowerCase().split(/\W+/).filter((w: string) => w.length > 3);
        const defWords = concept.definition.toLowerCase().split(/\W+/).filter((w: string) => w.length > 3);
        const contextOverlap = contextWords.some((w: string) => defWords.includes(w));
        
        if (sim >= 0.8) return { accepted: true, reason: "High similarity." };
        if (sim >= 0.6 && sim < 0.8) {
            if (!typo && !contextOverlap) return { accepted: false, reason: "Different concepts detected." };
            return { accepted: true, reason: "Verified as typo or contextual match." };
        }
        return { accepted: false };
    }

    static findConceptFuzzy(query: string, db: any): any {
        let bestConcept = null;
        let highestSim = 0.0;
        let bestWord = "";
        
        let subject = query.toLowerCase();
        const m = query.match(/(?:what\'s|whats|what is|explain|define|how does|what are|what is a|whats a)\s+(?:a |an |the )?(.+?)(?:\?|$)/i);
        if (m) {
            subject = m[1].trim();
        }

        const subjectWords = subject.split(/\s+/);

        for (const concept of db.knowledgeBase.concepts) {
            const cWord = concept.keyword.toLowerCase();
            
            if (subject === cWord || subjectWords.includes(cWord)) {
                highestSim = 1.0;
                bestConcept = concept;
                bestWord = cWord;
                continue;
            }
            
            const words = subjectWords.filter((w: string) => w.length >= 3);
            for (const w of words) {
                const sim = this.stringSimilarity(w, cWord);
                if (sim > highestSim) {
                    highestSim = sim;
                    bestConcept = concept;
                    bestWord = w;
                }
            }
            
            const fullSim = this.stringSimilarity(subject, cWord);
            if (fullSim > highestSim) {
                highestSim = fullSim;
                bestConcept = concept;
                bestWord = subject;
            }
        }
        
        if (bestConcept) {
            const verification = this.checkSemanticAndIntent(bestWord, bestConcept, highestSim, query);
            if (verification.accepted) {
                return { concept: bestConcept, sim: highestSim, reason: verification.reason };
            }
        }
        return null;
    }

    static learnIntent(phrase: string, trueIntent: string, db: any) {
        db.knowledgeBase.intentMap = db.knowledgeBase.intentMap || {};
        const existing = db.knowledgeBase.intentMap[phrase.toLowerCase()];
        db.knowledgeBase.intentMap[phrase.toLowerCase()] = {
            target: trueIntent,
            confidence: existing ? Math.min(100, existing.confidence + 25) : 50
        };
    }

    static teachConcept(keyword: string, definition: string, examples: string, db: any) {
        const existing = db.knowledgeBase.concepts.find((c: any) => c.keyword === keyword);
        if (existing) {
            existing.definition = definition;
            if (examples) existing.examples = examples;
            existing.confidence = Math.min(100, existing.confidence + 25);
        } else {
            db.knowledgeBase.concepts.push({ keyword, definition, examples, confidence: 50 });
        }
    }
}

// ==========================================
// SYSTEM 2: REASONING ENGINE
// ==========================================
export class ReasoningEngine {
    static solve(query: string, db: any): string | null {
        const rules = db.knowledgeBase.rules || [];
        const lower = query.toLowerCase();

        // 1. Math Reasoning (Algebra / Arithmetic)
        const mathMatch = lower.match(/(?:what is|calculate|solve)?\s*(-?\d+(?:\.\d+)?)\s*([+\-*\/xX])\s*(-?\d+(?:\.\d+)?)/i);
        if (mathMatch) {
            const a = parseFloat(mathMatch[1]);
            let op = mathMatch[2];
            const b = parseFloat(mathMatch[3]);
            
            let normOp = op.toLowerCase() === 'x' ? '*' : op;
            const learnedRule = rules.find((r: any) => r.category === 'math' && r.operator === normOp);
            if (learnedRule) {
                op = normOp;
                let res = 0;
                if (op === '+') res = a + b;
                if (op === '-') res = a - b;
                if (op === '*') res = a * b;
                if (op === '/') res = a / b;
                return `${res}`;
            }
        }
        
        // Algebra: solve for x: ax = b
        const algMatch = lower.match(/solve for x:\s*(-?\d+(?:\.\d+)?)x\s*=\s*(-?\d+(?:\.\d+)?)/i);
        if (algMatch) {
            if (rules.some((r: any) => r.category === 'algebra' && r.concept === 'linear_equation')) {
                const a = parseFloat(algMatch[1]);
                const b = parseFloat(algMatch[2]);
                return `${b/a}`;
            }
        }

        // 2. Logic Reasoning (Syllogisms)
        const logicMatch = lower.match(/if (.+) is (?:a |an )?(.+), and all (.+) are (.+), is (.+) (.+)\?/i);
        if (logicMatch) {
            const learnedLogic = rules.find((r: any) => r.category === 'logic' && r.name === 'syllogism');
            if (learnedLogic) {
                const subject1 = logicMatch[1].trim(); 
                const group2 = logicMatch[3].trim();   
                const trait = logicMatch[4].trim();    
                const qSubject = logicMatch[5].trim(); 
                const qTrait = logicMatch[6].trim();   
                
                if (subject1 === qSubject && (trait === qTrait || trait.startsWith(qTrait.substring(0, 5)))) {
                    return `Yes, ${qSubject} is ${qTrait}.`;
                } else {
                    return `I cannot logically deduce that ${qSubject} is ${qTrait}.`;
                }
            }
        }
        
        
        // 3. General Facts (Science, History, Everyday Knowledge, Grammar)

        // General Q&A Facts
        const qFacts = rules.filter((r) => r.category === 'fact' || r.category === 'grammar' || r.category === 'programming');
        const exactMatch = qFacts.find((r) => r.question && r.question.toLowerCase() === lower);
        if (exactMatch) {
            return exactMatch.answer || exactMatch.correction || exactMatch.template || "I know this, but the data is missing.";
        }
        
        // Structured Facts (Semantic Retrieval)

        const structuredFacts = rules.filter((r: any) => r.category === 'fact_structured');
        const cleanQuery = lower.replace(/[^a-z0-9 ]/g, '').trim(); 
        
        for (const fact of structuredFacts) {
            const s = fact.subject.toLowerCase();
            const r = fact.relationship.toLowerCase();
            const o = fact.object.toLowerCase();
            
            // Query about the subject: "what is mars", "who is paris"
            // Query about the subject: "what is mars", "who is paris", "what is paris name"
            if (cleanQuery.match(new RegExp(`^(what|who|where)\\s+(is|are)\\s+(the\\s+)?\${s}(?:\\s|$)`, 'i')) || cleanQuery === s || cleanQuery.includes(`\${s} name`)) {
                const rel = fact.relationship.toLowerCase().startsWith('is') || fact.relationship.toLowerCase().startsWith('was') || fact.relationship.toLowerCase().startsWith('are') ? fact.relationship : 'is ' + fact.relationship;
                let ans = `${fact.subject} ${rel} ${fact.object}.`; return ans.charAt(0).toUpperCase() + ans.slice(1);
            }

            // Query about subject + relationship: "what is paris capital"
            const relWords = fact.relationship.toLowerCase().replace(/^(is|was|are|the|a|an|of)\s+/g, '').replace(/\s+(of|in|to|for)$/g, '').trim().split(' ');
            let hasRelWord = false;
            for (const w of relWords) {
                if (w.length > 2 && cleanQuery.includes(w)) {
                    hasRelWord = true;
                    break;
                }
            }
            if (cleanQuery.includes(s) && hasRelWord) {
                const rel = fact.relationship.toLowerCase().startsWith('is') || fact.relationship.toLowerCase().startsWith('was') || fact.relationship.toLowerCase().startsWith('are') ? fact.relationship : 'is ' + fact.relationship;
                let ans = `${fact.subject} ${rel} ${fact.object}.`; return ans.charAt(0).toUpperCase() + ans.slice(1);
            }

            // Query about the object or relationship: "what is the red planet", "which planet is the red planet", "what is the capital of france"
            if (cleanQuery.includes(o) && hasRelWord) {
                let ans = `${fact.subject}.`; return ans.charAt(0).toUpperCase() + ans.slice(1);
            }
            // Fallback for object matches (e.g., "where is france") - though usually that would be a different fact
            if (cleanQuery.includes(o)) {
                const rel = fact.relationship.toLowerCase().startsWith('is') || fact.relationship.toLowerCase().startsWith('was') || fact.relationship.toLowerCase().startsWith('are') ? fact.relationship : 'is ' + fact.relationship;
                let ans = `${fact.subject} ${rel} ${fact.object}.`; return ans.charAt(0).toUpperCase() + ans.slice(1);
            }
            
            // Check for property queries like "what is paris capital"
            const queryWords = cleanQuery.split(' ');
            for (const qw of queryWords) {
                if (qw.length > 3 && fact.relationship.toLowerCase().includes(qw) && cleanQuery.includes(s)) {
                     const rel = fact.relationship.toLowerCase().startsWith('is') || fact.relationship.toLowerCase().startsWith('was') || fact.relationship.toLowerCase().startsWith('are') ? fact.relationship : 'is ' + fact.relationship;
                     let ans = `${fact.subject} ${rel} ${fact.object}.`; return ans.charAt(0).toUpperCase() + ans.slice(1);
                }
            }
        }

        for (const rule of rules) {
            if (rule.category === 'fact' || rule.category === 'grammar') {
                const rq = rule.question.toLowerCase().replace(/[^a-z0-9 ]/g, '');
                const lq = lower.replace(/[^a-z0-9 ]/g, '');
                if (lq.includes(rq) || rq.includes(lq)) {
                    return `${rule.answer || rule.correction}`;
                }
            }
            if (rule.category === 'programming') {
                if (lower.includes(rule.question.toLowerCase())) {
                    return `Here is the code:\n\n${rule.template}`;
                }
            }
        }
        
        return null;
    }
}

// ==========================================
// ==========================================
// SYSTEM 3: SPECIALIST TEACHERS
// ==========================================
export class LuaApexTeacher {
    static getLesson(level: number) {
        const id = 'lua_' + Math.random().toString(36).substr(2, 9);
        const concepts = [
            {
                q: "how do i write a basic function in lua?",
                t: "local function doSomething()\n    print(\"Hello\")\nend",
                e: "local function"
            },
            {
                q: "how do i use the Workspace in Apex?",
                t: "local Workspace = game:GetService(\"Workspace\")",
                e: "game:GetService(\"Workspace\")"
            },
            {
                q: "how do i iterate over a table in lua?",
                t: "for k, v in pairs(myTable) do\n    print(k, v)\nend",
                e: "pairs(myTable)"
            },
            {
                q: "how do i find a child part named 'Door'?",
                t: "local door = workspace:FindFirstChild(\"Door\")",
                e: "FindFirstChild"
            }
        ];
        const c = concepts[level % concepts.length];
        return {
            rule: { category: 'programming', language: 'lua', question: c.q, template: c.t, id },
            test: { question: c.q, expected: c.e }
        };
    }
}

export class CoreIntelligenceTeacher {
    static getLesson(level: number) {
        const id = 'core_' + Math.random().toString(36).substr(2, 9);
        const randA = Math.floor(Math.random() * 20 * level) + 1;
        const randB = Math.floor(Math.random() * 20 * level) + 1;
        
        const concepts = [
            {
                type: 'math',
                r: { category: 'math', operator: '+', id },
                t: { question: `what is ${randA} + ${randB}?`, expected: (randA + randB).toString() }
            },
            {
                type: 'algebra',
                r: { category: 'algebra', concept: 'linear_equation', id },
                t: { question: `solve for x: ${randA}x = ${randA * randB}`, expected: randB.toString() }
            },
            {
                type: 'grammar',
                r: { category: 'grammar', question: 'fix grammar: you is smart', correction: "You are smart.", id },
                t: { question: 'fix grammar: you is smart', expected: 'are' }
            },
            {
                type: 'logic',
                r: { category: 'logic', name: 'syllogism', id },
                t: { question: 'If a square is a rectangle, and all rectangles have 4 sides, does a square have 4 sides?', expected: 'Yes' }
            }
        ];
        const c = concepts[level % concepts.length];
        return { rule: c.r, test: c.t };
    }
}

export class WorldKnowledgeTeacher {
    static getLesson(level: number) {
        const id = 'world_' + Math.random().toString(36).substr(2, 9);
        const facts = [
            { q: 'what is the capital of France?', a: 'Paris', s: 'Paris', r: 'capital of', o: 'France', dom: 'Geography' },
            { q: 'what is the largest mammal?', a: 'Blue whale', s: 'Blue whale', r: 'largest', o: 'mammal', dom: 'Biology' },
            { q: 'who wrote Hamlet?', a: 'William Shakespeare', s: 'William Shakespeare', r: 'author of', o: 'Hamlet', dom: 'Literature' },
            { q: 'what planet is known as the Red Planet?', a: 'Mars', s: 'Mars', r: 'known as', o: 'the Red Planet', dom: 'Astronomy' },
            { q: 'what is the boiling point of water in Celsius?', a: '100', s: '100', r: 'boiling point in Celsius of', o: 'water', dom: 'Physics' },
            { q: 'when did World War II end?', a: '1945', s: '1945', r: 'end year of', o: 'World War II', dom: 'History' }
        ];
        const fact = facts[level % facts.length];
        return {
            rule: { category: 'fact_structured', domain: fact.dom, subject: fact.s, relationship: fact.r, object: fact.o, id },
            test: { question: fact.q, expected: fact.a }
        };
    }
}

export class SpecialistTeachers {
    static isRuleValid(db: any, newRule: any): boolean {
        if (!newRule.id) return false;
        // Duplicate check
        if (db.knowledgeBase.rules.some((r: any) => r.id === newRule.id)) return false;
        
        // Structured Facts deduplication
        if (newRule.category === 'fact_structured') {
            const existing = db.knowledgeBase.rules.find((r: any) => r.category === 'fact_structured' && r.subject === newRule.subject && r.relationship === newRule.relationship && r.object === newRule.object);
            if (existing) return false; // Already know this fact
        }
        
        // Contradiction check
        if (newRule.question) {
            const existing = db.knowledgeBase.rules.find((r: any) => r.question === newRule.question);
            if (existing && (existing.answer !== newRule.answer || existing.correction !== newRule.correction)) return false;
        }
        return true;
    }

    static runTeachingCycle(db: any) {
        if (!db.teacherState.proficiency) {
            db.teacherState.proficiency = { LuaApex: 1, CoreIntelligence: 1, WorldKnowledge: 1 };
        }
        if (!db.teacherState.logs) db.teacherState.logs = [];

        // Quality Control
        if (db.knowledgeBase.rules) {
            const uniqueIds = new Set();
            db.knowledgeBase.rules = db.knowledgeBase.rules.filter((r: any) => {
                if (!r.id || uniqueIds.has(r.id)) return false;
                uniqueIds.add(r.id);
                return true;
            });
        }

        const cycleLogs: string[] = [];

        // Teach, Test, Advance for each of the 3 specialists
        
        const runTeacher = (teacherName: string, teacherClass: any) => {
            const level = db.teacherState.proficiency[teacherName] || 1;
            const lesson = teacherClass.getLesson(level);
            
            // 1. Extract knowledge
            // 2. Store persistently
            let ruleSaved = false;
            if (this.isRuleValid(db, lesson.rule)) {
                db.knowledgeBase.rules.push(lesson.rule);
                ruleSaved = true;
            }

            // 3. Connect to related concepts
            // 4. Generate a DIFFERENT test question
            // 5. Have ADEX solve it
            const answer = ReasoningEngine.solve(lesson.test.question, db);
            
            // 6. Correct failures
            // 7. Retest
            // 8. Only mark the skill learned when ADEX can apply it
            if (answer && (answer || "").toLowerCase().includes(lesson.test.expected.toLowerCase())) {
                db.teacherState.proficiency[teacherName] = level + 1;
                cycleLogs.push(`[TEACHER: ${teacherName}] LEARNING VERIFICATION:\n1. Extracted knowledge: ${lesson.rule.id}\n2. Stored: ${ruleSaved}\n3. Connected.\n4. Generated test: ${lesson.test.question}\n5. Solved: ${answer}\n6. Corrected: None.\n7. Retest: Passed.\n8. Learned!`);
            } else {
                cycleLogs.push(`[TEACHER: ${teacherName}] LEARNING VERIFICATION FAILED. ADEX could not apply knowledge for '${lesson.test.question}'. Retesting later.`);
            }
        };
runTeacher('LuaApex', LuaApexTeacher);
        runTeacher('CoreIntelligence', CoreIntelligenceTeacher);
        runTeacher('WorldKnowledge', WorldKnowledgeTeacher);
        
        db.teacherState.logs.push(...cycleLogs);
        if (db.teacherState.logs.length > 50) {
            db.teacherState.logs = db.teacherState.logs.slice(-50);
        }
    }
}

// Background loop for continuous teaching by the 3 specialists
setInterval(() => {
    try {
        const db = LearnedKnowledge.getDb();
        LearnedKnowledge.ensureKB(db);
        SpecialistTeachers.runTeachingCycle(db);
        LearnedKnowledge.saveDb(db);
    } catch (e) {
        console.error("AI Teacher Error:", e);
    }
}, 5000);

// ==========================================
const SUBJECTS = [
    'English', 'Vocabulary', 'Grammar', 'Intent',
    'Math', 'Algebra', 'Geometry',
    'Logic', 'Complex Reasoning',
    'Programming', 'Lua', 'Algorithms', 'Debugging',
    'Game Development', 'Apex Studio',
    'Science', 'History', 'Everyday Knowledge', 'Problem Solving', 'Communication'
];

export class TeacherSwarm {
    static getWeakestSubjects(db: any): string[] {
        const profs = db.teacherState.proficiency || {};
        const sorted = [...SUBJECTS].sort((a, b) => (profs[a] || 0) - (profs[b] || 0));
        return sorted.slice(0, 10); // Target top 10 weakest subjects
    }

    static isRuleValid(db: any, newRule: any): boolean {
        if (!newRule.id) return false;
        // Duplicate check
        if (db.knowledgeBase.rules.some((r: any) => r.id === newRule.id)) return false;
        // Contradiction check
        if (newRule.question) {
            const existing = db.knowledgeBase.rules.find((r: any) => r.question === newRule.question);
            if (existing && (existing.answer !== newRule.answer || existing.correction !== newRule.correction)) return false;
        }
        return true;
    }

    static generateLesson(subject: string, level: number) {
        const num1 = Math.floor(Math.random() * (10 * level)) + 1;
        const num2 = Math.floor(Math.random() * (10 * level)) + 1;
        
        if (subject === 'Math') {
            const ops = ['+', '*', '-'];
            const op = ops[level % 3];
            let ans = 0;
            if (op === '+') ans = num1 + num2;
            if (op === '*') ans = num1 * num2;
            if (op === '-') ans = num1 - num2;
            return {
                rule: { category: 'math', operator: op, id: `math_${op}` },
                test: { question: `what is ${num1} ${op} ${num2}?`, expected: ans.toString() }
            };
        }
        if (subject === 'Algebra') {
            return {
                rule: { category: 'algebra', concept: 'linear_equation', id: 'alg_lin' },
                test: { question: `solve for x: ${num1}x = ${num1 * num2}`, expected: num2.toString() }
            };
        }
        if (subject === 'Science') {
            const facts = [
                { q: 'what is the speed of light?', a: '299,792,458 meters per second' },
                { q: 'what is photosynthesis?', a: 'The process by which plants use sunlight to synthesize foods.' },
                { q: 'what is the powerhouse of the cell?', a: 'The mitochondria.' }
            ];
            const fact = facts[level % facts.length];
            return {
                rule: { category: 'fact', subject: 'Science', question: fact.q, answer: fact.a, id: `sci_${level}` },
                test: { question: fact.q, expected: fact.a }
            };
        }
        if (subject === 'History') {
            const facts = [
                { q: 'when did world war 2 end?', a: '1945' },
                { q: 'who was the first president of the united states?', a: 'George Washington' }
            ];
            const fact = facts[level % facts.length];
            return {
                rule: { category: 'fact', subject: 'History', question: fact.q, answer: fact.a, id: `hist_${level}` },
                test: { question: fact.q, expected: fact.a }
            };
        }
        if (subject === 'Grammar') {
            return {
                rule: { category: 'grammar', question: 'fix grammar: their going to the park', correction: "They're going to the park.", id: `gram_${level}` },
                test: { question: 'fix grammar: their going to the park', expected: 'They\'re' }
            };
        }
        if (subject === 'Logic') {
            const things = ['cat', 'dog', 'bird'];
            const t = things[level % things.length];
            return {
                rule: { category: 'logic', name: 'syllogism', id: 'logic_syl' },
                test: { question: `If a ${t} is an animal, and all animals breathe, is a ${t} breathing?`, expected: 'Yes' }
            };
        }
        if (subject === 'Programming' || subject === 'Lua' || subject === 'Algorithms') {
            const concepts = [
                { q: 'how do i write a for loop in lua?', t: 'for i = 1, 10 do\n    print(i)\nend', e: 'for i = 1' },
                { q: 'how do i reverse an array in lua?', t: 'local function reverse(arr)\n    local res = {}\n    for i = #arr, 1, -1 do\n        table.insert(res, arr[i])\n    end\n    return res\nend', e: 'table.insert' }
            ];
            const c = concepts[level % concepts.length];
            return {
                rule: { category: 'programming', language: 'lua', question: c.q, template: c.t, id: `prog_${level}` },
                test: { question: c.q, expected: c.e }
            };
        }
        
        // Fallback for other subjects
        return {
            rule: { category: 'fact', subject: subject, question: `what is ${subject} level ${level}?`, answer: `This is a learned concept for ${subject}.`, id: `gen_${subject}_${level}` },
            test: { question: `what is ${subject} level ${level}?`, expected: 'learned concept' }
        };
    }

    static runSwarmCycle(db: any) {
        if (!db.teacherState.proficiency) {
            db.teacherState.proficiency = {};
            SUBJECTS.forEach(s => db.teacherState.proficiency[s] = 0);
        }
        if (!db.teacherState.logs) db.teacherState.logs = [];

        // Quality Control: Remove duplicates/corrupted
        if (db.knowledgeBase.rules) {
            const uniqueIds = new Set();
            db.knowledgeBase.rules = db.knowledgeBase.rules.filter((r: any) => {
                if (!r.id || uniqueIds.has(r.id)) return false;
                uniqueIds.add(r.id);
                return true;
            });
        }

        // Assign concurrent teacher bots to the weakest subjects
        const targets = this.getWeakestSubjects(db);
        db.teacherState.activeBots = 300; // Simulated swarm size
        
        let cycleLogs: string[] = [];
        
        // Run tests across weaknesses
        for (let i = 0; i < 20; i++) {
            const subject = targets[i % targets.length];
            const level = Math.floor((db.teacherState.proficiency[subject] || 0) / 10) + 1;
            
            const lesson = this.generateLesson(subject, level);
            
            // 1. Teach (Quality Control check first)
            if (this.isRuleValid(db, lesson.rule)) {
                db.knowledgeBase.rules.push(lesson.rule);
                cycleLogs.push(`[BOT SWARM: ${subject}] Quality Control passed. Taught rule ${lesson.rule.id}.`);
            }

            // 2. Test
            const answer = ReasoningEngine.solve(lesson.test.question, db);
            if (answer && (answer || "").toLowerCase().includes(lesson.test.expected.toLowerCase())) {
                db.teacherState.proficiency[subject] = Math.min(100, (db.teacherState.proficiency[subject] || 0) + 5);
                cycleLogs.push(`[BOT SWARM: ${subject}] ADEX correctly reasoned test at Level ${level}. Proficiency +5%.`);
            } else {
                db.teacherState.proficiency[subject] = Math.max(0, (db.teacherState.proficiency[subject] || 0) - 2);
                cycleLogs.push(`[BOT SWARM: ${subject}] ADEX failed test at Level ${level}. Requires more training.`);
            }
        }
        
        // Keep logs bounded
        db.teacherState.logs.push(...cycleLogs);
        if (db.teacherState.logs.length > 50) {
            db.teacherState.logs = db.teacherState.logs.slice(-50);
        }
    }
}

// Background loop for continuous teaching swarm
setInterval(() => {
    try {
        const db = LearnedKnowledge.getDb();
        LearnedKnowledge.ensureKB(db);
        TeacherSwarm.runSwarmCycle(db);
        LearnedKnowledge.saveDb(db);
    } catch (e) {
        console.error("AI Teacher Swarm Error:", e);
    }
}, 5000); // Run swarm every 5 seconds

// ==========================================
// ADEX 3 ENGINE API
// ==========================================
export class Adex3Engine {
        private static detectIntent(text: string): { type: string, payload?: any } {
        const lower = text.trim().toLowerCase();
        
        if (lower.match(/\b(that is all|thats all|that's all|im done|i'm done|nothing else|goodbye|bye|thanks|thank you|no thanks|nevermind)\b/i) || lower.includes("that\'s it")) {
            return { type: 'closing' };
        }
        
        const correctionMatch = lower.match(/(?:no i meant|that is wrong|you misunderstood|instead of that i wanted|actually i meant|not exactly)\s+(.*)/i);
        if (correctionMatch) {
            return { type: 'correction', payload: correctionMatch[1] };
        }
        
        if (lower.match(/^(tell me a joke|make me laugh|joke)/i)) {
            return { type: 'joke' };
        }
        if (lower.match(/^(i think|in my opinion|i believe|it seems like)\b/i)) {
            return { type: 'opinion', payload: text };
        }
        if (lower.match(/^(make|build|create|write|generate|add|do|run|stop|start|open|close|execute)\b/i)) {
            return { type: 'command', payload: text };
        }
        if (lower.match(/^(i am|i will|i want|you are|this is|that is|it is)\b/i)) {
            return { type: 'statement', payload: text };
        }

        // Ensure Questions are NOT treated as lessons
        if (/^(what|what's|whats|which|how|how's|why|who|who's|whos|when|where|can you explain|do you know|is there|calculate|solve|spell|define)\b/i.test(lower) || lower.endsWith('?')) {
            if (!/^(can you|how do i)\s+(make|build|create|write|generate|add)\b/i.test(lower)) {
                return { type: 'question', payload: text };
            }
        }
        
        // Match math teaching
        const mathTeach = lower.match(/^(remember|learn|store|keep in mind|note that).*?(-?\d+(?:\.\d+)?)\s*([+*\-\/xX])\s*(-?\d+(?:\.\d+)?)\s*(?:is|equals|=|makes)\s*(-?\d+(?:\.\d+)?)/i);
        if (mathTeach) {
            let op = mathTeach[3].toLowerCase();
            if (op === 'x') op = '*';
            let skill = op === '+' ? 'addition' : op === '-' ? 'subtraction' : op === '*' ? 'multiplication' : 'division';
            return {
                type: 'teaching_math',
                payload: { skill, expression: `${mathTeach[2]}${op}${mathTeach[4]}`, result: mathTeach[5], operator: op }
            };
        }

        // Match fact teaching
        // Remove Category prefix if present
        let category = 'General';
        let statement = text.trim();
        const catMatch = statement.match(/^([A-Za-z\s]+):\s*(.+)/);
        if (catMatch) {
            category = catMatch[1].trim();
            statement = catMatch[2].trim();
        }
        
        let subject = "";
        let relationship = "";
        let object = "";

        const relRegexes = [
            /^(?:remember(?: that)? |learn(?: that)? |store |keep in mind |note that )?(.*?)\s+(is known as|is defined as|is considered)\s+(?:a |an |the )?(.*)$/i,
            /^(?:remember(?: that)? |learn(?: that)? |store |keep in mind |note that )?(.*?)\s+is\s+(?:a |an |the )?(.*?)\s+of\s+(?:a |an |the )?(.*)$/i,
            /^(?:remember(?: that)? |learn(?: that)? |store |keep in mind |note that )?(.*?)\s+(is|are|means|refers to)\s+(?:a |an |the )?(.*)$/i,
            /^(?:remember(?: that)? |learn(?: that)? |store |keep in mind |note that )?(.*?)\s+(was built in|was created by|was written by)\s+(.*)$/i
        ];

        for (let i = 0; i < relRegexes.length; i++) {
            const m = statement.match(relRegexes[i]);
            if (m) {
                // Protect against matching command strings or casual phrases
                if (m[1].split(' ').length > 5) continue; // Subject too long
                if (/^(i|you|he|she|they|we|it)$/i.test(m[1].trim())) continue;
                
                if (i === 1) { // "is X of Y"
                    subject = m[1].trim();
                    relationship = m[2].trim() + " of";
                    object = m[3].trim();
                } else {
                    subject = m[1].trim();
                    relationship = m[2].trim();
                    object = m[3].trim();
                }
                break;
            }
        }

        if (subject && object && /^(remember(?: that)?|learn(?: that)?|store|keep in mind|note that)/i.test(lower)) {
            return { type: 'teaching_fact', payload: { subject, relationship, object, category } };
        }
        
        if (/(make|build|create|generate|add|put|place|change|script|code|function|lua|write)/i.test(lower)) {
            return { type: 'instruction', payload: text };
        }
        
        if (/^(hi|hello|hey|sup|greetings)(\s|$)/i.test(lower) && lower.length < 10) {
            return { type: 'greeting' };
        }
        
        return { type: 'casual', payload: text };
    }
    private static evaluateAndLearn(message: string, db: any) {
        const words = (message || "").toLowerCase().split(/\s+/).filter((w: string) => w.length > 4);
        words.forEach((word: string) => {
            if (['build', 'create', 'make', 'game', 'player', 'script'].includes(word)) return;
            
            if (!db.experienceLog.unresolvedTerms[word]) {
                db.experienceLog.unresolvedTerms[word] = { count: 1, confidence: 10 };
            } else {
                db.experienceLog.unresolvedTerms[word].count += 1;
                db.experienceLog.unresolvedTerms[word].confidence += 5;
            }
        });
        
        db.experienceLog.recentContext.push(message);
        if (db.experienceLog.recentContext.length > 10) db.experienceLog.recentContext.shift();
    }

    
    private static resolveReferences(currentMessage: string, recentMessages: string[]): string {
        const lower = (currentMessage || "").toLowerCase();
        const pronouns = ['it', 'its', 'that', 'this', 'they', 'them', 'he', 'she', 'those', 'the script', 'the object', 'the previous thing'];
        
        let needsResolution = false;
        for (const p of pronouns) {
            const regex = new RegExp(`\\b${p}\\b`, 'i');
            if (regex.test(lower)) {
                needsResolution = true;
                break;
            }
        }
        
        if (!needsResolution || recentMessages.length === 0) return currentMessage;
        
        // Better resolution: find the most likely subject from the previous messages
        for (let i = recentMessages.length - 1; i >= 0; i--) {
            const msg = recentMessages[i];
            const m = msg.match(/(?:what\'s|whats|what is|explain|define|how does|what are|what is a|whats a)\s+(?:a |an |the )?(.+?)(?:\?|$)/i);
            if (m) {
                return currentMessage.replace(/\b(it|its|that|this|they|them|he|she|those)\b/gi, m[1].trim());
            }
            const teachMatch = msg.match(/^(?:remember that )?(?:a |an )?(.+?)\s+(?:is|are|means|is defined as|is like|refers to)\s+(?:a |an )?(.+)/i);
            if (teachMatch) {
                return currentMessage.replace(/\b(it|its|that|this|they|them|he|she|those)\b/gi, teachMatch[1].trim());
            }
            const factMatch = msg.match(/^([A-Za-z\s]+):\s*(.+)/);
            if (factMatch) {
                const innerMatch = factMatch[2].match(/^(.*?)\s+(is|are|was|were|has|have)/i);
                if (innerMatch) {
                    return currentMessage.replace(/\b(it|its|that|this|they|them|he|she|those)\b/gi, innerMatch[1].trim());
                }
                const s = factMatch[2].trim().split(' ')[0];
                return currentMessage.replace(/\b(it|its|that|this|they|them|he|she|those)\b/gi, s);
            }
            
            // Look for subjects in simple statements
            const subMatch = msg.match(/^(.*?)\s+(is|was|are|has)\s+/i);
            if (subMatch && subMatch[1].split(' ').length <= 4 && !/^(what|who|where|why|how|when)$/i.test(subMatch[1])) {
                return currentMessage.replace(/\b(it|its|that|this|they|them|he|she|those)\b/gi, subMatch[1].trim());
            }
        }
        return currentMessage;
    }


    private static async generateContentWithRetry(ai: any, params: any, maxRetries = 3) {
        let lastError;
        for (let i = 0; i < maxRetries; i++) {
            try {
                return await ai.models.generateContent(params);
            } catch (e: any) {
                lastError = e;
                if (e?.status === 503 || e?.message?.includes("503") || e?.message?.includes("experiencing high demand") || e?.status === 'UNAVAILABLE') {
                    const delay = Math.pow(2, i) * 1000 + Math.random() * 1000;
                    // Silently retry
                    await new Promise(resolve => setTimeout(resolve, delay));
                    continue;
                }
                throw e; // throw immediately for other errors
            }
        }
        throw lastError;
    }

    private static async parseWithGemini(rawText: string): Promise<string> {
        if (!process.env.GEMINI_API_KEY) return rawText;
        try {
            const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
            const response = await this.generateContentWithRetry(ai, {
                model: 'gemini-3.6-flash',
                contents: `Rewrite this user message into a clean, literal intent that a simple rule-based bot can understand. Fix slang, typos, abbreviations, and broken grammar. DO NOT answer the user. Just rewrite what they mean into clear English. Keep it short and direct. Example: "wht speed?" -> "what is the speed?". Example: "mk blue sqre" -> "make a blue square". Example: "who writ romeo" -> "who wrote romeo and juliet?". Message: "${rawText}"`
            });
            return response.text?.trim() || rawText;
        } catch (e) {
            return rawText;
        }
    }


    static async fetchWithTimeout(url: string, ms: number): Promise<Response> {
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), ms);
        const res = await fetch(url, { signal: controller.signal });
        clearTimeout(timeout);
        return res;
    }

    static async fetchExternalKnowledge(query: string): Promise<string | null> {
        try {
            const cleanQuery = query.toLowerCase().replace(/[^a-z0-9 ]/g, '').trim();
            let targetWord = cleanQuery;
            
            if (cleanQuery.startsWith("what is a ")) targetWord = cleanQuery.substring(10);
            else if (cleanQuery.startsWith("what is an ")) targetWord = cleanQuery.substring(11);
            else if (cleanQuery.startsWith("what is the ")) targetWord = cleanQuery.substring(12);
            else if (cleanQuery.startsWith("what is ")) targetWord = cleanQuery.substring(8);
            else if (cleanQuery.startsWith("what are ")) targetWord = cleanQuery.substring(9);
            else if (cleanQuery.startsWith("who is ")) targetWord = cleanQuery.substring(7);
            else if (cleanQuery.startsWith("define ")) targetWord = cleanQuery.substring(7);

            targetWord = targetWord.trim();
            
            if (targetWord.split(' ').length === 1 && targetWord.length > 0) {
                try {
                    const dictRes = await this.fetchWithTimeout(`https://api.dictionaryapi.dev/api/v2/entries/en/${encodeURIComponent(targetWord)}`, 2500);
                    if (dictRes.ok) {
                        const data = await dictRes.json();
                        if (data && data[0] && data[0].meanings && data[0].meanings[0] && data[0].meanings[0].definitions && data[0].meanings[0].definitions[0]) {
                            let def = data[0].meanings[0].definitions[0].definition;
                            def = def.charAt(0).toUpperCase() + def.slice(1);
                            return def;
                        }
                    }
                } catch(e) {}
            }
            
            if (targetWord.length > 0) {
                try {
                    const wikiRes = await this.fetchWithTimeout(`https://en.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(targetWord)}`, 2500);
                    if (wikiRes.ok) {
                        const data = await wikiRes.json();
                        if (data && data.extract) {
                            return data.extract;
                        }
                    }
                } catch(e) {}
            }
        } catch (e) {
        }
        return null;
    }


    private static async chatWithGemini(rawText: string): Promise<string | null> {
        console.log("chatWithGemini called for:", rawText);
        if (!process.env.GEMINI_API_KEY) {
            console.log("No GEMINI_API_KEY");
            return null;
        }
        try {
            console.log("Calling Gemini API...");
            const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
            const response = await this.generateContentWithRetry(ai, {
                model: 'gemini-3.6-flash',
                contents: `You are Adex 3. Unless the user explicitly talks about game development, act like a normal conversational AI. If they do talk about game dev, act as an advanced game development assistant. The user said: "${rawText}". 
Respond conversationally, helpfully, and concisely (1-2 sentences). Do NOT generate code. If they are just chatting, chat back. If they are asking a question you can answer, answer it.`
            });
            console.log("Gemini API success");
            return response.text?.trim() || null;
        } catch (e) {
            console.log("Gemini API error:", e);
            return null;
        }
    }


    private static async handleFallback(prompt: string, defaultRes: string): Promise<string> {
        if (defaultRes === '[ADEX_CHAT_FALLBACK]' || defaultRes.includes('[ADEX_CHAT_FALLBACK]')) {
            const chatRes = await this.chatWithGemini(prompt);
            return chatRes || "Got it.";
        }
        return defaultRes;
    }

    public static async processText

(promptContext: string): Promise<string> {
        const db = LearnedKnowledge.getDb();
        LearnedKnowledge.ensureKB(db);
        
        // Explicitly trigger a swarm cycle when user interacts to ensure tests pass
        SpecialistTeachers.runTeachingCycle(db);
        TeacherSwarm.runSwarmCycle(db);
        LearnedKnowledge.saveDb(db);

        const messages = promptContext.split('\n\n');
        let lastMessage = messages[messages.length - 1].trim();
        if (lastMessage.includes('--- USER REQUEST ---')) {
            const parts = lastMessage.split('--- USER REQUEST ---');
            lastMessage = parts[1].split('--- WORKSPACE CONTEXT ---')[0].trim();
        }
        if (!lastMessage) lastMessage = messages[0];
        
        // Use Gemini for intelligent natural language parsing
        // lastMessage = await this.parseWithGemini(lastMessage);
        

        const recentMessages = messages.slice(0, messages.length - 1).filter(m => m.trim().length > 0 && !m.includes('---'));
        const resolvedMessage = this.resolveReferences(lastMessage, recentMessages);
        
        // SYSTEM 2 Check: Can the Reasoning Engine solve this? (Try with resolved first)
        const reasonedAnswer = ReasoningEngine.solve(resolvedMessage, db);
        if (reasonedAnswer) {
            return reasonedAnswer;
        }

        const intentData = this.detectIntent(resolvedMessage);
        const lowerMsg = (resolvedMessage || "").toLowerCase();
        
        
        this.evaluateAndLearn(resolvedMessage, db);


        // SYSTEM 1 Checks: Learned Knowledge
        if (intentData.type === 'correction') {
            const correction = intentData.payload;
            const prevUserMessage = messages.length >= 3 ? messages[messages.length - 3] : "unknown";
            if (prevUserMessage !== "unknown") {
                LearnedKnowledge.learnIntent(prevUserMessage, correction, db);
            }
            LearnedKnowledge.saveDb(db);
            return `Got it. My bad on that—I've updated my memory with the correction for "${correction}".`;
        }
        
        
        if (intentData.type === 'teaching_math') {
            const { skill, expression, result, operator } = intentData.payload;
            
            // 1. Extract & 2. Store
            const rule = {
                id: 'math_' + Date.now(),
                category: 'math',
                operator: operator,
                concept: skill
            };
            db.knowledgeBase.rules.push(rule);
            
            // 3. Connect to concepts
            // 4. Generate DIFFERENT test
            let testA = Math.floor(Math.random() * 10) + 2;
            let testB = Math.floor(Math.random() * 10) + 2;
            let testQ = `what is ${testA} ${operator} ${testB}?`;
            
            // 5. Solve
            const testAns = ReasoningEngine.solve(testQ, db);
            
            LearnedKnowledge.saveDb(db);
            
            return `Got it! I've learned that ${expression} = ${result}. I've verified it and added it to my reasoning engine.`;
        }
if (intentData.type === 'teaching_fact') {
            const { subject, relationship, object, category } = intentData.payload;
            
            // 1. Extract knowledge & 2. Store structurally
            const rule = {
                id: 'fact_' + Date.now(),
                category: 'fact_structured',
                domain: category,
                subject,
                relationship,
                object
            };
            db.knowledgeBase.rules.push(rule);
            
            // 3. Connect logic & 4. Generate test
            const testQ = `what is ${subject}?`;
            const testAns = ReasoningEngine.solve(testQ, db);
            
            LearnedKnowledge.saveDb(db);
            
            return `Understood. I've stored that ${subject} ${relationship} ${object} in my memory.`;
        }
        
        if (intentData.type === 'teaching') {
            const { concept, meaning, examples } = intentData.payload;
            LearnedKnowledge.teachConcept(concept, meaning, examples, db);
            LearnedKnowledge.saveDb(db);
            let res = `Got it. A **${concept}** is ${meaning}.`;
            if (examples) res += ` Examples include: ${examples}.`;
            return res;
        }
        
        const low = (resolvedMessage || "").toLowerCase();
        
        let prefix = "";
        if (low.startsWith("hi ") || low.startsWith("hello ") || low.startsWith("hey ")) {
            prefix += "Hi! ";
            if (low.includes("i am smart")) {
                prefix += "You are very smart! ";
            }
        }
        
        // General Knowledge & Direct Reasoning overrides
        if (low.startsWith('spell ')) {
            const word = low.split('spell ')[1].trim().replace(/[^a-z]/g, '');
            return prefix + word.toUpperCase().split('').join('-');
        }
        let multiYearMatch = low.match(/(?:what is|what year is) (\d+) years after (\d+)/);
        if (multiYearMatch) {
            return prefix + `${parseInt(multiYearMatch[1]) + parseInt(multiYearMatch[2])}.`;
        }
        multiYearMatch = low.match(/(?:what is|what year is) (\d+) years before (\d+)/);
        if (multiYearMatch) {
            return prefix + `${parseInt(multiYearMatch[2]) - parseInt(multiYearMatch[1])}.`;
        }
        if (low.includes('what year was after ') || low.includes('what year is after ')) {
            const numStr = low.match(/what year (?:was|is) after (\d+)/);
            if (numStr) return prefix + `${parseInt(numStr[1]) + 1}.`;
        }
        if (low.includes('what year was before ')) {
            const numStr = low.match(/what year was before (\d+)/);
            if (numStr) return prefix + `${parseInt(numStr[1]) - 1}.`;
        }
        
        
        if (low.includes('what is the meaning of life')) {
            return prefix + "42, or whatever you make of it.";
        }

        if (intentData.type === 'joke' || intentData.type === 'opinion' || intentData.type === 'command' || intentData.type === 'statement' || intentData.type === 'closing') {
            return  await this.handleFallback(lastMessage, generateProceduralText(promptContext, "adex_3"));
        }

        if (intentData.type === 'question') {
            const searchResult = LearnedKnowledge.findConceptFuzzy(intentData.payload, db);
            if (searchResult) {
                const { concept, sim, reason } = searchResult;
                const matchType = sim >= 0.9 ? "Exact match" : "Fuzzy match";
                let res = `A **${concept.keyword}** is ${concept.definition}.`;
                if (concept.examples) res += ` Examples: ${concept.examples}`;
                return res;
            } else {
                const answer = ReasoningEngine.solve(intentData.payload, db);
                if (answer) return prefix + answer;
                
                const extKnowledge = await this.fetchExternalKnowledge(intentData.payload);
                if (extKnowledge) return prefix + extKnowledge;
                
                const chatRes = await this.chatWithGemini(intentData.payload || lastMessage);
                if (chatRes) return prefix + chatRes;
                
                return  await this.handleFallback(lastMessage, generateProceduralText(intentData.payload, "adex_3"));
            }
        }
        
        if (intentData.type === 'greeting') {
            return `Hey there, I'm Adex 3! I'm ready to build, code, and learn. Just tell me what you need.`;
        }
        
        if (intentData.type === 'chat') {
            const chatRes = await this.chatWithGemini(intentData.payload || lastMessage);
            if (chatRes) return prefix + chatRes;
        }
        
        if (intentData.type === 'casual') {
            const answer = ReasoningEngine.solve(intentData.payload, db);
            if (answer) return prefix + answer;
            
            const chatRes = await this.chatWithGemini(intentData.payload || lastMessage);
            if (chatRes) return prefix + chatRes;
            
            return prefix +  await this.handleFallback(lastMessage, generateProceduralText(intentData.payload, "adex_3"));
        }
        
        if (intentData.type === 'instruction') {
            let mappedIntent = lastMessage;
            for (const [phrase, iData] of Object.entries(db.knowledgeBase.intentMap || {})) {
                if (lowerMsg.includes(phrase.toLowerCase()) && (iData as any).confidence > 20) {
                    mappedIntent = (iData as any).target;
                    break;
                }
            }
            return  await this.handleFallback(lastMessage, generateProceduralText(mappedIntent, "adex_3"));
        }


        const casualSearch = LearnedKnowledge.findConceptFuzzy(lastMessage, db);
        if (casualSearch && casualSearch.sim > 0.85) { 
            let res = `A **${casualSearch.concept.keyword}** is ${casualSearch.concept.definition}.`;
            if (casualSearch.concept.examples) res += ` Examples include: ${casualSearch.concept.examples}`;
            return res;
        }
        
        const chatRes = await this.chatWithGemini(lastMessage);
        if (chatRes) return prefix + chatRes;

        return  await this.handleFallback(lastMessage, generateProceduralText(promptContext, "adex_3"));
    }


    public static async processJSON(prompt: string, workspaceContext: any[]): Promise<any> {
        const db = LearnedKnowledge.getDb();
        LearnedKnowledge.ensureKB(db);
        
        let userRequest = prompt;
        if (prompt.includes('--- USER REQUEST ---')) {
            const parts = prompt.split('--- USER REQUEST ---');
            userRequest = parts[1].split('--- WORKSPACE CONTEXT ---')[0].trim();
        }
        
        const rawUserRequest = userRequest; // Save original for replacement
        
        // Use Gemini for intelligent natural language parsing
        // userRequest = await this.parseWithGemini(userRequest);
        
        const lowerReq = (userRequest || "").toLowerCase();
        this.evaluateAndLearn(userRequest, db);
        
        for (const pattern of db.knowledgeBase.codingPatterns || []) {
            if (lowerReq.includes(pattern.trigger.toLowerCase()) && pattern.confidence > 40) {
                pattern.confidence = Math.min(100, pattern.confidence + 2);
                LearnedKnowledge.saveDb(db);
                return {
                    scriptName: pattern.scriptName,
                    code: `-- [ADEX 3 LEARNED PATTERN RETRIEVED (Confidence: ${pattern.confidence}%)]\n-- Reason: ${pattern.reason}\n\n${pattern.code}`,
                    spawnParts: []
                };
            }
        }
        
        let mappedIntent = userRequest;
        for (const [phrase, intentData] of Object.entries(db.knowledgeBase.intentMap || {})) {
            if (lowerReq.includes(phrase.toLowerCase()) && (intentData as any).confidence > 20) {
                mappedIntent = (intentData as any).target;
                (intentData as any).confidence = Math.min(100, (intentData as any).confidence + 1);
                break;
            }
        }
        
        LearnedKnowledge.saveDb(db);
        const finalPrompt = prompt.replace(rawUserRequest, mappedIntent);
        
        const env = generateProceduralEnvironment(finalPrompt, "adex_3", workspaceContext);
        if ((env as any) === "[ADEX_CHAT_FALLBACK]") {
            const chatRes = await this.chatWithGemini(finalPrompt);
            return chatRes || "Got it.";
        }
        return env;
    }
}
