export class AdexTokenizer {
  private vocab: Map<string, number>;
  private inverseVocab: Map<number, string>;

  constructor() {
    this.vocab = new Map();
    this.inverseVocab = new Map();
    // Initialize base vocabulary
    this.addToken('<|endoftext|>', 0);
    this.addToken('<|padding|>', 1);
    this.addToken('<|system|>', 2);
    this.addToken('<|user|>', 3);
    this.addToken('<|model|>', 4);
  }

  private addToken(token: string, id: number) {
    this.vocab.set(token, id);
    this.inverseVocab.set(id, token);
  }

  encode(text: string): number[] {
    // Simple mock tokenizer - in reality this would use BPE (Byte Pair Encoding) or WordPiece
    const tokens = text.split(' ').map(word => {
      const id = this.vocab.get(word);
      return id !== undefined ? id : 0; // fallback to unk/0
    });
    return tokens;
  }

  decode(tokens: number[]): string {
    return tokens.map(id => this.inverseVocab.get(id) || '').join(' ');
  }
}
