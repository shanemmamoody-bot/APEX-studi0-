import { adexRuntime } from "./adex/inference";

export type AIModelId = 'apex_spark' | 'adex_spark_2' | 'odex_forge' | 'odex_latest' | 'adex_3_preview' | 'adex_3';

export interface ModelPipelineConfig {
  id: AIModelId;
  name: string;
  passesCount: number;
}

export const MODEL_CONFIGS: Record<AIModelId, ModelPipelineConfig> = {
  apex_spark: { id: 'apex_spark', name: 'Apex Spark', passesCount: 1 },
  adex_spark_2: { id: 'adex_spark_2', name: 'Adex Spark 2', passesCount: 1 },
  odex_forge: { id: 'odex_forge', name: 'Odex Forge', passesCount: 2 },
  odex_latest: { id: 'odex_latest', name: 'Odex Latest', passesCount: 2 },
  adex_3_preview: { id: 'adex_3_preview', name: 'Adex 3 Preview', passesCount: 4 },
  adex_3: { id: 'adex_3', name: 'Adex 3', passesCount: 8 }
};

export async function runAICoderPipeline(options: {
  prompt: string;
  workspaceContext?: any[];
  aiModel?: AIModelId;
}) {
  const modelId = options.aiModel || 'adex_3_preview';
  
  if (modelId === 'adex_3_preview' || modelId === 'adex_3' || modelId === 'apex_spark' || modelId === 'adex_spark_2' || modelId === 'odex_forge' || modelId === 'odex_latest') {
    return await adexRuntime.generateJSON(modelId as any, options.prompt, {}, options.workspaceContext || []);
  }
  
  throw new Error(`${String(modelId).toUpperCase().replace(/_/g, ' ')} IS UNTRAINED — TRAINING REQUIRED.`);
}

export async function runAIOwnerPublisherPipeline(options: {
  level: 'LOW' | 'MEDIUM' | 'HIGH';
  aiModel?: AIModelId;
}) {
  const modelId = options.aiModel || 'adex_3_preview';

  if (modelId === 'adex_3_preview' || modelId === 'adex_3' || modelId === 'apex_spark' || modelId === 'adex_spark_2' || modelId === 'odex_forge' || modelId === 'odex_latest') {
    return await adexRuntime.generateJSON(modelId as any, `Level: ${options.level}`, {});
  }

  throw new Error(`${String(modelId).toUpperCase().replace(/_/g, ' ')} IS UNTRAINED — TRAINING REQUIRED.`);
}
