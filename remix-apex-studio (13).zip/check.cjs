const fs = require('fs');
const esbuild = require('esbuild');

try {
  esbuild.buildSync({
    entryPoints: ['server.ts'],
    bundle: true,
    platform: 'node',
    format: 'cjs',
    packages: 'external',
    outfile: 'dist/server.cjs'
  });
  console.log("SUCCESS");
} catch(e) {
  console.error(e.message);
}
