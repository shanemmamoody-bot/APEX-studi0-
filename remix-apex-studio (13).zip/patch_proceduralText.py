import sys

with open("src/server/adex/proceduralText.ts", "r") as f:
    text = f.read()

replacement = """    if (plan.intent === 'joke') {
        const jokes = [
            "Why do programmers prefer dark mode? Because light attracts bugs.",
            "I would tell you a joke about UDP, but you might not get it.",
            "There are 10 types of people in the world: those who understand binary, and those who don't."
        ];
        return jokes[Math.floor(Math.random() * jokes.length)];
    }
    
    if (plan.intent === 'opinion') {
        return `That's an interesting perspective! Since I'm an AI, I don't have personal opinions, but I can definitely understand why you would think that about ${plan.primarySubject || 'this topic'}.`;
    }
    
    if (plan.intent === 'statement') {
        return `I understand. You're saying that ${lastMessage.toLowerCase()}. Let's use that as context going forward.`;
    }
    
    if (plan.intent === 'chat') {
        // Conversational handling
        if (lastMessage.toLowerCase().includes("how are you")) {
            return "I'm doing well, thanks for asking! Ready to help you build or chat about whatever you'd like.";
        }
        if (lastMessage.toLowerCase().match(/^(yes|yeah|yep|sure|ok|okay)$/i)) {
            return "Great! Let me know what you'd like to do next.";
        }
        if (lastMessage.toLowerCase().match(/^(no|nope|nah)$/i)) {
            return "No problem. We can take a different approach.";
        }
        return `That sounds interesting. Tell me more about that.`;
    }

    if (plan.intent === 'question') {
        if (lastMessage.toLowerCase().includes("what can you do") || lastMessage.toLowerCase().includes("who are you")) {
            return `I am ${identity}, an advanced AI engine. I can help you write code, build 3D environments, brainstorm ideas, and have natural conversations!`;
        }
        return `That's a good question about ${plan.primarySubject || 'that topic'}. I'm continually learning, but I'm here to help you figure it out. What exactly do you want to achieve?`;
    }

    if (modelId === "adex_3") return `Got it. Let's focus on ${plan.primarySubject || 'that'}. What's the plan?`;"""

text = text.replace('    if (modelId === "adex_3") return `Got it. You mentioned "${lastMessage}". We can brainstorm that, write the code, or build the environment. Where do you want to start?`;', replacement)

with open("src/server/adex/proceduralText.ts", "w") as f:
    f.write(text)
