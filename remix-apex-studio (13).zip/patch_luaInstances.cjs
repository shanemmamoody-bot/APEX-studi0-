const fs = require('fs');
let code = fs.readFileSync('src/utils/lua/luaInstances.ts', 'utf-8');

code = code.replace(
  "    model.BehaviorTriggered = Signal.new()",
  `    model.BehaviorTriggered = Signal.new()
    
    -- Advanced AI Scripting Bridge Events
    model.OnTame = Signal.new()
    model.OnAttack = Signal.new()
    model.OnIdle = Signal.new()
    model.OnHeal = Signal.new()
    model.OnPatrol = Signal.new()
    model.OnFollow = Signal.new()`
);

fs.writeFileSync('src/utils/lua/luaInstances.ts', code);
