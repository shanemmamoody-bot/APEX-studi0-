const fs = require('fs');
const db = JSON.parse(fs.readFileSync('./adex_db.json', 'utf8'));

const rules = db.knowledgeBase.rules || [];
const lower = "what is my game speed".toLowerCase();

const structuredFacts = rules.filter(r => r.category === 'fact_structured');
const cleanQuery = lower.replace(/[^a-z0-9 ]/g, '').trim();
console.log("cleanQuery:", cleanQuery);

let found = null;
for (const fact of structuredFacts) {
    if (fact.subject === 'my game speed') {
        console.log("Found fact:", fact);
        const s = fact.subject.toLowerCase();
        const r = fact.relationship.toLowerCase();
        const o = fact.object.toLowerCase();
        
        const regexStr = `^(what|who|where)\\s+(is|are)\\s+(the\\s+)?${s}`;
        const regex = new RegExp(regexStr, 'i');
        console.log("Regex string:", regexStr);
        console.log("Regex object:", regex);
        
        const match = cleanQuery.match(regex);
        console.log("Match:", match);
        
        if (match || cleanQuery === s || cleanQuery.includes(`${s} name`)) {
            console.log("Condition met!");
            const rel = fact.relationship.toLowerCase().startsWith('is') || fact.relationship.toLowerCase().startsWith('was') || fact.relationship.toLowerCase().startsWith('are') ? fact.relationship : 'is ' + fact.relationship;
            let ans = `${fact.subject} ${rel} ${fact.object}.`;
            found = ans.charAt(0).toUpperCase() + ans.slice(1);
        }
    }
}
console.log("Final answer:", found);
