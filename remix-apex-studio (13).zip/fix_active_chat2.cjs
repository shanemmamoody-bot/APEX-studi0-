const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf-8');
const searchStr = `const [isTesting, setIsTesting] = useState(false);`;
code = code.replace(searchStr, searchStr + "\n  const [activeNpcChat, setActiveNpcChat] = useState<any>(null);");
fs.writeFileSync('src/App.tsx', code);
