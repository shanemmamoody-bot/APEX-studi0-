const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf-8');

const targetStr = `      // Format history
      let promptText = systemInstruction + "\\n\\nChat History:\\n";
      for (const msg of history) {
        if (msg.role === 'user') {
          promptText += \`\${playerName}: \${msg.text}\\n\`;
        } else {
          promptText += \`\${npcName}: \${msg.text}\\n\`;
        }
      }
      promptText += \`\\n\${npcName}:\`;

      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: promptText,
      });
      
      const reply = response.text || "I have nothing to say right now.";
      res.json({ reply });`;

const replaceStr = `      // Format history
      const contents = history.map((msg: any) => ({
        role: msg.role === 'user' ? 'user' : 'model',
        parts: [{ text: msg.text }]
      }));

      const tools = [{
        functionDeclarations: [
          {
            name: "change_behavior",
            description: "Changes the NPC's AI behavior mode in the game engine. Call this if the conversation implies you should attack the player, follow them, guard, flee, etc.",
            parameters: {
              type: "OBJECT",
              properties: {
                newMode: {
                  type: "STRING",
                  description: "The new AI mode to switch to.",
                  enum: ["Attack", "Follow", "Flee", "Guard", "Wander", "Idle", "Heal"]
                },
                reason: {
                  type: "STRING",
                  description: "A short reason why the state is changing, which will be said by the NPC."
                }
              },
              required: ["newMode"]
            }
          }
        ]
      }];

      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents,
        config: {
          systemInstruction,
          tools
        }
      });
      
      let reply = response.text || "I have nothing to say right now.";
      let action = null;
      
      if (response.functionCalls && response.functionCalls.length > 0) {
        const fc = response.functionCalls[0];
        if (fc.name === "change_behavior") {
          const args = fc.args as any;
          action = args.newMode;
          reply = args.reason || \`I will now \${action.toLowerCase()}.\`;
        }
      }

      res.json({ reply, action });`;

code = code.replace(targetStr, replaceStr);
fs.writeFileSync('server.ts', code);
