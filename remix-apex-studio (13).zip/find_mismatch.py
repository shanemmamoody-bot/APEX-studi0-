with open('src/App.tsx', 'r') as f:
    text = f.read()

import re
# Remove single line comments
text = re.sub(r'//.*', '', text)
# Remove string literals
text = re.sub(r'(["\'`])(?:(?=(\\?))\2.)*?\1', '""', text, flags=re.DOTALL)
# Remove JSX text? No, too hard with regex.

stack = []
lines = text.split('\n')
for idx, line in enumerate(lines):
    for c in line:
        if c in '{(':
            stack.append((c, idx+1))
        elif c == '}':
            if stack and stack[-1][0] == '{':
                stack.pop()
            else:
                pass
        elif c == ')':
            if stack and stack[-1][0] == '(':
                stack.pop()
            else:
                pass

for s in stack:
    print(f"Unclosed {s[0]} at line {s[1]}")
