import re

with open('server.ts', 'r') as f:
    text = f.read()

text = re.sub(r'activeGameSessions\.get\(bot\.gameId\)\?\.delete\(bot\.username\.toLowerCase\(\)\);\s*botClients\.delete\(botId\);\s*continue;\s*\}\s*bot\.facingYaw.*?activeGameSessions\.has\(bot\.gameId\)\) \{.*?\}\s*\}\},\s*1000\);', '', text, flags=re.DOTALL)

with open('server.ts', 'w') as f:
    f.write(text)
