const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf-8');

const targetStr = `  const { npcName, npcPrompt, playerName, history } = req.body;
  if (!npcName || !history) {`;

const replaceStr = `  const { npcName, npcPrompt, playerName, history, npcHealth, npcMaxHealth, aiMode, environmentInfo } = req.body;
  if (!npcName || !history) {`;

const instructionTarget = `const systemInstruction = \`You are an interactive AI NPC inside a 3D game named Apex Studio.
NPC Name: \${npcName}
Player talking to you: \${playerName}

YOUR BRAIN/PERSONALITY PROMPT:
\${npcPrompt}

Respond concisely and directly in character. Keep responses relatively short (1-3 sentences) suitable for a game chat box.\`;`;

const instructionReplace = `const systemInstruction = \`You are an interactive AI NPC inside a 3D game named Apex Studio.
NPC Name: \${npcName}
Player talking to you: \${playerName}

--- SYSTEM SENSORS ---
Current AI State: \${aiMode || 'Idle'}
Health: \${npcHealth !== undefined ? npcHealth + '/' + (npcMaxHealth || 100) : 'Unknown'}
Environment: \${environmentInfo || 'Normal'}
---

YOUR BRAIN/PERSONALITY PROMPT:
\${npcPrompt}

Respond concisely and directly in character. Keep responses relatively short (1-3 sentences) suitable for a game chat box.\`;`;

code = code.replace(targetStr, replaceStr);
code = code.replace(instructionTarget, instructionReplace);
fs.writeFileSync('server.ts', code);
