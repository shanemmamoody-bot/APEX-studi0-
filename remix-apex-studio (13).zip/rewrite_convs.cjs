const fs = require('fs');
const file = 'src/components/FriendsAndMessagingModal.tsx';
let code = fs.readFileSync(file, 'utf8');

// Replace conversation sidebar search
code = code.replace(
  /<div className="w-1\/3 border-r border-\[#1E1E24\] bg-\[#0F0F12\] flex flex-col p-3">([\s\S]*?)<div className="flex-1 overflow-y-auto p-2 space-y-1">/g,
  `<div className="w-1/3 border-r border-[#1E1E24] bg-[#0A0A0C] flex flex-col">
              <div className="p-4 border-b border-[#1E1E24]">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-500" />
                  <input
                    type="text"
                    placeholder="Search messages..."
                    value={searchFilter}
                    onChange={(e) => setSearchFilter(e.target.value)}
                    className="w-full bg-transparent text-sm text-white placeholder-gray-500 focus:outline-none pl-9"
                  />
                </div>
              </div>
              <div className="flex-1 overflow-y-auto">`
);

// Replace conversation items
// I'll use regex to find the button mapping
const buttonRegex = /<button\s*key=\{conv\.id\}\s*onClick=\{[^}]+\}\s*className=\{`w-full text-left p-2\.5 rounded-2xl flex items-center space-x-3 transition-all cursor-pointer \${[\s\S]*?}`\}\s*>/;

const newButton = `<button
                          key={conv.id}
                          onClick={() => setSelectedConversationId(conv.id)}
                          className={\`w-full text-left p-4 flex items-center space-x-3 transition-all cursor-pointer border-b border-[#1E1E24] \${
                            selectedConversationId === conv.id
                              ? "bg-[#1E1E24] text-white border-l-4 border-l-[#3B82F6]"
                              : "hover:bg-[#121215] text-gray-400 border-l-4 border-l-transparent"
                          }\`}
                        >`;
                        
code = code.replace(buttonRegex, newButton);

fs.writeFileSync(file, code);
