const fs = require('fs');
let code = fs.readFileSync('src/components/Viewport.tsx', 'utf-8');

const targetStr = `          if (modelInst.aiDamage && modelInst.aiDamage > 0) {
            behaviors.push({ type: 'Deal Damage', damage: modelInst.aiDamage, radius: 3.5, cooldown: 1.0 });
          }`;

const replaceStr = `          if (modelInst.aiDamage && modelInst.aiDamage > 0) {
            behaviors.push({ type: 'Deal Damage', damage: modelInst.aiDamage, radius: 3.5, cooldown: 1.0 });
          }

          // SMART AI: Self-Preservation Override
          // If the AI has health, and is below 30%, and is currently following or attacking, override to flee
          if (modelInst.health !== undefined && modelInst.maxHealth !== undefined) {
            if (modelInst.health < modelInst.maxHealth * 0.3 && (modelInst.aiMode === 'Follow' || modelInst.aiDamage)) {
              // Remove Follow Player or Wander
              for (let i = behaviors.length - 1; i >= 0; i--) {
                if (behaviors[i].type === 'Follow Player' || behaviors[i].type === 'Wander' || behaviors[i].type === 'Patrol') {
                  behaviors.splice(i, 1);
                }
              }
              behaviors.push({ type: 'Flee Player', speed: (modelInst.aiWalkSpeed || 16) * 1.5, fleeDistance: 40 });
            }
          }`;

code = code.replace(targetStr, replaceStr);
fs.writeFileSync('src/components/Viewport.tsx', code);
