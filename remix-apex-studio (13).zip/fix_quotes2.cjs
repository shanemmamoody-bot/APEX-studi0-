const fs = require('fs');
let code = fs.readFileSync('src/server/adex/modelInstructions.ts', 'utf-8');

code = code.replace(/3\. \*\*Advanced VFX\*\*: \\`Instance.new\("Explosion"\)", \`Instance.new\("ParticleEmitter"\)\`, \`Instance.new\("Fire"\)\`, \`Instance.new\("Sparkles"\)\`\./, 
'3. **Advanced VFX**: \\`Instance.new("Explosion")\\`, \\`Instance.new("ParticleEmitter")\\`, \\`Instance.new("Fire")\\`, \\`Instance.new("Sparkles")\\`.');

// Wait, the actual line is:
// 3. **Advanced VFX**: \`Instance.new("Explosion")`, `Instance.new("ParticleEmitter")`, `Instance.new("Fire")`, `Instance.new("Sparkles")`. Parenting an Explosion to Workspace with a position triggers an immediate visual blast and shockwave.

code = code.replace(/3\. \*\*Advanced VFX\*\*: \\`Instance\.new\("Explosion"\)", `Instance\.new\("ParticleEmitter"\)`, `Instance\.new\("Fire"\)`, `Instance\.new\("Sparkles"\)`\./, 
'3. **Advanced VFX**: \\`Instance.new("Explosion")\\`, \\`Instance.new("ParticleEmitter")\\`, \\`Instance.new("Fire")\\`, \\`Instance.new("Sparkles")\\`.');


fs.writeFileSync('src/server/adex/modelInstructions.ts', code);
