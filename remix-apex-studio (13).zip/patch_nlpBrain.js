const fs = require('fs');
let code = fs.readFileSync('src/server/adex/nlpBrain.ts', 'utf-8');

const replacement = `        // --- 3. Intent Detection ---
        if (/^(hello|hi|hey|how are you|greetings|sup)\\b/i.test(lower) && lower.split(' ').length <= 5) {
            intent = 'greeting';
            primarySubject = 'greeting';
        } 
        else if (lower.match(/^(tell me a joke|make me laugh|joke)/i)) {
            intent = 'joke';
            primarySubject = 'joke';
        }
        else if (lower.match(/^(i think|in my opinion|i believe|it seems like)\\b/i)) {
            intent = 'opinion';
            primarySubject = lower;
        }
        else if (lower.match(/^(what|which|how|why|who|when|where|can you explain|do you know|is there|calculate|solve|spell)\\b/i) || lower.endsWith('?')) {
            if (/^(can you|how do i)\\s+(make|build|create|write|generate|add)\\b/i.test(lower)) {
                intent = 'build';
            } else {
                intent = 'question';
                primarySubject = lower;
            }
        }
        else if (lower.match(/^(make|build|create|write|generate|add|do|run|stop|start|open|close|execute)\\b/i)) {
            intent = 'build';
        }
        else if (lower.includes('what is') || lower.includes('how to') || lower.includes('explain') || lower.includes('what does')) {
            intent = 'explain';`;

code = code.replace(/        \/\/ --- 3\. Intent Detection ---[\s\S]*?else if \(lower\.includes\('what is'\) \|\| lower\.includes\('how to'\) \|\| lower\.includes\('explain'\) \|\| lower\.includes\('what does'\)\) \{/, replacement);

fs.writeFileSync('src/server/adex/nlpBrain.ts', code);
