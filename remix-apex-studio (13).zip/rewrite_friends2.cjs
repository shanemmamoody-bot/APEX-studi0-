const fs = require('fs');
const file = 'src/components/FriendsAndMessagingModal.tsx';
let code = fs.readFileSync(file, 'utf8');

const regex = /<div className="flex bg-\[#0A0A0C\] p-1 rounded-xl border border-\[#1E1E24\]">[\s\S]*?<\/button>\s*<\/div>\s*<\/div>\s*<button\s*onClick=\{onClose\}/;

const newNav = `<div className="flex space-x-6 px-2">
              <button
                onClick={() => handleTabChange("friends")}
                className={\`py-2 text-sm font-bold transition-all flex items-center space-x-2 border-b-2 cursor-pointer \${
                  currentSubTab === "friends"
                    ? "border-[#3B82F6] text-white"
                    : "border-transparent text-gray-400 hover:text-gray-200"
                }\`}
              >
                <Users className="h-4 w-4" />
                <span>Friends ({actualFriends.length})</span>
              </button>
              <button
                onClick={() => handleTabChange("messages")}
                className={\`py-2 text-sm font-bold transition-all flex items-center space-x-2 border-b-2 cursor-pointer \${
                  currentSubTab === "messages"
                    ? "border-[#3B82F6] text-white"
                    : "border-transparent text-gray-400 hover:text-gray-200"
                }\`}
              >
                <MessageSquare className="h-4 w-4" />
                <span>Messages</span>
              </button>
              <button
                onClick={() => handleTabChange("requests")}
                className={\`py-2 text-sm font-bold transition-all flex items-center space-x-2 border-b-2 cursor-pointer \${
                  currentSubTab === "requests"
                    ? "border-amber-500 text-amber-500"
                    : "border-transparent text-gray-400 hover:text-gray-200"
                }\`}
              >
                <UserPlus className="h-4 w-4" />
                <span>Friend Requests</span>
                {pendingRequests.length > 0 && (
                  <span className="bg-rose-500 text-white font-black text-[10px] px-1.5 py-0.5 rounded-full ml-1">
                    {pendingRequests.length}
                  </span>
                )}
              </button>
            </div>
          </div>
          <button
            onClick={onClose}`;

code = code.replace(regex, newNav);

// Also let's fix the Header padding so the tabs touch the bottom edge.
// <div className="p-4 border-b border-[#1E1E24] bg-[#0A0A0C] flex items-center justify-between shrink-0">
code = code.replace(
  /<div className="p-4 border-b border-\[#1E1E24\] bg-\[#0A0A0C\] flex items-center justify-between shrink-0">/,
  '<div className="px-6 pt-4 border-b border-[#1E1E24] bg-[#0A0A0C] flex items-center justify-between shrink-0">'
);

fs.writeFileSync(file, code);
console.log("Nav replaced with regex.");
