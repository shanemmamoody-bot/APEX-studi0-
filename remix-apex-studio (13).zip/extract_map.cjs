const fs = require('fs');
const path = require('path');

const map = JSON.parse(fs.readFileSync('dist/server.cjs.map', 'utf8'));

if (!fs.existsSync('recovered')) {
  fs.mkdirSync('recovered');
}

map.sources.forEach((source, index) => {
  const content = map.sourcesContent[index];
  if (content) {
    const dest = path.join('recovered', source.replace(/^(\.\.\/)+/, ''));
    fs.mkdirSync(path.dirname(dest), { recursive: true });
    fs.writeFileSync(dest, content, 'utf8');
    console.log('Recovered', source);
  }
});
