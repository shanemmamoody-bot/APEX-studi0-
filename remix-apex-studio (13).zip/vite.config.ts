import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import {defineConfig} from 'vite';

export default defineConfig(() => {
  return {
    define: {
      global: 'globalThis',
      'process.versions': JSON.stringify({ node: '18.0.0' }),
      'process.env': {},
    },
    plugins: [react(), tailwindcss()],
    resolve: {
      alias: {
        '@': path.resolve(__dirname, '.'),
        os: path.resolve(__dirname, 'src/utils/osPolyfill.ts'),
        fs: path.resolve(__dirname, 'src/utils/fsPolyfill.ts'),
        constants: path.resolve(__dirname, 'src/utils/fsPolyfill.ts'),
        path: path.resolve(__dirname, 'src/utils/pathPolyfill.ts'),
        child_process: path.resolve(__dirname, 'src/utils/childProcessPolyfill.ts'),
      },
    },
    server: {
      // HMR is disabled in AI Studio via DISABLE_HMR env var.
      // Do not modifyâfile watching is disabled to prevent flickering during agent edits.
      hmr: process.env.DISABLE_HMR !== 'true',
      // Disable file watching when DISABLE_HMR is true to save CPU during agent edits.
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});
