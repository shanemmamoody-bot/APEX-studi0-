const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf-8');

const routes = `
// ==========================================
// FRIEND REQUESTS SYSTEM
// ==========================================

app.get("/api/friends/:username", (req, res) => {
  const uKey = (req.params.username || "").trim().toLowerCase();
  const user = usersDb[uKey];
  if (!user) {
    return res.status(404).json({ error: "User not found." });
  }
  ensureUserHasBuilderGuyFriend(user);
  
  const safeFriends = (user.friends || []).map((f: any) => {
    // If the friend exists in usersDb, get latest status
    const friendDb = usersDb[f.username?.toLowerCase()];
    if (friendDb) {
      return {
        id: friendDb.id,
        username: friendDb.username,
        displayName: friendDb.displayName,
        avatarUrl: friendDb.avatarUrl,
        isOnline: friendDb.isOnline,
        lastOnline: friendDb.lastOnline,
        mutualFriends: f.mutualFriends || 0,
        aBucks: getUserBalance(friendDb.username)
      };
    }
    return f;
  });

  const safeRequests = (user.friendRequests || []).map((f: any) => {
    const friendDb = usersDb[f.username?.toLowerCase()];
    if (friendDb) {
      return {
        id: friendDb.id,
        username: friendDb.username,
        displayName: friendDb.displayName,
        avatarUrl: friendDb.avatarUrl,
        timestamp: f.timestamp
      };
    }
    return f;
  });

  res.json({
    friends: safeFriends,
    friendRequests: safeRequests
  });
});

app.post("/api/friends/request", (req, res) => {
  const { senderUsername, targetUsername } = req.body;
  if (!senderUsername || !targetUsername) {
    return res.status(400).json({ error: "Missing sender or target username." });
  }

  const sKey = senderUsername.trim().toLowerCase();
  const tKey = targetUsername.trim().toLowerCase();

  const sender = usersDb[sKey];
  const target = usersDb[tKey];

  if (!sender) return res.status(404).json({ error: "Sender not found." });
  if (!target) return res.status(404).json({ error: "Account doesn't exist." });

  if (sKey === tKey) {
    return res.status(400).json({ error: "You cannot add yourself as a friend." });
  }

  ensureUserHasBuilderGuyFriend(sender);
  ensureUserHasBuilderGuyFriend(target);

  // Check if already friends
  if (sender.friends.some((f: any) => f.username.toLowerCase() === tKey)) {
    return res.status(400).json({ error: "Already friends." });
  }

  // Check if target already sent a request to sender
  if (sender.friendRequests.some((r: any) => r.username.toLowerCase() === tKey)) {
    return res.status(400).json({ error: "This user already sent you a friend request. Check your requests!" });
  }

  // Check if sender already sent a request to target
  if (target.friendRequests.some((r: any) => r.username.toLowerCase() === sKey)) {
    return res.status(400).json({ error: "Friend request already sent." });
  }

  // Add request to target
  target.friendRequests.push({
    username: sender.username,
    timestamp: new Date().toISOString()
  });

  saveUsersDB();
  res.json({ success: true, message: "Friend request sent!" });
});

app.post("/api/friends/accept", (req, res) => {
  const { username, targetUsername } = req.body;
  const uKey = username.trim().toLowerCase();
  const tKey = targetUsername.trim().toLowerCase();

  const user = usersDb[uKey];
  const target = usersDb[tKey];

  if (!user || !target) {
    return res.status(404).json({ error: "User not found." });
  }

  ensureUserHasBuilderGuyFriend(user);
  ensureUserHasBuilderGuyFriend(target);

  // Remove request from user
  user.friendRequests = user.friendRequests.filter((r: any) => r.username.toLowerCase() !== tKey);

  // Add to friends lists if not already
  if (!user.friends.some((f: any) => f.username.toLowerCase() === tKey)) {
    user.friends.push({ username: target.username, mutualFriends: Math.floor(Math.random() * 5) });
    user.friendsCount = user.friends.length;
  }
  if (!target.friends.some((f: any) => f.username.toLowerCase() === uKey)) {
    target.friends.push({ username: user.username, mutualFriends: Math.floor(Math.random() * 5) });
    target.friendsCount = target.friends.length;
  }

  saveUsersDB();
  res.json({ success: true, message: "Friend request accepted!" });
});

app.post("/api/friends/decline", (req, res) => {
  const { username, targetUsername } = req.body;
  const uKey = username.trim().toLowerCase();
  const tKey = targetUsername.trim().toLowerCase();

  const user = usersDb[uKey];
  if (!user) {
    return res.status(404).json({ error: "User not found." });
  }

  ensureUserHasBuilderGuyFriend(user);
  user.friendRequests = user.friendRequests.filter((r: any) => r.username.toLowerCase() !== tKey);

  saveUsersDB();
  res.json({ success: true, message: "Friend request declined." });
});

`;

const anchor = 'app.get("/api/games", (req, res) => {';
if (code.includes(anchor)) {
    code = code.replace(anchor, routes + anchor);
    fs.writeFileSync('server.ts', code);
    console.log("Added friend routes");
} else {
    console.log("Anchor not found");
}
