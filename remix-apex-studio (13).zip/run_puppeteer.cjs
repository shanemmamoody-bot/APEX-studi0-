const puppeteer = require('puppeteer');

(async () => {
  const browser = await puppeteer.launch({ args: ['--no-sandbox', '--disable-setuid-sandbox'] });
  const page = await browser.newPage();
  
  page.on('console', msg => {
    if (msg.type() === 'error' || msg.text().includes('two children with the same key')) {
      console.log('BROWSER LOG:', msg.text());
    }
  });

  await page.goto('http://localhost:3000', { waitUntil: 'networkidle0' });
  
  // click "Tycoon" template to trigger project creation
  try {
    await page.evaluate(() => {
      const tycoonBtn = Array.from(document.querySelectorAll('button')).find(el => el.textContent.includes('Tycoon'));
      if (tycoonBtn) tycoonBtn.click();
    });
    await new Promise(r => setTimeout(r, 2000));
    
    await page.evaluate(() => {
      const createBtn = Array.from(document.querySelectorAll('button')).find(el => el.textContent.includes('Create Project') || el.textContent.includes('Create Experience'));
      if (createBtn) createBtn.click();
    });
    await new Promise(r => setTimeout(r, 2000));
  } catch(e) {}
  
  await browser.close();
})();
