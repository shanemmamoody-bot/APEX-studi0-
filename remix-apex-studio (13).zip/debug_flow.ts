import { Adex3Engine, ReasoningEngine } from "./src/server/adex/adex3Engine";
import { LearnedKnowledge } from "./src/server/adex/knowledge";

const db = LearnedKnowledge.getDb();
const payload = "what is my game speed";
const answer = ReasoningEngine.solve(payload, db);
console.log("Answer from ReasoningEngine:", answer);
