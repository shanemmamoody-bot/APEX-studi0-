const fs = require('fs');
let code = fs.readFileSync('src/server/adex/adex3Engine.ts', 'utf-8');

code = code.replace(/lastMessage = await this\.parseWithGemini\(lastMessage\);/g, '// lastMessage = await this.parseWithGemini(lastMessage);');
code = code.replace(/userRequest = await this\.parseWithGemini\(userRequest\);/g, '// userRequest = await this.parseWithGemini(userRequest);');

fs.writeFileSync('src/server/adex/adex3Engine.ts', code);
