import { Adex3Engine } from './src/server/adex/adex3Engine';

(async () => {
    try {
        console.log("Q: what's 5x5?");
        const a1 = await Adex3Engine.processText("what's 5x5?");
        console.log("A:", a1);

        console.log("\nQ: what do you want to do?");
        const a2 = await Adex3Engine.processText("what do you want to do?");
        console.log("A:", a2);

        console.log("\nQ: what is the speed of light?");
        const a3 = await Adex3Engine.processText("what is the speed of light?");
        console.log("A:", a3);
        
        console.log("\nQ: fix grammar: their going to the park");
        const a4 = await Adex3Engine.processText("fix grammar: their going to the park");
        console.log("A:", a4);
        
        console.log("\nQ: what's 10 - 2");
        const a5 = await Adex3Engine.processText("what's 10 - 2");
        console.log("A:", a5);
        
        console.log("\nQ: nevermind, that's all");
        const a6 = await Adex3Engine.processText("nevermind, that's all");
        console.log("A:", a6);
        
        console.log("\nQ: what is the powerhouse of the cell?");
        const a7 = await Adex3Engine.processText("what is the powerhouse of the cell?");
        console.log("A:", a7);
    } catch(e) {
        console.error(e);
    }
})();
