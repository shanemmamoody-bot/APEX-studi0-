const fs = require('fs');
const path = require('path');

function walkDir(dir, callback) {
  fs.readdirSync(dir).forEach(f => {
    let dirPath = path.join(dir, f);
    let isDirectory = fs.statSync(dirPath).isDirectory();
    if (isDirectory) {
      walkDir(dirPath, callback);
    } else if (f.endsWith('.tsx') || f.endsWith('.ts') || f.endsWith('.css')) {
      callback(dirPath);
    }
  });
}

const shadowRe = /shadow-\w+-\d+\/\d+/g;
const gradientRe = /bg-gradient-to-\w+ from-[^\s]+( via-[^\s]+)? to-[^\s]+/g;
const bgGradientRe = /bg-gradient-to-\w+/g;
const fromRe = /from-[^\s]+/g;
const toRe = /to-[^\s]+/g;
const viaRe = /via-[^\s]+/g;
const textGradientRe = /text-transparent bg-clip-text/g;
const glassRe = /backdrop-blur-\w+/g;

walkDir('./src', (filePath) => {
  let content = fs.readFileSync(filePath, 'utf-8');
  let newContent = content;

  // Replace shadow slop
  newContent = newContent.replace(/shadow-cyan-\d+\/\d+/g, 'shadow-sm');
  newContent = newContent.replace(/shadow-purple-\d+\/\d+/g, 'shadow-sm');
  newContent = newContent.replace(/shadow-amber-\d+\/\d+/g, 'shadow-sm');
  newContent = newContent.replace(/shadow-\[0_0_8px_rgba.*?\]/g, '');

  // Replace gradient background slop with solid colors based on the context
  // To be safe, just strip the gradient classes entirely and rely on fallback background classes if they exist, or add simple ones.
  // Actually, regexing `bg-gradient-to-\w+ from-[^\s]+( via-[^\s]+)? to-[^\s]+` might be better.
  newContent = newContent.replace(/bg-gradient-to-\w+\s+from-[^\s]+\s+via-[^\s]+\s+to-[^\s]+/g, 'bg-[#18181b]');
  newContent = newContent.replace(/bg-gradient-to-\w+\s+from-[^\s]+\s+to-[^\s]+/g, 'bg-[#27272a]');
  
  // Clean up any stray gradient classes
  newContent = newContent.replace(/bg-gradient-to-[a-z]+/g, '');
  newContent = newContent.replace(/from-[a-z0-9\/\[\]#-]+/g, '');
  newContent = newContent.replace(/via-[a-z0-9\/\[\]#-]+/g, '');
  newContent = newContent.replace(/to-[a-z0-9\/\[\]#-]+/g, '');
  newContent = newContent.replace(/text-transparent bg-clip-text/g, 'text-zinc-100');
  
  // Clean up other AI slop buzzwords/classes
  newContent = newContent.replace(/backdrop-blur-(md|lg|sm|xl|2xl|3xl)/g, '');
  newContent = newContent.replace(/shadow-2xl/g, 'shadow-sm');
  newContent = newContent.replace(/shadow-xl/g, 'shadow-sm');
  newContent = newContent.replace(/shadow-lg/g, 'shadow-sm');

  // Cyan and purple texts often scream AI
  newContent = newContent.replace(/text-cyan-\d00/g, 'text-zinc-100');
  newContent = newContent.replace(/text-purple-\d00/g, 'text-zinc-100');
  newContent = newContent.replace(/border-cyan-\d00\/\d+/g, 'border-zinc-800');
  newContent = newContent.replace(/border-purple-\d00\/\d+/g, 'border-zinc-800');
  newContent = newContent.replace(/bg-purple-\d00\/\d+/g, 'bg-zinc-800');
  newContent = newContent.replace(/bg-cyan-\d00\/\d+/g, 'bg-zinc-800');

  // Fix button text to avoid black text on dark background after gradient removal
  // When we replaced from-amber-xxx to-yellow-xxx it became bg-[#27272a], so we should make text-slate-950 into text-white
  newContent = newContent.replace(/text-slate-950/g, 'text-white');

  // Fix multiple spaces
  newContent = newContent.replace(/\s{2,}/g, ' ');

  if (content !== newContent) {
    fs.writeFileSync(filePath, newContent, 'utf-8');
  }
});
console.log("Slop cleaned.");
