local Players = game:GetService("Players")

local function setupObby()
    local spawnLocation = workspace:FindFirstChild("Start Platform")
    
    local function onPlayerAdded(player)
        local leaderstats = Instance.new("Folder")
        leaderstats.Name = "leaderstats"
        leaderstats.Parent = player
        
        local stage = Instance.new("NumberValue")
        stage.Name = "Stage"
        stage.Value = 1
        stage.Parent = leaderstats
        
        player.CharacterAdded:Connect(function(char)
            local humanoid = char:WaitForChild("Humanoid")
            local hrp = char:WaitForChild("HumanoidRootPart")
            
            task.wait(0.1)
            
            -- Teleport to checkpoint
            local targetStage = stage.Value
            if targetStage > 1 then
                local checkpoint = workspace:FindFirstChild("Checkpoint " .. targetStage)
                if checkpoint then
                    hrp.CFrame = checkpoint.CFrame + Vector3.new(0, 3, 0)
                end
            else
                if spawnLocation then
                    hrp.CFrame = spawnLocation.CFrame + Vector3.new(0, 3, 0)
                end
            end
            
            -- Kill floor handling
            -- For standard obby, let's just make lava traps kill immediately
        end)
    end
    
    Players.PlayerAdded:Connect(onPlayerAdded)
    for _, p in ipairs(Players:GetPlayers()) do
        onPlayerAdded(p)
    end
    
    -- Setup Lava and Checkpoints
    for _, part in ipairs(workspace:GetChildren()) do
        if part.Name:match("^Lava") then
            part.Touched:Connect(function(hit)
                if hit and hit.Parent then
                    local hum = hit.Parent:FindFirstChild("Humanoid")
                    if hum then
                        hum.Health = 0
                    end
                end
            end)
        elseif part.Name:match("^Checkpoint") then
            local stageNum = tonumber(part.Name:match("%d+"))
            if stageNum then
                part.Touched:Connect(function(hit)
                    if hit and hit.Parent then
                        local player = Players:GetPlayerFromCharacter(hit.Parent)
                        if player then
                            local leaderstats = player:FindFirstChild("leaderstats")
                            if leaderstats and leaderstats:FindFirstChild("Stage") then
                                if leaderstats.Stage.Value < stageNum then
                                    leaderstats.Stage.Value = stageNum
                                    -- simple save can be added later if needed
                                end
                            end
                        end
                    end
                end)
            end
        elseif part.Name == "Golden Victory Trophy" or part.Name == "Finish Platform" then
            part.Touched:Connect(function(hit)
                if hit and hit.Parent then
                    local player = Players:GetPlayerFromCharacter(hit.Parent)
                    if player then
                        local leaderstats = player:FindFirstChild("leaderstats")
                        if leaderstats and leaderstats:FindFirstChild("Stage") then
                            if leaderstats.Stage.Value < 999 then
                                leaderstats.Stage.Value = 999
                                print(player.Name .. " has completed the obby!")
                                -- Add a win effect or something
                            end
                        end
                    end
                end
            end)
        end
    end
end

setupObby()
