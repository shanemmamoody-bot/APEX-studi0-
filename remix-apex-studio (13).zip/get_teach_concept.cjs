const fs = require('fs');
const content = fs.readFileSync('src/server/adex/adex3Engine.ts', 'utf-8');

const tStart = content.indexOf('static teachConcept(');
console.log(content.substring(tStart, content.indexOf('}', content.indexOf('}', tStart) + 1) + 1));
