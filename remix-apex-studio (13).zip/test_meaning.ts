import { generateProceduralText } from "./src/server/adex/proceduralText";
console.log(generateProceduralText("what is the meaning of life", "adex_3"));
