import { Adex3Engine } from "./src/server/adex/adex3Engine";

console.log("--- Q1 ---");
console.log(Adex3Engine.processText("what Is the meing to lifr"));

console.log("\n--- Q2 ---");
console.log(Adex3Engine.processText("what Is the meing to lifr\n\nwhat is it"));

console.log("\n--- Q3 ---");
console.log(Adex3Engine.processText("remember my game speed is 19"));

console.log("\n--- Q4 ---");
console.log(Adex3Engine.processText("what is my game speed"));
