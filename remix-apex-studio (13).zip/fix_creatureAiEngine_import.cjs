const fs = require('fs');
let code = fs.readFileSync('src/utils/creatureAiEngine.ts', 'utf-8');

// Remove the import from the bottom
code = code.replace("import { ApexLuaSession } from './luaEngine';\\n", "");
code = code.replace("import { ApexLuaSession } from './luaEngine';", "");

// Add to the top
code = "import { ApexLuaSession } from './luaEngine';\n" + code;

fs.writeFileSync('src/utils/creatureAiEngine.ts', code);
