const fs = require('fs');
let code = fs.readFileSync('src/components/Viewport.tsx', 'utf-8');

const targetStr = `          // Inject advanced scriptable flat properties
          if (modelInst.aiMode === 'Follow') {
            behaviors.push({ type: 'Follow Player', speed: modelInst.aiWalkSpeed ?? 16, followDistance: modelInst.aiStopDistance ?? 2 });
          } else if (modelInst.aiMode === 'Patrol') {
            behaviors.push({ type: 'Patrol', speed: modelInst.aiWalkSpeed ?? 16, patrolDistance: modelInst.aiPatrolRadius ?? 10 });
          } else if (modelInst.aiMode === 'Wander') {
            behaviors.push({ type: 'Wander', speed: modelInst.aiWalkSpeed ?? 16, wanderDistance: modelInst.aiPatrolRadius ?? 15 });
          } else if (modelInst.aiMode === 'Guard') {
            behaviors.push({ type: 'Guard Area', speed: modelInst.aiWalkSpeed ?? 16, guardRadius: modelInst.aiPatrolRadius ?? 12 });
          } else if (modelInst.aiMode === 'Flee') {
            behaviors.push({ type: 'Flee Player', speed: modelInst.aiWalkSpeed ?? 20, fleeDistance: 30 });
          }
          if (modelInst.aiDamage && modelInst.aiDamage > 0) {
            behaviors.push({ type: 'Deal Damage', damage: modelInst.aiDamage, radius: 3.5, cooldown: 1.0 });
          }`;

const replaceStr = `          // Inject advanced scriptable flat properties
          let activeAiMode = modelInst.aiMode;

          if (activeAiMode === 'Autonomous') {
             let autoState = modelAutonomousStateRef.current.get(modelInst.id);
             if (!autoState) {
               autoState = { state: 'Idle', lastStateChange: nowTimeMs, trust: 0 };
               modelAutonomousStateRef.current.set(modelInst.id, autoState);
             }
             
             // State Machine Logic
             const timeInState = nowTimeMs - autoState.lastStateChange;
             
             // Transitions
             if (modelInst.health !== undefined && modelInst.maxHealth !== undefined && modelInst.health < modelInst.maxHealth * 0.99) {
               // Hurt
               if (autoState.state !== 'Attack' && autoState.state !== 'Flee') {
                  autoState.state = (modelInst.health < modelInst.maxHealth * 0.3) ? 'Flee' : 'Attack';
                  autoState.lastStateChange = nowTimeMs;
                  autoState.trust -= 50;
               }
             } else if (autoState.state === 'Attack' || autoState.state === 'Flee') {
               // Cool down from aggression/fear
               if (timeInState > 10000 && dist > 20) {
                 autoState.state = 'Wander';
                 autoState.lastStateChange = nowTimeMs;
               }
             } else if (autoState.trust >= 100) {
               autoState.state = 'Follow';
               autoState.lastStateChange = nowTimeMs;
             } else if (dist < 15 && autoState.state !== 'Tameable' && autoState.state !== 'Follow' && autoState.state !== 'Attack' && autoState.state !== 'Flee') {
               // Player is close, wait and see (Tameable state)
               autoState.state = 'Tameable';
               autoState.lastStateChange = nowTimeMs;
             } else if (autoState.state === 'Tameable' && dist > 20) {
               autoState.state = 'Wander';
               autoState.lastStateChange = nowTimeMs;
             } else if (autoState.state === 'Tameable' && timeInState > 6000 && dist < 15) {
               // Gets bored of waiting
               autoState.state = 'Wander';
               autoState.lastStateChange = nowTimeMs;
             } else if (autoState.state === 'Idle' && timeInState > 4000) {
               autoState.state = 'Wander';
               autoState.lastStateChange = nowTimeMs;
             } else if (autoState.state === 'Wander' && timeInState > 8000) {
               autoState.state = 'Idle';
               autoState.lastStateChange = nowTimeMs;
             }
             
             activeAiMode = autoState.state;
          }

          if (activeAiMode === 'Follow') {
            behaviors.push({ type: 'Follow Player', speed: modelInst.aiWalkSpeed ?? 16, followDistance: modelInst.aiStopDistance ?? 2 });
          } else if (activeAiMode === 'Patrol') {
            behaviors.push({ type: 'Patrol', speed: modelInst.aiWalkSpeed ?? 16, patrolDistance: modelInst.aiPatrolRadius ?? 10 });
          } else if (activeAiMode === 'Wander') {
            behaviors.push({ type: 'Wander', speed: modelInst.aiWalkSpeed ?? 16, wanderDistance: modelInst.aiPatrolRadius ?? 15 });
          } else if (activeAiMode === 'Guard') {
            behaviors.push({ type: 'Guard Area', speed: modelInst.aiWalkSpeed ?? 16, guardRadius: modelInst.aiPatrolRadius ?? 12 });
          } else if (activeAiMode === 'Flee') {
            behaviors.push({ type: 'Flee Player', speed: modelInst.aiWalkSpeed ?? 20, fleeDistance: 30 });
          } else if (activeAiMode === 'Attack') {
            behaviors.push({ type: 'Follow Player', speed: (modelInst.aiWalkSpeed || 16) * 1.2, followDistance: 1 });
            behaviors.push({ type: 'Deal Damage', damage: modelInst.aiDamage || 15, radius: 3.5, cooldown: 1.0 });
          } else if (activeAiMode === 'Tameable') {
             // Just stand there and look at player, waiting for interaction
             const faceAngle = Math.atan2(dx, dz) * (180 / Math.PI);
             mainPart.rotation.y = faceAngle;
          }

          if (modelInst.aiDamage && modelInst.aiDamage > 0 && activeAiMode !== 'Autonomous' && activeAiMode !== 'Attack') {
            behaviors.push({ type: 'Deal Damage', damage: modelInst.aiDamage, radius: 3.5, cooldown: 1.0 });
          }`;

code = code.replace(targetStr, replaceStr);
fs.writeFileSync('src/components/Viewport.tsx', code);
