const fs = require('fs');
const db = JSON.parse(fs.readFileSync('./adex_db.json', 'utf8'));
const rules = db.knowledgeBase.rules.filter(r => r.category === 'fact_structured');
const queries = ["what is my game speed", "remember my game speed is 19"];

for (const lower of queries) {
    const cleanQuery = lower.replace(/[^a-z0-9 ]/g, '').trim();
    console.log("---- Query:", cleanQuery, "----");
    for (const fact of rules) {
        if (fact.subject !== 'my game speed') continue;
        const s = fact.subject.toLowerCase();
        const r = fact.relationship.toLowerCase();
        const o = fact.object.toLowerCase();
        
        console.log(`Condition 1 match:`, cleanQuery.match(new RegExp(`^(what|who|where)\\s+(is|are)\\s+(the\\s+)?${s}(?:\\s|$)`, 'i')) || cleanQuery === s || cleanQuery.includes(`${s} name`));
        
        const relWords = fact.relationship.toLowerCase().replace(/^(is|was|are|the|a|an|of)\s+/g, '').replace(/\s+(of|in|to|for)$/g, '').trim().split(' ');
        let hasRelWord = false;
        for (const w of relWords) {
            if (w.length > 2 && cleanQuery.includes(w)) {
                hasRelWord = true;
                break;
            }
        }
        console.log(`Condition 2 match:`, cleanQuery.includes(s) && hasRelWord);
        console.log(`Condition 3 match:`, cleanQuery.includes(o) && hasRelWord);
        console.log(`Condition 4 match:`, cleanQuery.includes(o) && cleanQuery.includes(s) && fact.relationship !== 'is' && fact.relationship !== 'are');
        console.log(`Condition 5 match:`, (cleanQuery.includes("when") || cleanQuery.includes("where")) && (cleanQuery.includes(s) || cleanQuery.includes(o)) && fact.relationship !== 'is');
    }
}
