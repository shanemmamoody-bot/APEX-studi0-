import fs from 'fs';
import path from 'path';

const typesFile = path.join(process.cwd(), 'src/types.ts');
let content = fs.readFileSync(typesFile, 'utf8');

content += `
export interface AdCampaign {
  id: string;
  gameId: string;
  username: string;
  budgetAbux: number;
  durationMs: number;
  startTime: number;
  endTime: number;
  status: 'active' | 'completed';
  stats: {
    realPlayerRecommendations: number;
    realPlayerClicks: number;
    aiVisits: number;
  };
}
`;
fs.writeFileSync(typesFile, content, 'utf8');
