import fs from 'fs';
import path from 'path';

const serverFile = path.join(process.cwd(), 'server.ts');
let content = fs.readFileSync(serverFile, 'utf8');

const adSystemCode = `
// -------------------------------------------------------------
// APEX ADVERTISEMENT SYSTEM
// -------------------------------------------------------------
export interface AdCampaign {
  id: string;
  gameId: string;
  username: string;
  budgetAbux: number;
  durationMs: number;
  startTime: number;
  endTime: number;
  status: 'active' | 'completed';
  stats: {
    realPlayerRecommendations: number;
    realPlayerClicks: number;
    aiVisits: number;
  };
  lastCycleTime: number;
}
export const adCampaigns: AdCampaign[] = [];
const botClients = new Map<string, ConnectedPlayerSocket>();

function spawnAIBot(gameId: string) {
  const botId = "bot-" + Math.random().toString(36).substring(2, 9);
  const bot: ConnectedPlayerSocket = {
     ws: null as any,
     id: botId,
     username: "Guest_" + Math.floor(Math.random() * 9999),
     gameId,
     gameMode: "45-jump-obby",
     avatar: { skinTone: "#f5d0b5", shirtColor: "#3b82f6", pantsColor: "#1e293b" },
     x: (Math.random() - 0.5) * 10,
     y: 10,
     z: (Math.random() - 0.5) * 10,
     facingYaw: Math.random() * Math.PI * 2,
     animState: "running",
     health: 100,
     lastPing: Date.now()
  };
  botClients.set(botId, bot);
  
  if (!activeGameSessions.has(gameId)) {
     activeGameSessions.set(gameId, new Map());
  }
  activeGameSessions.get(gameId)!.set(bot.username.toLowerCase(), Date.now());

  broadcastToRoom(gameId, {
    type: "PLAYER_JOINED",
    player: {
      id: bot.id,
      username: bot.username,
      gameId: bot.gameId,
      gameMode: bot.gameMode,
      avatar: bot.avatar,
      x: bot.x,
      y: bot.y,
      z: bot.z,
      facingYaw: bot.facingYaw,
      animState: bot.animState,
      health: bot.health
    }
  });
}

// Global Ad Check & Bot Movement Loop
setInterval(() => {
  const now = Date.now();
  
  // Ad Cycles
  for (const ad of adCampaigns) {
    if (ad.status !== 'active') continue;
    if (now >= ad.endTime) {
      ad.status = 'completed';
      continue;
    }
    // Every 30 minutes
    if (now - ad.lastCycleTime >= 30 * 60 * 1000) {
      ad.lastCycleTime = now;
      
      // 1. Recommend to 3-6 REAL players
      const numReal = Math.floor(Math.random() * 4) + 3;
      const onlineUsers = Array.from(wsClients.values()).filter(c => !c.id.startsWith('bot-'));
      const picked = onlineUsers.sort(() => 0.5 - Math.random()).slice(0, numReal);
      for (const p of picked) {
         if (p.ws && p.ws.readyState === 1) { // WebSocket.OPEN is 1
            p.ws.send(JSON.stringify({ type: "RECOMMENDED_AD", adId: ad.id, gameId: ad.gameId }));
            ad.stats.realPlayerRecommendations++;
         }
      }
      
      // 2. Create AI bots
      const numBots = Math.floor(Math.random() * 4) + 3;
      for (let i = 0; i < numBots; i++) {
         if (Math.random() <= 0.65) {
            ad.stats.aiVisits++;
            spawnAIBot(ad.gameId);
         }
      }
    }
  }
  
  // Bot movement
  for (const [botId, bot] of botClients.entries()) {
     if (Math.random() < 0.05) { // 5% chance per second to leave
        broadcastToRoom(bot.gameId, { type: "PLAYER_LEFT", playerId: botId });
        activeGameSessions.get(bot.gameId)?.delete(bot.username.toLowerCase());
        botClients.delete(botId);
        continue;
     }

     bot.facingYaw += (Math.random() - 0.5) * 1.5;
     const speed = 0.4;
     bot.x += Math.sin(bot.facingYaw) * speed;
     bot.z += Math.cos(bot.facingYaw) * speed;
     bot.y -= 0.6; // gravity
     if (bot.y < -20) {
        bot.y = 10;
        bot.x = 0;        bot.z = 0;     }     bot.currentJump = Math.random() < 0.15;     bot.animState = "running";     broadcastToRoom(bot.gameId, {        type: "REMOTE_PLAYER_STATE",        playerId: botId,        username: bot.username,        x: bot.x,        y: bot.y,        z: bot.z,        facingYaw: bot.facingYaw,        animState: bot.animState,        health: bot.health,        isSlashing: false,        isSittingOnSwing: false,        currentJump: bot.currentJump     });          // keep session active     if (activeGameSessions.has(bot.gameId)) {        activeGameSessions.get(bot.gameId)!.set(bot.username.toLowerCase(), Date.now());     }  }}, 1000);

app.post("/api/ads/create", (req, res) => {
   const { username, gameId, budgetAbux } = req.body;
   const uKey = username.toLowerCase();
   
   if (!userProgressionMap[uKey]) return res.status(404).json({ error: "User not found" });
   
   const bal = userProgressionMap[uKey].aBucks || 0;
   if (bal < budgetAbux) {
      return res.status(400).json({ error: "Insufficient Abux" });
   }
   userProgressionMap[uKey].aBucks -= budgetAbux;
   saveProgressionDB();
   
   const durationMs = (budgetAbux / 100) * 2 * 60 * 60 * 1000;
   const ad: AdCampaign = {
      id: "ad-" + Date.now(),
      gameId,
      username,
      budgetAbux,
      durationMs,
      startTime: Date.now(),
      endTime: Date.now() + durationMs,
      status: 'active',
      stats: { realPlayerRecommendations: 0, realPlayerClicks: 0, aiVisits: 0 },
      lastCycleTime: Date.now() - (30 * 60 * 1000) // trigger immediately on first cycle!
   };
   adCampaigns.push(ad);
   res.json({ success: true, ad });
});

app.get("/api/ads", (req, res) => {
   const username = req.query.username as string;
   const uKey = (username || '').toLowerCase();
   
   // Refresh status before returning
   const now = Date.now();
   for (const ad of adCampaigns) {
      if (ad.status === 'active' && now >= ad.endTime) {
         ad.status = 'completed';
      }
   }
   
   const ads = adCampaigns.filter(a => a.username.toLowerCase() === uKey);
   res.json(ads);
});

app.post("/api/ads/click", (req, res) => {
   const { adId } = req.body;
   const ad = adCampaigns.find(a => a.id === adId);
   if (ad) ad.stats.realPlayerClicks++;
   res.json({ success: true });
});
`;

if (!content.includes('/api/ads/create')) {
    content = content.replace(
      'if (process.env.NODE_ENV !== "production") {',
      adSystemCode + '\n  if (process.env.NODE_ENV !== "production") {'
    );
    fs.writeFileSync(serverFile, content, 'utf8');
    console.log('Successfully injected /api/ads into server.ts');
} else {
    console.log('/api/ads already exists!');
}
