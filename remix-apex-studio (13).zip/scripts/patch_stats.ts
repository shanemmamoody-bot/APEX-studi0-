import fs from 'fs';

const path = 'src/components/PlayerGamesHub.tsx';
let content = fs.readFileSync(path, 'utf8');

// Replace PlayerGamesHubProps to add onSelectGame
content = content.replace(
  'onPlayProject: (project: Project) => void;',
  'onPlayProject: (project: Project) => void;\n  onSelectGame?: (game: PlayerGame) => void;'
);

content = content.replace(
  'onPublishCurrentProject,\n  currentUserUsername,',
  'onPublishCurrentProject,\n  currentUserUsername,\n  onSelectGame,'
);

// Remove gameStats useState entirely
const startStats = content.indexOf('const [gameStats, setGameStats] = useState<');
const endStats = content.indexOf('});', startStats) + 3;
content = content.slice(0, startStats) + content.slice(endStats);

// Remove localStorage syncing for gameStats
const syncStart = content.indexOf('// Sync state to localStorage');
const syncEnd = content.indexOf('}, [gameStats]);') + 16;
content = content.slice(0, syncStart) + content.slice(syncEnd);

// In handleStartPlaying, remove setGameStats
content = content.replace(/setGameStats\(\(prev\) => \(\{\s*\.\.\.prev,\s*\[game\.id\]: \{\s*\.\.\.\(prev\[game\.id\] \|\| \{\s*likes: game\.likes \|\| 0,\s*favorites: game\.favorites \|\| 0,\s*\}\),\s*plays: data\.plays,\s*\},\s*\}\)\);/g, '');
content = content.replace(/setGameStats\(\(prev\) => \{\s*const current = prev\[game\.id\].*?return \{\s*\.\.\.prev,\s*\[game\.id\]: \{\s*\.\.\.current,\s*plays: current\.plays \+ 1,\s*\},\s*\};\s*\}\);/gs, '');

// In handleToggleLike, remove setGameStats
content = content.replace(/setGameStats\(\(prev\) => \{\s*const current = prev\[gameId\].*?return \{\s*\.\.\.prev,\s*\[gameId\]: \{\s*\.\.\.current,\s*likes: Math\.max\(0, current\.likes \+ delta\),\s*\},\s*\};\s*\}\);/gs, '');

// In handleToggleFavorite, remove setGameStats
content = content.replace(/setGameStats\(\(prev\) => \{\s*const current = prev\[gameId\].*?return \{\s*\.\.\.prev,\s*\[gameId\]: \{\s*\.\.\.current,\s*favorites: Math\.max\(0, current\.favorites \+ delta\),\s*\},\s*\};\s*\}\);/gs, '');

// Replace gameStats[game.id]?.likes ?? game.likes with game.likes
content = content.replace(/const realPlays =\s*gameStats\[game\.id\]\?\.plays \?\? game\.plays \?\? 0;/g, 'const realPlays = game.plays || 0;');
content = content.replace(/const realLikes =\s*gameStats\[game\.id\]\?\.likes \?\? game\.likes \?\? 0;/g, 'const realLikes = game.likes || 0;');
content = content.replace(/const realFavorites =\s*gameStats\[game\.id\]\?\.favorites \?\? game\.favorites \?\? 0;/g, 'const realFavorites = game.favorites || 0;');

// Add cursor-pointer and onClick to game card
content = content.replace(
  'className="bg-[#121215] rounded-xl border border-[#1E1E24] hover:border-emerald-500/40 overflow-hidden flex flex-col group transition-all hover:-translate-y-1 shadow-xl"',
  'className="bg-[#121215] rounded-xl border border-[#1E1E24] hover:border-emerald-500/40 overflow-hidden flex flex-col group transition-all hover:-translate-y-1 shadow-xl cursor-pointer"\n                      onClick={() => { if (onSelectGame) { onSelectGame(game); } else { handleStartPlaying(game); } }}'
);

// Fix button stopPropagation
content = content.replace(
  '<button\n                              onClick={() => handleStartPlaying(game)}',
  '<button\n                              onClick={(e) => { e.stopPropagation(); handleStartPlaying(game); }}'
);
content = content.replace(
  '<button\n                                onClick={() => handleToggleLike(game.id)}',
  '<button\n                                onClick={(e) => { e.stopPropagation(); handleToggleLike(game.id); }}'
);
content = content.replace(
  '<button\n                                onClick={() => handleToggleFavorite(game.id)}',
  '<button\n                                onClick={(e) => { e.stopPropagation(); handleToggleFavorite(game.id); }}'
);

fs.writeFileSync(path, content, 'utf8');
