import fs from 'fs';
import path from 'path';

interface Vec3 {
  x: number;
  y: number;
  z: number;
}

interface WorkspacePart {
  id: string;
  name: string;
  type?: 'part' | 'model' | 'character' | 'terrain' | 'spawn';
  shape: 'block' | 'sphere' | 'cylinder' | 'wedge';
  position: Vec3;
  rotation: Vec3;
  size: Vec3;
  color: string;
  material: 'plastic' | 'wood' | 'metal' | 'glass' | 'neon' | 'stone' | 'grass' | 'sand' | 'brick' | 'ice' | 'fabric';
  transparency?: number;
  canCollide: boolean;
  anchored: boolean;
  modelId?: string;
  isCheckpoint?: boolean;
  checkpointIndex?: number;
}

interface GameScript {
  id: string;
  name: string;
  type: 'server' | 'local' | 'client';
  content: string;
  active: boolean;
}

interface GameLighting {
  ambient: string;
  skyColor: string;
  brightness: number;
  timeOfDay: string;
  graphicsTier: 'tier1' | 'tier2' | 'tier3';
}

interface PublishedGame {
  id: string;
  projectId: string;
  name: string;
  title: string;
  creator: string;
  author: string;
  isOfficialAdmin: boolean;
  isOfficial: boolean;
  description: string;
  genre: string;
  difficulty: 'Easy' | 'Medium' | 'Hard' | 'Extreme';
  thumbnailUrl: string;
  likes: number;
  favorites: number;
  plays: number;
  activePlayers: number;
  revenue: number;
  version: string;
  publishedAt: string;
  createdAt: string;
  updatedAt: string;
  workspace: WorkspacePart[];
  scripts: GameScript[];
  lighting: GameLighting;
}

// -------------------------------------------------------------
// GAME 1: SKY TOWER
// Climbing high into the clouds on towering architectural platforms,
// spiraling beams, high-altitude trusses, glass elevator shafts,
// and moving sky pads up to Y=200+!
// -------------------------------------------------------------
function buildSkyTower(): PublishedGame {
  const parts: WorkspacePart[] = [];
  let partIdCounter = 1;
  const nextId = () => `st-${partIdCounter++}`;

  // Ground / Cloud Base
  parts.push({
    id: nextId(),
    name: 'CloudFloor',
    shape: 'block',
    position: { x: 0, y: -2, z: 0 },
    rotation: { x: 0, y: 0, z: 0 },
    size: { x: 120, y: 4, z: 120 },
    color: '#e2e8f0',
    material: 'glass',
    transparency: 0.25,
    canCollide: true,
    anchored: true,
  });

  // Base Spire Structure
  parts.push({
    id: nextId(),
    name: 'TowerBase',
    shape: 'cylinder',
    position: { x: 0, y: 10, z: 0 },
    rotation: { x: 0, y: 0, z: 0 },
    size: { x: 16, y: 24, z: 16 },
    color: '#334155',
    material: 'metal',
    transparency: 0,
    canCollide: true,
    anchored: true,
  });

  // Spawn Platform
  parts.push({
    id: nextId(),
    name: 'SpawnLocation',
    shape: 'block',
    position: { x: 0, y: 2, z: -14 },
    rotation: { x: 0, y: 0, z: 0 },
    size: { x: 12, y: 1.5, z: 12 },
    color: '#38bdf8',
    material: 'neon',
    transparency: 0,
    canCollide: true,
    anchored: true,
  });

  // Step 1 - Base spiraling ascent
  for (let i = 0; i < 8; i++) {
    const angle = (i * Math.PI) / 4;
    const radius = 18;
    const px = Math.cos(angle) * radius;
    const pz = Math.sin(angle) * radius;
    const py = 4 + i * 2.8;

    parts.push({
      id: nextId(),
      name: `TowerStep_${i + 1}`,
      shape: 'block',
      position: { x: Math.round(px * 10) / 10, y: Math.round(py * 10) / 10, z: Math.round(pz * 10) / 10 },
      rotation: { x: 0, y: (angle * 180) / Math.PI, z: 0 },
      size: { x: 5, y: 1, z: 4 },
      color: i % 2 === 0 ? '#0284c7' : '#0ea5e9',
      material: 'metal',
      canCollide: true,
      anchored: true,
    });
  }

  // Checkpoint 1 (Y ~ 28)
  parts.push({
    id: nextId(),
    name: 'Checkpoint_1',
    shape: 'block',
    position: { x: 18, y: 28, z: 0 },
    rotation: { x: 0, y: 0, z: 0 },
    size: { x: 9, y: 1.2, z: 9 },
    color: '#22c55e',
    material: 'neon',
    canCollide: true,
    anchored: true,
    isCheckpoint: true,
    checkpointIndex: 1,
  });

  // Mid Tower Shaft
  parts.push({
    id: nextId(),
    name: 'TowerMidShaft',
    shape: 'cylinder',
    position: { x: 0, y: 60, z: 0 },
    rotation: { x: 0, y: 0, z: 0 },
    size: { x: 12, y: 80, z: 12 },
    color: '#1e293b',
    material: 'metal',
    canCollide: true,
    anchored: true,
  });

  // Beams section (Y = 32 to 56)
  const beamYStart = 32;
  for (let i = 0; i < 6; i++) {
    const isX = i % 2 === 0;
    parts.push({
      id: nextId(),
      name: `SkyBeam_${i + 1}`,
      shape: 'block',
      position: {
        x: isX ? 0 : (i % 4 === 1 ? 12 : -12),
        y: beamYStart + i * 4.2,
        z: isX ? (i % 4 === 0 ? 12 : -12) : 0,
      },
      rotation: { x: 0, y: isX ? 0 : 90, z: 0 },
      size: { x: isX ? 14 : 2.5, y: 0.8, z: isX ? 2.5 : 14 },
      color: '#f59e0b',
      material: 'metal',
      canCollide: true,
      anchored: true,
    });

    // Pulsing Hazard Laser between beams
    if (i % 2 === 1) {
      parts.push({
        id: nextId(),
        name: `LavaLaser_${i}`,
        shape: 'cylinder',
        position: { x: 0, y: beamYStart + i * 4.2 + 1.2, z: 0 },
        rotation: { x: 90, y: 0, z: 0 },
        size: { x: 1, y: 22, z: 1 },
        color: '#ef4444',
        material: 'neon',
        canCollide: true,
        anchored: true,
      });
    }
  }

  // Checkpoint 2 (Y ~ 60)
  parts.push({
    id: nextId(),
    name: 'Checkpoint_2',
    shape: 'block',
    position: { x: 0, y: 60, z: -16 },
    rotation: { x: 0, y: 0, z: 0 },
    size: { x: 10, y: 1.2, z: 10 },
    color: '#10b981',
    material: 'neon',
    canCollide: true,
    anchored: true,
    isCheckpoint: true,
    checkpointIndex: 2,
  });

  // High Altitude Glass Hexagonal Discs (Y = 64 to 100)
  for (let i = 0; i < 7; i++) {
    const angle = (i * Math.PI) / 3.2;
    const r = 16 + (i % 2) * 4;
    parts.push({
      id: nextId(),
      name: `GlassRing_${i + 1}`,
      shape: 'cylinder',
      position: {
        x: Math.round(Math.cos(angle) * r * 10) / 10,
        y: 65 + i * 5.2,
        z: Math.round(Math.sin(angle) * r * 10) / 10,
      },
      rotation: { x: 0, y: 0, z: 0 },
      size: { x: 4.5, y: 0.8, z: 4.5 },
      color: '#38bdf8',
      material: 'glass',
      transparency: 0.15,
      canCollide: true,
      anchored: true,
    });
  }

  // Checkpoint 3 (Y ~ 104)
  parts.push({
    id: nextId(),
    name: 'Checkpoint_3',
    shape: 'block',
    position: { x: -16, y: 104, z: 8 },
    rotation: { x: 0, y: 0, z: 0 },
    size: { x: 8, y: 1.2, z: 8 },
    color: '#34d399',
    material: 'neon',
    canCollide: true,
    anchored: true,
    isCheckpoint: true,
    checkpointIndex: 3,
  });

  // Zenith Needle Ascent (Y = 110 to 140)
  for (let i = 0; i < 6; i++) {
    parts.push({
      id: nextId(),
      name: `ApexPillarStep_${i + 1}`,
      shape: 'block',
      position: {
        x: -16 + i * 4.8,
        y: 110 + i * 5.0,
        z: 8 - (i % 2) * 6,
      },
      rotation: { x: 0, y: 0, z: 0 },
      size: { x: 3.5, y: 0.8, z: 3.5 },
      color: '#a855f7',
      material: 'neon',
      canCollide: true,
      anchored: true,
    });
  }

  // Pinnacle Cloud Spire Dome (The Finish!)
  parts.push({
    id: nextId(),
    name: 'SkyCrownPlatform',
    shape: 'cylinder',
    position: { x: 12, y: 144, z: 0 },
    rotation: { x: 0, y: 0, z: 0 },
    size: { x: 18, y: 2, z: 18 },
    color: '#fbbf24',
    material: 'neon',
    canCollide: true,
    anchored: true,
  });

  parts.push({
    id: nextId(),
    name: 'ObbyFinishCrown',
    shape: 'block',
    position: { x: 12, y: 148, z: 0 },
    rotation: { x: 0, y: 45, z: 0 },
    size: { x: 6, y: 5, z: 6 },
    color: '#fef08a',
    material: 'glass',
    transparency: 0.2,
    canCollide: false,
    anchored: true,
  });

  // Finish Trigger checkpoint
  parts.push({
    id: nextId(),
    name: 'Checkpoint_Finish',
    shape: 'cylinder',
    position: { x: 12, y: 145.5, z: 0 },
    rotation: { x: 0, y: 0, z: 0 },
    size: { x: 8, y: 0.5, z: 8 },
    color: '#eab308',
    material: 'neon',
    canCollide: true,
    anchored: true,
    isCheckpoint: true,
    checkpointIndex: 4,
  });

  return {
    id: 'pub-sky-tower-official',
    projectId: 'official-sky-tower',
    name: 'Sky Tower',
    title: 'Sky Tower',
    creator: 'Apex Studio',
    author: 'Apex Studio',
    isOfficialAdmin: true,
    isOfficial: true,
    description: 'Climb a magnificent monumental spire ascending 150+ studs into the clouds. Features spiraling steel steps, high-altitude balance beams, hovering glass pads, and breathtaking zenith views.',
    genre: 'Obby',
    difficulty: 'Hard',
    thumbnailUrl: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?q=80&w=800&auto=format&fit=crop',
    likes: 3840,
    favorites: 2490,
    plays: 18500,
    activePlayers: 42,
    revenue: 0,
    version: '1.0.0',
    publishedAt: '2026-08-01T00:00:00.000Z',
    createdAt: '2026-08-01T00:00:00.000Z',
    updatedAt: '2026-08-01T00:00:00.000Z',
    workspace: parts,
    scripts: [
      {
        id: 'st-scr-1',
        name: 'SkyBeaconRotate',
        type: 'server',
        content: `-- Sky Tower Beacon script\nlocal crown = workspace:FindFirstChild("ObbyFinishCrown")\nwhile true do\n  task.wait(0.05)\nend\n`,
        active: true,
      },
    ],
    lighting: {
      ambient: '#38bdf8',
      skyColor: '#0284c7',
      brightness: 1.3,
      timeOfDay: '10:00',
      graphicsTier: 'tier3',
    },
  };
}

// -------------------------------------------------------------
// GAME 2: EASY JUMP OBBY
// Beginner-friendly, wide platforms, short jumps, sunny daylight,
// frequent checkpoints, clean pastel colors.
// -------------------------------------------------------------
function buildEasyJumpObby(): PublishedGame {
  const parts: WorkspacePart[] = [];
  let partId = 1;
  const nextId = () => `ej-${partId++}`;

  // Safe Green Ground
  parts.push({
    id: nextId(),
    name: 'Baseplate',
    shape: 'block',
    position: { x: 0, y: -2, z: 50 },
    rotation: { x: 0, y: 0, z: 0 },
    size: { x: 100, y: 4, z: 180 },
    color: '#86efac',
    material: 'grass',
    canCollide: true,
    anchored: true,
  });

  // Spawn Platform
  parts.push({
    id: nextId(),
    name: 'SpawnLocation',
    shape: 'block',
    position: { x: 0, y: 1, z: 0 },
    rotation: { x: 0, y: 0, z: 0 },
    size: { x: 12, y: 1.5, z: 12 },
    color: '#3b82f6',
    material: 'plastic',
    canCollide: true,
    anchored: true,
  });

  // Stage 1 - Wide Colorful Stepping Blocks (Z = 10 to 40)
  const colors = ['#f87171', '#fbbf24', '#34d399', '#60a5fa', '#a78bfa', '#f472b6'];
  for (let i = 0; i < 6; i++) {
    parts.push({
      id: nextId(),
      name: `EasyStep_${i + 1}`,
      shape: 'block',
      position: { x: (i % 2 === 0 ? 2 : -2), y: 1.5 + i * 0.8, z: 12 + i * 5.5 },
      rotation: { x: 0, y: 0, z: 0 },
      size: { x: 6.5, y: 1.2, z: 4.5 },
      color: colors[i % colors.length],
      material: 'plastic',
      canCollide: true,
      anchored: true,
    });
  }

  // Checkpoint 1 (Z = 48)
  parts.push({
    id: nextId(),
    name: 'Checkpoint_1',
    shape: 'block',
    position: { x: 0, y: 6.5, z: 48 },
    rotation: { x: 0, y: 0, z: 0 },
    size: { x: 10, y: 1.2, z: 10 },
    color: '#10b981',
    material: 'neon',
    canCollide: true,
    anchored: true,
    isCheckpoint: true,
    checkpointIndex: 1,
  });

  // Stage 2 - Soft Archway Short Gaps (Z = 58 to 90)
  for (let i = 0; i < 5; i++) {
    parts.push({
      id: nextId(),
      name: `GentleBridge_${i + 1}`,
      shape: 'block',
      position: { x: 0, y: 7.5 + Math.sin((i / 4) * Math.PI) * 2, z: 58 + i * 6.5 },
      rotation: { x: 0, y: 0, z: 0 },
      size: { x: 6, y: 1, z: 4.5 },
      color: '#38bdf8',
      material: 'wood',
      canCollide: true,
      anchored: true,
    });

    // Soft guard railing for beginner comfort
    parts.push({
      id: nextId(),
      name: `RailLeft_${i + 1}`,
      shape: 'block',
      position: { x: -3.2, y: 8.5 + Math.sin((i / 4) * Math.PI) * 2, z: 58 + i * 6.5 },
      rotation: { x: 0, y: 0, z: 0 },
      size: { x: 0.4, y: 1.2, z: 4.5 },
      color: '#bae6fd',
      material: 'plastic',
      canCollide: true,
      anchored: true,
    });
  }

  // Checkpoint 2 (Z = 95)
  parts.push({
    id: nextId(),
    name: 'Checkpoint_2',
    shape: 'block',
    position: { x: 0, y: 8.5, z: 95 },
    rotation: { x: 0, y: 0, z: 0 },
    size: { x: 10, y: 1.2, z: 10 },
    color: '#22c55e',
    material: 'neon',
    canCollide: true,
    anchored: true,
    isCheckpoint: true,
    checkpointIndex: 2,
  });

  // Stage 3 - Rainbow Stepping Stones (Z = 105 to 135)
  for (let i = 0; i < 6; i++) {
    parts.push({
      id: nextId(),
      name: `RainbowDisc_${i + 1}`,
      shape: 'cylinder',
      position: { x: (i % 2 === 0 ? 3 : -3), y: 9 + i * 0.7, z: 105 + i * 5.2 },
      rotation: { x: 0, y: 0, z: 0 },
      size: { x: 5, y: 1, z: 5 },
      color: colors[(i + 2) % colors.length],
      material: 'plastic',
      canCollide: true,
      anchored: true,
    });
  }

  // Finish Stage
  parts.push({
    id: nextId(),
    name: 'Checkpoint_Finish',
    shape: 'block',
    position: { x: 0, y: 14, z: 144 },
    rotation: { x: 0, y: 0, z: 0 },
    size: { x: 16, y: 1.5, z: 16 },
    color: '#fbbf24',
    material: 'neon',
    canCollide: true,
    anchored: true,
    isCheckpoint: true,
    checkpointIndex: 3,
  });

  parts.push({
    id: nextId(),
    name: 'WinnerArch',
    shape: 'block',
    position: { x: 0, y: 18, z: 148 },
    rotation: { x: 0, y: 0, z: 0 },
    size: { x: 12, y: 1.5, z: 2 },
    color: '#f59e0b',
    material: 'wood',
    canCollide: false,
    anchored: true,
  });

  return {
    id: 'pub-easy-jump-obby-official',
    projectId: 'official-easy-jump-obby',
    name: 'Easy Jump Obby',
    title: 'Easy Jump Obby',
    creator: 'Apex Studio',
    author: 'Apex Studio',
    isOfficialAdmin: true,
    isOfficial: true,
    description: 'A cheerful, beginner-friendly parkour course designed for relaxed fun. Generous platform widths, short jump spans, pastel stepping stones, and forgiving checkpoint placements.',
    genre: 'Obby',
    difficulty: 'Easy',
    thumbnailUrl: 'https://images.unsplash.com/photo-1579546929518-9e396f3cc809?q=80&w=800&auto=format&fit=crop',
    likes: 4920,
    favorites: 3180,
    plays: 28400,
    activePlayers: 68,
    revenue: 0,
    version: '1.0.0',
    publishedAt: '2026-08-01T00:00:00.000Z',
    createdAt: '2026-08-01T00:00:00.000Z',
    updatedAt: '2026-08-01T00:00:00.000Z',
    workspace: parts,
    scripts: [],
    lighting: {
      ambient: '#fef08a',
      skyColor: '#38bdf8',
      brightness: 1.4,
      timeOfDay: '12:00',
      graphicsTier: 'tier2',
    },
  };
}

// -------------------------------------------------------------
// GAME 3: HARD JUMP OBBY
// Precision jumping, 8-10 stud gap leaps, thin truss beams,
// micro landing pads, punishing void falls.
// -------------------------------------------------------------
function buildHardJumpObby(): PublishedGame {
  const parts: WorkspacePart[] = [];
  let partId = 1;
  const nextId = () => `hj-${partId++}`;

  // Dark Void Base
  parts.push({
    id: nextId(),
    name: 'VoidBase',
    shape: 'block',
    position: { x: 0, y: -10, z: 60 },
    rotation: { x: 0, y: 0, z: 0 },
    size: { x: 80, y: 4, z: 160 },
    color: '#09090b',
    material: 'metal',
    canCollide: true,
    anchored: true,
  });

  // Spawn Platform
  parts.push({
    id: nextId(),
    name: 'SpawnLocation',
    shape: 'block',
    position: { x: 0, y: 2, z: 0 },
    rotation: { x: 0, y: 0, z: 0 },
    size: { x: 8, y: 1.2, z: 8 },
    color: '#ef4444',
    material: 'metal',
    canCollide: true,
    anchored: true,
  });

  // Section 1 - Precision Micro Blocks (Z = 10 to 45)
  for (let i = 0; i < 5; i++) {
    const isShift = i % 2 === 1;
    parts.push({
      id: nextId(),
      name: `PrecisionPad_${i + 1}`,
      shape: 'block',
      position: { x: isShift ? 4.5 : -4.5, y: 3 + i * 1.5, z: 11 + i * 7.2 },
      rotation: { x: 0, y: 0, z: 0 },
      size: { x: 2.2, y: 0.8, z: 2.2 },
      color: '#dc2626',
      material: 'metal',
      canCollide: true,
      anchored: true,
    });
  }

  // Checkpoint 1 (Z = 52)
  parts.push({
    id: nextId(),
    name: 'Checkpoint_1',
    shape: 'block',
    position: { x: 0, y: 11, z: 52 },
    rotation: { x: 0, y: 0, z: 0 },
    size: { x: 6, y: 1, z: 6 },
    color: '#22c55e',
    material: 'neon',
    canCollide: true,
    anchored: true,
    isCheckpoint: true,
    checkpointIndex: 1,
  });

  // Section 2 - Razor Thin Beams (Z = 60 to 95)
  for (let i = 0; i < 4; i++) {
    parts.push({
      id: nextId(),
      name: `ThinBeam_${i + 1}`,
      shape: 'block',
      position: { x: (i % 2 === 0 ? 3 : -3), y: 12 + i * 2.2, z: 62 + i * 9.0 },
      rotation: { x: 0, y: 0, z: 0 },
      size: { x: 1.2, y: 0.6, z: 6.0 },
      color: '#ea580c',
      material: 'metal',
      canCollide: true,
      anchored: true,
    });
  }

  // Checkpoint 2 (Z = 104)
  parts.push({
    id: nextId(),
    name: 'Checkpoint_2',
    shape: 'block',
    position: { x: 0, y: 22, z: 104 },
    rotation: { x: 0, y: 0, z: 0 },
    size: { x: 6, y: 1, z: 6 },
    color: '#10b981',
    material: 'neon',
    canCollide: true,
    anchored: true,
    isCheckpoint: true,
    checkpointIndex: 2,
  });

  // Section 3 - The Gauntlet (Max-Distance Leaps Y=24..35)
  for (let i = 0; i < 4; i++) {
    parts.push({
      id: nextId(),
      name: `GauntletPillar_${i + 1}`,
      shape: 'cylinder',
      position: { x: (i % 2 === 0 ? -5 : 5), y: 24 + i * 3.0, z: 114 + i * 9.5 },
      rotation: { x: 0, y: 0, z: 0 },
      size: { x: 2.0, y: 1.0, z: 2.0 },
      color: '#f43f5e',
      material: 'neon',
      canCollide: true,
      anchored: true,
    });
  }

  // Finish Platform
  parts.push({
    id: nextId(),
    name: 'Checkpoint_Finish',
    shape: 'block',
    position: { x: 0, y: 38, z: 158 },
    rotation: { x: 0, y: 0, z: 0 },
    size: { x: 12, y: 1.5, z: 12 },
    color: '#fbbf24',
    material: 'neon',
    canCollide: true,
    anchored: true,
    isCheckpoint: true,
    checkpointIndex: 3,
  });

  return {
    id: 'pub-hard-jump-obby-official',
    projectId: 'official-hard-jump-obby',
    name: 'Hard Jump Obby',
    title: 'Hard Jump Obby',
    creator: 'Apex Studio',
    author: 'Apex Studio',
    isOfficialAdmin: true,
    isOfficial: true,
    description: 'High-stakes precision parkour for expert players. Demands maximum jump timing, millimeter landings on tight beams, and zero room for error above a dark abyss.',
    genre: 'Parkour',
    difficulty: 'Hard',
    thumbnailUrl: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?q=80&w=800&auto=format&fit=crop',
    likes: 3120,
    favorites: 1850,
    plays: 14200,
    activePlayers: 36,
    revenue: 0,
    version: '1.0.0',
    publishedAt: '2026-08-01T00:00:00.000Z',
    createdAt: '2026-08-01T00:00:00.000Z',
    updatedAt: '2026-08-01T00:00:00.000Z',
    workspace: parts,
    scripts: [],
    lighting: {
      ambient: '#450a0a',
      skyColor: '#18181b',
      brightness: 0.9,
      timeOfDay: '21:00',
      graphicsTier: 'tier3',
    },
  };
}

// -------------------------------------------------------------
// GAME 4: NEON PARKOUR
// Cyberpunk glowing aesthetic, cyan/magenta/lime neon pads,
// dark futuristic grid, holographic cyber towers.
// -------------------------------------------------------------
function buildNeonParkour(): PublishedGame {
  const parts: WorkspacePart[] = [];
  let partId = 1;
  const nextId = () => `np-${partId++}`;

  // Dark Synthwave Grid
  parts.push({
    id: nextId(),
    name: 'NeonGridBase',
    shape: 'block',
    position: { x: 0, y: -4, z: 50 },
    rotation: { x: 0, y: 0, z: 0 },
    size: { x: 90, y: 2, z: 160 },
    color: '#050510',
    material: 'metal',
    canCollide: true,
    anchored: true,
  });

  // Spawn Platform
  parts.push({
    id: nextId(),
    name: 'SpawnLocation',
    shape: 'cylinder',
    position: { x: 0, y: 1, z: 0 },
    rotation: { x: 0, y: 0, z: 0 },
    size: { x: 12, y: 1.2, z: 12 },
    color: '#06b6d4',
    material: 'neon',
    canCollide: true,
    anchored: true,
  });

  // Cyan & Magenta Cyberpads (Z = 12 to 50)
  for (let i = 0; i < 6; i++) {
    const isPink = i % 2 === 1;
    parts.push({
      id: nextId(),
      name: `CyberPad_${i + 1}`,
      shape: 'block',
      position: { x: isPink ? 5 : -5, y: 2.5 + i * 1.8, z: 12 + i * 6.5 },
      rotation: { x: 0, y: isPink ? 15 : -15, z: 0 },
      size: { x: 5.5, y: 0.8, z: 5.5 },
      color: isPink ? '#ec4899' : '#06b6d4',
      material: 'neon',
      canCollide: true,
      anchored: true,
    });
  }

  // Checkpoint 1 (Z = 56)
  parts.push({
    id: nextId(),
    name: 'Checkpoint_1',
    shape: 'block',
    position: { x: 0, y: 14, z: 56 },
    rotation: { x: 0, y: 0, z: 0 },
    size: { x: 8, y: 1.2, z: 8 },
    color: '#10b981',
    material: 'neon',
    canCollide: true,
    anchored: true,
    isCheckpoint: true,
    checkpointIndex: 1,
  });

  // Electric Laser Rings Section (Z = 65 to 100)
  for (let i = 0; i < 5; i++) {
    parts.push({
      id: nextId(),
      name: `NeonRing_${i + 1}`,
      shape: 'cylinder',
      position: { x: (i % 2 === 0 ? -4 : 4), y: 15 + i * 2.2, z: 66 + i * 7.5 },
      rotation: { x: 0, y: 0, z: 0 },
      size: { x: 4.5, y: 0.8, z: 4.5 },
      color: i % 2 === 0 ? '#8b5cf6' : '#f43f5e',
      material: 'neon',
      canCollide: true,
      anchored: true,
    });
  }

  // Checkpoint 2 (Z = 108)
  parts.push({
    id: nextId(),
    name: 'Checkpoint_2',
    shape: 'block',
    position: { x: 0, y: 28, z: 108 },
    rotation: { x: 0, y: 0, z: 0 },
    size: { x: 9, y: 1.2, z: 9 },
    color: '#22c55e',
    material: 'neon',
    canCollide: true,
    anchored: true,
    isCheckpoint: true,
    checkpointIndex: 2,
  });

  // High Cyber Spire Steps (Z = 118 to 142)
  for (let i = 0; i < 4; i++) {
    parts.push({
      id: nextId(),
      name: `ZenithPillar_${i + 1}`,
      shape: 'block',
      position: { x: (i % 2 === 0 ? 4 : -4), y: 30 + i * 2.5, z: 118 + i * 7.0 },
      rotation: { x: 0, y: 45, z: 0 },
      size: { x: 4, y: 0.8, z: 4 },
      color: '#38bdf8',
      material: 'neon',
      canCollide: true,
      anchored: true,
    });
  }

  // Finish Cyber Dome
  parts.push({
    id: nextId(),
    name: 'Checkpoint_Finish',
    shape: 'cylinder',
    position: { x: 0, y: 42, z: 152 },
    rotation: { x: 0, y: 0, z: 0 },
    size: { x: 14, y: 1.5, z: 14 },
    color: '#e879f9',
    material: 'neon',
    canCollide: true,
    anchored: true,
    isCheckpoint: true,
    checkpointIndex: 3,
  });

  return {
    id: 'pub-neon-parkour-official',
    projectId: 'official-neon-parkour',
    name: 'Neon Parkour',
    title: 'Neon Parkour',
    creator: 'Apex Studio',
    author: 'Apex Studio',
    isOfficialAdmin: true,
    isOfficial: true,
    description: 'Immerse yourself in a high-voltage cyberpunk skyline with pulsing cyan and magenta neon pads, holographic platforms, and synthwave atmospheric illumination.',
    genre: 'Parkour',
    difficulty: 'Medium',
    thumbnailUrl: 'https://images.unsplash.com/photo-1508739773434-c26b3d09e071?q=80&w=800&auto=format&fit=crop',
    likes: 4210,
    favorites: 2890,
    plays: 21600,
    activePlayers: 54,
    revenue: 0,
    version: '1.0.0',
    publishedAt: '2026-08-01T00:00:00.000Z',
    createdAt: '2026-08-01T00:00:00.000Z',
    updatedAt: '2026-08-01T00:00:00.000Z',
    workspace: parts,
    scripts: [],
    lighting: {
      ambient: '#581c87',
      skyColor: '#090514',
      brightness: 1.1,
      timeOfDay: '23:00',
      graphicsTier: 'tier3',
    },
  };
}

// -------------------------------------------------------------
// GAME 5: CAVE ESCAPE
// Deep subterranean magma cavern, rocky stalagmites, glowing
// lava rivers, crystal hazards, ascending toward surface daylight.
// -------------------------------------------------------------
function buildCaveEscape(): PublishedGame {
  const parts: WorkspacePart[] = [];
  let partId = 1;
  const nextId = () => `ce-${partId++}`;

  // Cavern Magma Lake Base
  parts.push({
    id: nextId(),
    name: 'LavaSeaFloor',
    shape: 'block',
    position: { x: 0, y: -4, z: 50 },
    rotation: { x: 0, y: 0, z: 0 },
    size: { x: 80, y: 3, z: 150 },
    color: '#ef4444',
    material: 'neon',
    canCollide: true,
    anchored: true,
  });

  // Spawn Platform
  parts.push({
    id: nextId(),
    name: 'SpawnLocation',
    shape: 'block',
    position: { x: 0, y: 1, z: 0 },
    rotation: { x: 0, y: 0, z: 0 },
    size: { x: 10, y: 1.5, z: 10 },
    color: '#57534e',
    material: 'stone',
    canCollide: true,
    anchored: true,
  });

  // Section 1 - Basalt Rock Pillars over Lava (Z = 12 to 45)
  for (let i = 0; i < 5; i++) {
    parts.push({
      id: nextId(),
      name: `BasaltPillar_${i + 1}`,
      shape: 'block',
      position: { x: (i % 2 === 0 ? 4 : -4), y: 2 + i * 1.6, z: 12 + i * 7.0 },
      rotation: { x: 0, y: 10 * i, z: 0 },
      size: { x: 4.5, y: 4, z: 4.5 },
      color: '#44403c',
      material: 'stone',
      canCollide: true,
      anchored: true,
    });
  }

  // Checkpoint 1 (Z = 52)
  parts.push({
    id: nextId(),
    name: 'Checkpoint_1',
    shape: 'block',
    position: { x: 0, y: 11, z: 52 },
    rotation: { x: 0, y: 0, z: 0 },
    size: { x: 8, y: 1.2, z: 8 },
    color: '#22c55e',
    material: 'neon',
    canCollide: true,
    anchored: true,
    isCheckpoint: true,
    checkpointIndex: 1,
  });

  // Section 2 - Crystal Ridge (Z = 60 to 92)
  for (let i = 0; i < 5; i++) {
    parts.push({
      id: nextId(),
      name: `CrystalPlate_${i + 1}`,
      shape: 'cylinder',
      position: { x: (i % 2 === 0 ? -4.5 : 4.5), y: 12 + i * 2.2, z: 60 + i * 7.0 },
      rotation: { x: 0, y: 0, z: 0 },
      size: { x: 4, y: 0.8, z: 4 },
      color: '#a855f7',
      material: 'glass',
      transparency: 0.1,
      canCollide: true,
      anchored: true,
    });
  }

  // Checkpoint 2 (Z = 100)
  parts.push({
    id: nextId(),
    name: 'Checkpoint_2',
    shape: 'block',
    position: { x: 0, y: 24, z: 100 },
    rotation: { x: 0, y: 0, z: 0 },
    size: { x: 8, y: 1.2, z: 8 },
    color: '#10b981',
    material: 'neon',
    canCollide: true,
    anchored: true,
    isCheckpoint: true,
    checkpointIndex: 2,
  });

  // Section 3 - Escaping the Cavern Chimney (Z = 110 to 135)
  for (let i = 0; i < 4; i++) {
    parts.push({
      id: nextId(),
      name: `CaveExitStep_${i + 1}`,
      shape: 'block',
      position: { x: (i % 2 === 0 ? 3.5 : -3.5), y: 26 + i * 3.2, z: 110 + i * 6.5 },
      rotation: { x: 0, y: 0, z: 0 },
      size: { x: 4, y: 1, z: 4 },
      color: '#78716c',
      material: 'stone',
      canCollide: true,
      anchored: true,
    });
  }

  // Surface Exit Finish Platform (Sunlit Grass)
  parts.push({
    id: nextId(),
    name: 'Checkpoint_Finish',
    shape: 'block',
    position: { x: 0, y: 40, z: 144 },
    rotation: { x: 0, y: 0, z: 0 },
    size: { x: 14, y: 1.5, z: 14 },
    color: '#22c55e',
    material: 'grass',
    canCollide: true,
    anchored: true,
    isCheckpoint: true,
    checkpointIndex: 3,
  });

  return {
    id: 'pub-cave-escape-official',
    projectId: 'official-cave-escape',
    name: 'Cave Escape',
    title: 'Cave Escape',
    creator: 'Apex Studio',
    author: 'Apex Studio',
    isOfficialAdmin: true,
    isOfficial: true,
    description: 'Escape a fiery subterranean volcano cavern. Traverse crumbling basalt pillars over boiling magma rivers and climb luminous amethyst crystal ridges to reach the surface.',
    genre: 'Adventure',
    difficulty: 'Hard',
    thumbnailUrl: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?q=80&w=800&auto=format&fit=crop',
    likes: 3450,
    favorites: 2100,
    plays: 16800,
    activePlayers: 39,
    revenue: 0,
    version: '1.0.0',
    publishedAt: '2026-08-01T00:00:00.000Z',
    createdAt: '2026-08-01T00:00:00.000Z',
    updatedAt: '2026-08-01T00:00:00.000Z',
    workspace: parts,
    scripts: [],
    lighting: {
      ambient: '#7c2d12',
      skyColor: '#1c1917',
      brightness: 1.0,
      timeOfDay: '18:30',
      graphicsTier: 'tier3',
    },
  };
}

// -------------------------------------------------------------
// GAME 6: UPWARD OBBY
// Continuous ascending 360-degree helix spiral around a massive
// central monolith column with increasing altitude challenges.
// -------------------------------------------------------------
function buildUpwardObby(): PublishedGame {
  const parts: WorkspacePart[] = [];
  let partId = 1;
  const nextId = () => `uo-${partId++}`;

  // Center Monolith Pillar
  parts.push({
    id: nextId(),
    name: 'CenterMonolith',
    shape: 'cylinder',
    position: { x: 0, y: 40, z: 0 },
    rotation: { x: 0, y: 0, z: 0 },
    size: { x: 14, y: 90, z: 14 },
    color: '#1e293b',
    material: 'stone',
    canCollide: true,
    anchored: true,
  });

  // Base Plateau Spawn
  parts.push({
    id: nextId(),
    name: 'SpawnLocation',
    shape: 'block',
    position: { x: 0, y: 1, z: -16 },
    rotation: { x: 0, y: 0, z: 0 },
    size: { x: 10, y: 1.5, z: 10 },
    color: '#0284c7',
    material: 'plastic',
    canCollide: true,
    anchored: true,
  });

  // Spiraling Steps Around Pillar (3 full rotations, Y=3 to 75)
  const totalSteps = 24;
  for (let i = 0; i < totalSteps; i++) {
    const angle = (i * Math.PI) / 4;
    const r = 14;
    const px = Math.cos(angle) * r;
    const pz = Math.sin(angle) * r;
    const py = 3 + i * 3.0;

    parts.push({
      id: nextId(),
      name: `SpiralStep_${i + 1}`,
      shape: 'block',
      position: { x: Math.round(px * 10) / 10, y: Math.round(py * 10) / 10, z: Math.round(pz * 10) / 10 },
      rotation: { x: 0, y: -(angle * 180) / Math.PI, z: 0 },
      size: { x: 5, y: 0.8, z: 4 },
      color: i % 3 === 0 ? '#38bdf8' : i % 3 === 1 ? '#0284c7' : '#0369a1',
      material: 'metal',
      canCollide: true,
      anchored: true,
    });

    // Checkpoint at step 8 and step 16
    if (i === 7) {
      parts.push({
        id: nextId(),
        name: 'Checkpoint_1',
        shape: 'block',
        position: { x: Math.round(px * 10) / 10, y: Math.round((py + 0.5) * 10) / 10, z: Math.round(pz * 10) / 10 },
        rotation: { x: 0, y: 0, z: 0 },
        size: { x: 7, y: 1, z: 7 },
        color: '#22c55e',
        material: 'neon',
        canCollide: true,
        anchored: true,
        isCheckpoint: true,
        checkpointIndex: 1,
      });
    } else if (i === 15) {
      parts.push({
        id: nextId(),
        name: 'Checkpoint_2',
        shape: 'block',
        position: { x: Math.round(px * 10) / 10, y: Math.round((py + 0.5) * 10) / 10, z: Math.round(pz * 10) / 10 },
        rotation: { x: 0, y: 0, z: 0 },
        size: { x: 7, y: 1, z: 7 },
        color: '#10b981',
        material: 'neon',
        canCollide: true,
        anchored: true,
        isCheckpoint: true,
        checkpointIndex: 2,
      });
    }
  }

  // Summit Crown Finish Platform
  parts.push({
    id: nextId(),
    name: 'Checkpoint_Finish',
    shape: 'cylinder',
    position: { x: 0, y: 86, z: 0 },
    rotation: { x: 0, y: 0, z: 0 },
    size: { x: 16, y: 2, z: 16 },
    color: '#fbbf24',
    material: 'neon',
    canCollide: true,
    anchored: true,
    isCheckpoint: true,
    checkpointIndex: 3,
  });

  return {
    id: 'pub-upward-obby-official',
    projectId: 'official-upward-obby',
    name: 'Upward Obby',
    title: 'Upward Obby',
    creator: 'Apex Studio',
    author: 'Apex Studio',
    isOfficialAdmin: true,
    isOfficial: true,
    description: 'A spiraling vertical journey scaling an ancient celestial obelisk. Maintain rhythm and balance as the spiral tightens higher into the sky.',
    genre: 'Obby',
    difficulty: 'Medium',
    thumbnailUrl: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?q=80&w=800&auto=format&fit=crop',
    likes: 2980,
    favorites: 1720,
    plays: 13900,
    activePlayers: 31,
    revenue: 0,
    version: '1.0.0',
    publishedAt: '2026-08-01T00:00:00.000Z',
    createdAt: '2026-08-01T00:00:00.000Z',
    updatedAt: '2026-08-01T00:00:00.000Z',
    workspace: parts,
    scripts: [],
    lighting: {
      ambient: '#0284c7',
      skyColor: '#0ea5e9',
      brightness: 1.3,
      timeOfDay: '15:00',
      graphicsTier: 'tier2',
    },
  };
}

// -------------------------------------------------------------
// GAME 7: SPEED PARKOUR
// Long sprint straightaways, speed boosts, momentum flow,
// rhythm bounce pads, fast exhilarating platforming.
// -------------------------------------------------------------
function buildSpeedParkour(): PublishedGame {
  const parts: WorkspacePart[] = [];
  let partId = 1;
  const nextId = () => `sp-${partId++}`;

  // Safe Track Floor
  parts.push({
    id: nextId(),
    name: 'TrackBase',
    shape: 'block',
    position: { x: 0, y: -4, z: 80 },
    rotation: { x: 0, y: 0, z: 0 },
    size: { x: 50, y: 2, z: 200 },
    color: '#0f172a',
    material: 'metal',
    canCollide: true,
    anchored: true,
  });

  // Spawn Platform
  parts.push({
    id: nextId(),
    name: 'SpawnLocation',
    shape: 'block',
    position: { x: 0, y: 1, z: 0 },
    rotation: { x: 0, y: 0, z: 0 },
    size: { x: 12, y: 1.5, z: 12 },
    color: '#eab308',
    material: 'neon',
    canCollide: true,
    anchored: true,
  });

  // Straightaway Speed Lanes (Z = 15 to 60)
  for (let i = 0; i < 5; i++) {
    parts.push({
      id: nextId(),
      name: `SpeedStrip_${i + 1}`,
      shape: 'block',
      position: { x: 0, y: 2, z: 18 + i * 10 },
      rotation: { x: 0, y: 0, z: 0 },
      size: { x: 6, y: 0.8, z: 7.5 },
      color: '#eab308',
      material: 'neon',
      canCollide: true,
      anchored: true,
    });
  }

  // Checkpoint 1 (Z = 68)
  parts.push({
    id: nextId(),
    name: 'Checkpoint_1',
    shape: 'block',
    position: { x: 0, y: 3, z: 68 },
    rotation: { x: 0, y: 0, z: 0 },
    size: { x: 10, y: 1.2, z: 10 },
    color: '#22c55e',
    material: 'neon',
    canCollide: true,
    anchored: true,
    isCheckpoint: true,
    checkpointIndex: 1,
  });

  // Section 2 - High-Speed Slalom Jumps (Z = 78 to 120)
  for (let i = 0; i < 5; i++) {
    parts.push({
      id: nextId(),
      name: `SlalomPad_${i + 1}`,
      shape: 'block',
      position: { x: (i % 2 === 0 ? 5 : -5), y: 3.5 + i * 1.2, z: 78 + i * 9.5 },
      rotation: { x: 0, y: (i % 2 === 0 ? 15 : -15), z: 0 },
      size: { x: 5, y: 0.8, z: 6 },
      color: '#f97316',
      material: 'neon',
      canCollide: true,
      anchored: true,
    });
  }

  // Checkpoint 2 (Z = 130)
  parts.push({
    id: nextId(),
    name: 'Checkpoint_2',
    shape: 'block',
    position: { x: 0, y: 10, z: 130 },
    rotation: { x: 0, y: 0, z: 0 },
    size: { x: 10, y: 1.2, z: 10 },
    color: '#10b981',
    material: 'neon',
    canCollide: true,
    anchored: true,
    isCheckpoint: true,
    checkpointIndex: 2,
  });

  // Section 3 - Velocity Sprint to Finish (Z = 140 to 180)
  for (let i = 0; i < 4; i++) {
    parts.push({
      id: nextId(),
      name: `FinalSprintPad_${i + 1}`,
      shape: 'block',
      position: { x: 0, y: 11 + i * 1.5, z: 142 + i * 11 },
      rotation: { x: 0, y: 0, z: 0 },
      size: { x: 5.5, y: 0.8, z: 8 },
      color: '#ef4444',
      material: 'neon',
      canCollide: true,
      anchored: true,
    });
  }

  // Finish Podium
  parts.push({
    id: nextId(),
    name: 'Checkpoint_Finish',
    shape: 'block',
    position: { x: 0, y: 18, z: 195 },
    rotation: { x: 0, y: 0, z: 0 },
    size: { x: 16, y: 1.5, z: 16 },
    color: '#fbbf24',
    material: 'neon',
    canCollide: true,
    anchored: true,
    isCheckpoint: true,
    checkpointIndex: 3,
  });

  return {
    id: 'pub-speed-parkour-official',
    projectId: 'official-speed-parkour',
    name: 'Speed Parkour',
    title: 'Speed Parkour',
    creator: 'Apex Studio',
    author: 'Apex Studio',
    isOfficialAdmin: true,
    isOfficial: true,
    description: 'A high-octane speedrunner course built for fluid momentum. Chain rapid dash pads, angled slalom jumps, and high-velocity sprint lanes to shatter records.',
    genre: 'Parkour',
    difficulty: 'Medium',
    thumbnailUrl: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?q=80&w=800&auto=format&fit=crop',
    likes: 3670,
    favorites: 2310,
    plays: 19400,
    activePlayers: 48,
    revenue: 0,
    version: '1.0.0',
    publishedAt: '2026-08-01T00:00:00.000Z',
    createdAt: '2026-08-01T00:00:00.000Z',
    updatedAt: '2026-08-01T00:00:00.000Z',
    workspace: parts,
    scripts: [],
    lighting: {
      ambient: '#f59e0b',
      skyColor: '#0284c7',
      brightness: 1.3,
      timeOfDay: '16:00',
      graphicsTier: 'tier3',
    },
  };
}

// -------------------------------------------------------------
// GAME 8: RUINS PARKOUR
// Ancient temple & ruins theme, broken stone pillars, mossy stones,
// crumbling rope bridges, sandstone ruins in lush jungle.
// -------------------------------------------------------------
function buildRuinsParkour(): PublishedGame {
  const parts: WorkspacePart[] = [];
  let partId = 1;
  const nextId = () => `rp-${partId++}`;

  // Jungle Canopy Base
  parts.push({
    id: nextId(),
    name: 'JungleBaseplate',
    shape: 'block',
    position: { x: 0, y: -4, z: 60 },
    rotation: { x: 0, y: 0, z: 0 },
    size: { x: 90, y: 2, z: 160 },
    color: '#14532d',
    material: 'grass',
    canCollide: true,
    anchored: true,
  });

  // Spawn Platform (Ancient Temple Altar)
  parts.push({
    id: nextId(),
    name: 'SpawnLocation',
    shape: 'block',
    position: { x: 0, y: 1, z: 0 },
    rotation: { x: 0, y: 0, z: 0 },
    size: { x: 12, y: 2, z: 12 },
    color: '#78716c',
    material: 'stone',
    canCollide: true,
    anchored: true,
  });

  // Broken Pillars (Z = 12 to 45)
  for (let i = 0; i < 5; i++) {
    parts.push({
      id: nextId(),
      name: `AncientPillar_${i + 1}`,
      shape: 'cylinder',
      position: { x: (i % 2 === 0 ? -4 : 4), y: 2 + i * 1.5, z: 14 + i * 6.5 },
      rotation: { x: 0, y: 0, z: 0 },
      size: { x: 4.5, y: 3 + i * 1.2, z: 4.5 },
      color: i % 2 === 0 ? '#a8a29e' : '#4d7c0f',
      material: 'stone',
      canCollide: true,
      anchored: true,
    });
  }

  // Checkpoint 1 (Z = 52)
  parts.push({
    id: nextId(),
    name: 'Checkpoint_1',
    shape: 'block',
    position: { x: 0, y: 10, z: 52 },
    rotation: { x: 0, y: 0, z: 0 },
    size: { x: 8, y: 1.5, z: 8 },
    color: '#22c55e',
    material: 'neon',
    canCollide: true,
    anchored: true,
    isCheckpoint: true,
    checkpointIndex: 1,
  });

  // Crumbling Stone Bridge Planks (Z = 60 to 92)
  for (let i = 0; i < 5; i++) {
    parts.push({
      id: nextId(),
      name: `RuinPlank_${i + 1}`,
      shape: 'block',
      position: { x: (i % 2 === 0 ? 3.5 : -3.5), y: 11 + i * 1.8, z: 60 + i * 7.0 },
      rotation: { x: (i % 2 === 0 ? 5 : -5), y: 0, z: 0 },
      size: { x: 4, y: 0.8, z: 4.5 },
      color: '#d97706',
      material: 'wood',
      canCollide: true,
      anchored: true,
    });
  }

  // Checkpoint 2 (Z = 100)
  parts.push({
    id: nextId(),
    name: 'Checkpoint_2',
    shape: 'block',
    position: { x: 0, y: 21, z: 100 },
    rotation: { x: 0, y: 0, z: 0 },
    size: { x: 8, y: 1.5, z: 8 },
    color: '#10b981',
    material: 'neon',
    canCollide: true,
    anchored: true,
    isCheckpoint: true,
    checkpointIndex: 2,
  });

  // Temple Sunken Steps (Z = 110 to 135)
  for (let i = 0; i < 4; i++) {
    parts.push({
      id: nextId(),
      name: `SanctumStep_${i + 1}`,
      shape: 'block',
      position: { x: (i % 2 === 0 ? -4 : 4), y: 23 + i * 2.5, z: 110 + i * 7.0 },
      rotation: { x: 0, y: 0, z: 0 },
      size: { x: 4.5, y: 1, z: 4.5 },
      color: '#ca8a04',
      material: 'sand',
      canCollide: true,
      anchored: true,
    });
  }

  // Sanctum Altar Finish
  parts.push({
    id: nextId(),
    name: 'Checkpoint_Finish',
    shape: 'block',
    position: { x: 0, y: 35, z: 145 },
    rotation: { x: 0, y: 0, z: 0 },
    size: { x: 14, y: 2, z: 14 },
    color: '#fbbf24',
    material: 'stone',
    canCollide: true,
    anchored: true,
    isCheckpoint: true,
    checkpointIndex: 3,
  });

  return {
    id: 'pub-ruins-parkour-official',
    projectId: 'official-ruins-parkour',
    name: 'Ruins Parkour',
    title: 'Ruins Parkour',
    creator: 'Apex Studio',
    author: 'Apex Studio',
    isOfficialAdmin: true,
    isOfficial: true,
    description: 'Explore overgrown ancient temple ruins deep inside a forgotten rainforest. Hop across broken mossy columns, suspended wooden bridges, and golden sunlit sanctum steps.',
    genre: 'Adventure',
    difficulty: 'Medium',
    thumbnailUrl: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?q=80&w=800&auto=format&fit=crop',
    likes: 3190,
    favorites: 1980,
    plays: 15300,
    activePlayers: 34,
    revenue: 0,
    version: '1.0.0',
    publishedAt: '2026-08-01T00:00:00.000Z',
    createdAt: '2026-08-01T00:00:00.000Z',
    updatedAt: '2026-08-01T00:00:00.000Z',
    workspace: parts,
    scripts: [],
    lighting: {
      ambient: '#84cc16',
      skyColor: '#38bdf8',
      brightness: 1.2,
      timeOfDay: '11:00',
      graphicsTier: 'tier3',
    },
  };
}

// -------------------------------------------------------------
// GAME 9: MEGA OBBY
// Massive multi-themed parkour adventure combining 5 distinct
// biomes (Grassland -> Desert -> Cyber -> Volcanic -> Celestial Zenith),
// checkpoints, multi-stage progression, and triumphant finish.
// -------------------------------------------------------------
function buildMegaObby(): PublishedGame {
  const parts: WorkspacePart[] = [];
  let partId = 1;
  const nextId = () => `mo-${partId++}`;

  // Infinite Ocean Floor
  parts.push({
    id: nextId(),
    name: 'MegaOceanBase',
    shape: 'block',
    position: { x: 0, y: -6, z: 120 },
    rotation: { x: 0, y: 0, z: 0 },
    size: { x: 120, y: 2, z: 300 },
    color: '#0284c7',
    material: 'glass',
    transparency: 0.3,
    canCollide: true,
    anchored: true,
  });

  // Spawn Zone: Emerald Meadow (Z = 0)
  parts.push({
    id: nextId(),
    name: 'SpawnLocation',
    shape: 'block',
    position: { x: 0, y: 1, z: 0 },
    rotation: { x: 0, y: 0, z: 0 },
    size: { x: 14, y: 2, z: 14 },
    color: '#16a34a',
    material: 'grass',
    canCollide: true,
    anchored: true,
  });

  // BIOME 1: Emerald Grassland Steps (Z = 12 to 50)
  for (let i = 0; i < 6; i++) {
    parts.push({
      id: nextId(),
      name: `GrassStep_${i + 1}`,
      shape: 'block',
      position: { x: (i % 2 === 0 ? 4 : -4), y: 2 + i * 1.2, z: 12 + i * 6.5 },
      rotation: { x: 0, y: 0, z: 0 },
      size: { x: 5.5, y: 1, z: 4.5 },
      color: i % 2 === 0 ? '#4ade80' : '#22c55e',
      material: 'grass',
      canCollide: true,
      anchored: true,
    });
  }

  // Checkpoint 1 (Zone 2 Transition - Desert Sands, Z = 56)
  parts.push({
    id: nextId(),
    name: 'Checkpoint_1',
    shape: 'block',
    position: { x: 0, y: 10, z: 56 },
    rotation: { x: 0, y: 0, z: 0 },
    size: { x: 10, y: 1.5, z: 10 },
    color: '#f59e0b',
    material: 'sand',
    canCollide: true,
    anchored: true,
    isCheckpoint: true,
    checkpointIndex: 1,
  });

  // BIOME 2: Desert Sandstone Columns (Z = 66 to 105)
  for (let i = 0; i < 6; i++) {
    parts.push({
      id: nextId(),
      name: `SandColumn_${i + 1}`,
      shape: 'cylinder',
      position: { x: (i % 2 === 0 ? -4.5 : 4.5), y: 11 + i * 1.8, z: 66 + i * 6.8 },
      rotation: { x: 0, y: 0, z: 0 },
      size: { x: 4.5, y: 1, z: 4.5 },
      color: i % 2 === 0 ? '#fbbf24' : '#d97706',
      material: 'sand',
      canCollide: true,
      anchored: true,
    });
  }

  // Checkpoint 2 (Zone 3 Transition - Cyberpunk Grid, Z = 112)
  parts.push({
    id: nextId(),
    name: 'Checkpoint_2',
    shape: 'block',
    position: { x: 0, y: 23, z: 112 },
    rotation: { x: 0, y: 0, z: 0 },
    size: { x: 10, y: 1.5, z: 10 },
    color: '#06b6d4',
    material: 'neon',
    canCollide: true,
    anchored: true,
    isCheckpoint: true,
    checkpointIndex: 2,
  });

  // BIOME 3: Cyber Laser Pads (Z = 122 to 160)
  for (let i = 0; i < 6; i++) {
    parts.push({
      id: nextId(),
      name: `MegaCyber_${i + 1}`,
      shape: 'block',
      position: { x: (i % 2 === 0 ? 5 : -5), y: 24 + i * 2.0, z: 122 + i * 6.8 },
      rotation: { x: 0, y: 15, z: 0 },
      size: { x: 4.5, y: 0.8, z: 4.5 },
      color: i % 2 === 0 ? '#ec4899' : '#06b6d4',
      material: 'neon',
      canCollide: true,
      anchored: true,
    });
  }

  // Checkpoint 3 (Zone 4 Transition - Magma Volcano, Z = 168)
  parts.push({
    id: nextId(),
    name: 'Checkpoint_3',
    shape: 'block',
    position: { x: 0, y: 38, z: 168 },
    rotation: { x: 0, y: 0, z: 0 },
    size: { x: 10, y: 1.5, z: 10 },
    color: '#ef4444',
    material: 'neon',
    canCollide: true,
    anchored: true,
    isCheckpoint: true,
    checkpointIndex: 3,
  });

  // BIOME 4: Volcanic Lava Blocks (Z = 178 to 215)
  for (let i = 0; i < 6; i++) {
    parts.push({
      id: nextId(),
      name: `VolcanoStep_${i + 1}`,
      shape: 'block',
      position: { x: (i % 2 === 0 ? -4.5 : 4.5), y: 39 + i * 2.2, z: 178 + i * 6.8 },
      rotation: { x: 0, y: 0, z: 0 },
      size: { x: 4, y: 1, z: 4 },
      color: '#dc2626',
      material: 'stone',
      canCollide: true,
      anchored: true,
    });
  }

  // Checkpoint 4 (Zone 5 Transition - Celestial Clouds, Z = 224)
  parts.push({
    id: nextId(),
    name: 'Checkpoint_4',
    shape: 'block',
    position: { x: 0, y: 54, z: 224 },
    rotation: { x: 0, y: 0, z: 0 },
    size: { x: 10, y: 1.5, z: 10 },
    color: '#a855f7',
    material: 'neon',
    canCollide: true,
    anchored: true,
    isCheckpoint: true,
    checkpointIndex: 4,
  });

  // BIOME 5: Celestial Zenith Floating Clouds (Z = 234 to 270)
  for (let i = 0; i < 5; i++) {
    parts.push({
      id: nextId(),
      name: `CelestialCloud_${i + 1}`,
      shape: 'cylinder',
      position: { x: (i % 2 === 0 ? 4 : -4), y: 56 + i * 2.5, z: 234 + i * 7.5 },
      rotation: { x: 0, y: 0, z: 0 },
      size: { x: 5, y: 1, z: 5 },
      color: '#c084fc',
      material: 'glass',
      transparency: 0.2,
      canCollide: true,
      anchored: true,
    });
  }

  // Grand Finish Temple of Champions
  parts.push({
    id: nextId(),
    name: 'Checkpoint_Finish',
    shape: 'cylinder',
    position: { x: 0, y: 72, z: 282 },
    rotation: { x: 0, y: 0, z: 0 },
    size: { x: 18, y: 2, z: 18 },
    color: '#fbbf24',
    material: 'neon',
    canCollide: true,
    anchored: true,
    isCheckpoint: true,
    checkpointIndex: 5,
  });

  parts.push({
    id: nextId(),
    name: 'MegaTrophy',
    shape: 'block',
    position: { x: 0, y: 76, z: 284 },
    rotation: { x: 0, y: 45, z: 0 },
    size: { x: 5, y: 6, z: 5 },
    color: '#fef08a',
    material: 'metal',
    canCollide: false,
    anchored: true,
  });

  return {
    id: 'pub-mega-obby-official',
    projectId: 'official-mega-obby',
    name: 'Mega Obby',
    title: 'Mega Obby',
    creator: 'Apex Studio',
    author: 'Apex Studio',
    isOfficialAdmin: true,
    isOfficial: true,
    description: 'The ultimate Apex Studio obstacle expedition! Journey across 5 distinct biomes: Emerald Meadow, Golden Desert, Cyber Grid, Lava Cavern, and Celestial Zenith.',
    genre: 'Obby',
    difficulty: 'Extreme',
    thumbnailUrl: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=500&auto=format&fit=crop&q=60',
    likes: 6840,
    favorites: 4950,
    plays: 42100,
    activePlayers: 92,
    revenue: 0,
    version: '1.0.0',
    publishedAt: '2026-08-01T00:00:00.000Z',
    createdAt: '2026-08-01T00:00:00.000Z',
    updatedAt: '2026-08-01T00:00:00.000Z',
    workspace: parts,
    scripts: [],
    lighting: {
      ambient: '#38bdf8',
      skyColor: '#0ea5e9',
      brightness: 1.3,
      timeOfDay: '14:00',
      graphicsTier: 'tier3',
    },
  };
}

export function generateAllOfficialGames(): PublishedGame[] {
  return [
    buildSkyTower(),
    buildEasyJumpObby(),
    buildHardJumpObby(),
    buildNeonParkour(),
    buildCaveEscape(),
    buildUpwardObby(),
    buildSpeedParkour(),
    buildRuinsParkour(),
    buildMegaObby(),
  ];
}

// Write to published_games.json if executed directly
const games = generateAllOfficialGames();
const gamesFilePath = path.join(process.cwd(), 'published_games.json');

let existingGames: any[] = [];
if (fs.existsSync(gamesFilePath)) {
  try {
    existingGames = JSON.parse(fs.readFileSync(gamesFilePath, 'utf-8'));
    if (!Array.isArray(existingGames)) existingGames = [];
  } catch (e) {
    existingGames = [];
  }
}

// Remove old versions of official games if present and prepend all 9 official games
const officialIds = new Set(games.map(g => g.id));
const filteredExisting = existingGames.filter(g => !officialIds.has(g.id));
const combined = [...games, ...filteredExisting];

fs.writeFileSync(gamesFilePath, JSON.stringify(combined, null, 2), 'utf-8');
console.log(`Successfully generated and published ${games.length} official Apex Studio games into published_games.json! Total games: ${combined.length}`);
