import fs from 'fs';
import path from 'path';

const file = path.join(process.cwd(), 'src/components/DeveloperHubAds.tsx');
let content = fs.readFileSync(file, 'utf8');

// Replace preview section
const previewStart = content.indexOf('<div className="flex flex-col border-b border-gray-800 pb-3">');
const previewEnd = content.indexOf('</div>', content.indexOf('<span className="font-bold text-purple-400/70 text-xs">65% individual join chance</span>')) + 6;

if (previewStart > -1 && previewEnd > -1) {
    const toRemove = content.substring(previewStart, previewEnd + 12);
    // actually, let's just use regex or exact replacement
}

const badPreview = `                 <div className="flex flex-col border-b border-gray-800 pb-3">
                    <span className="text-gray-400 mb-1">Recommended to:</span>
                    <span className="font-bold text-green-400 text-sm">3–6 real players every 30 minutes</span>
                 </div>
                 
                 <div className="flex flex-col">
                    <span className="text-gray-400 mb-1">AI Visitors:</span>
                    <span className="font-bold text-purple-400 text-sm">3–6 generated every 30 minutes</span>
                    <span className="font-bold text-purple-400/70 text-xs">65% individual join chance</span>
                 </div>`;

content = content.replace(badPreview, "");

const badPreview2 = `                 <div className="flex justify-between items-center border-b border-gray-800 pb-3">
                    <span className="text-gray-400">Advertising Time:</span>
                    <span className="font-bold text-white">{durationHours} Hours</span>
                 </div>`;

const goodPreview2 = `                 <div className="flex justify-between items-center pb-3">
                    <span className="text-gray-400">Advertising Time:</span>
                    <span className="font-bold text-white">{durationHours} Hours</span>
                 </div>`;

content = content.replace(badPreview2, goodPreview2);

const badStats = `                          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 flex-1 text-center md:border-l md:border-gray-800 md:pl-6">
                             <div>
                                <p className="text-xs text-gray-500 uppercase font-bold tracking-wider mb-1">Time Left</p>
                                <p className={\`text-lg font-bold \${isActive ? 'text-white' : 'text-gray-600'}\`}>
                                   {isActive ? Math.max(0, Math.ceil((ad.endTime - Date.now()) / (1000 * 60 * 60))) + "h" : "0h"}
                                </p>
                             </div>
                             <div>
                                <p className="text-xs text-gray-500 uppercase font-bold tracking-wider mb-1">Real Recommends</p>
                                <p className="text-lg font-bold text-green-400">{ad.stats.realPlayerRecommendations}</p>
                             </div>
                             <div>
                                <p className="text-xs text-gray-500 uppercase font-bold tracking-wider mb-1">Real Clicks</p>
                                <p className="text-lg font-bold text-green-400">{ad.stats.realPlayerClicks}</p>
                             </div>
                             <div>
                                <p className="text-xs text-gray-500 uppercase font-bold tracking-wider mb-1">AI Visitors</p>
                                <p className="text-lg font-bold text-purple-400">{ad.stats.aiVisits}</p>
                             </div>
                          </div>`;

const goodStats = `                          <div className="grid grid-cols-1 md:grid-cols-1 gap-6 flex-1 text-center md:border-l md:border-gray-800 md:pl-6">
                             <div>
                                <p className="text-xs text-gray-500 uppercase font-bold tracking-wider mb-1">Time Left</p>
                                <p className={\`text-lg font-bold \${isActive ? 'text-white' : 'text-gray-600'}\`}>
                                   {isActive ? Math.max(0, Math.ceil((ad.endTime - Date.now()) / (1000 * 60 * 60))) + "h" : "0h"}
                                </p>
                             </div>
                          </div>`;

content = content.replace(badStats, goodStats);

fs.writeFileSync(file, content, 'utf8');
console.log("Patched DeveloperHubAds.tsx");
