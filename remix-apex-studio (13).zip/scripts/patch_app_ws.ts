import fs from 'fs';
import path from 'path';

const file = path.join(process.cwd(), 'src/App.tsx');
let content = fs.readFileSync(file, 'utf8');

const injection = `
          } else if (data.type === 'RECOMMENDED_AD') {
            const adGameId = data.gameId;
            const project = projects.find(p => p.id === adGameId);
            if (project) {
               // Show a custom toast notification or set state
               setRecommendedAd(project);
               setTimeout(() => setRecommendedAd(null), 15000);
            }
          }
`;

content = content.replace(
  "} else if (data.type === 'CHAT_BROADCAST' || data.type === 'CHAT_MESSAGE') {",
  injection.trim() + " else if (data.type === 'CHAT_BROADCAST' || data.type === 'CHAT_MESSAGE') {"
);

// We need to add state `recommendedAd`
content = content.replace(
  "const [equippedToolId, setEquippedToolId] = useState<string | undefined>(undefined);",
  "const [equippedToolId, setEquippedToolId] = useState<string | undefined>(undefined);\n  const [recommendedAd, setRecommendedAd] = useState<Project | null>(null);"
);

// And we need to render the Ad Recommendation UI!
// Just render it fixed at the top center of the screen
const uiCode = `
      {/* Recommended Ad Popup */}
      {recommendedAd && (
        <div className="fixed top-20 left-1/2 transform -translate-x-1/2 z-[250] bg-blue-900 border-2 border-blue-400 p-4 rounded-xl shadow-2xl flex items-center space-x-4 animate-bounce">
          <div className="w-12 h-12 bg-blue-800 rounded flex items-center justify-center overflow-hidden">
             {recommendedAd.thumbnailData ? <img src={recommendedAd.thumbnailData} className="w-full h-full object-cover" /> : <div className="text-2xl">🎮</div>}
          </div>
          <div>
            <h4 className="text-white font-bold text-lg">Sponsored: {recommendedAd.name}</h4>
            <p className="text-blue-200 text-sm">Recommended for you!</p>
          </div>
          <button 
             onClick={() => {
                fetch('/api/ads/click', { method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({ adId: data.adId }) }).catch(() => {});
                setActiveProject(recommendedAd);
                setIsPlayOnly(true);
                setRecommendedAd(null);
             }}
             className="ml-4 px-4 py-2 bg-blue-500 hover:bg-blue-400 text-white font-bold rounded-lg shadow-lg"
          >
            Play Now
          </button>
          <button onClick={() => setRecommendedAd(null)} className="ml-2 p-2 text-gray-400 hover:text-white">X</button>
        </div>
      )}
`;

content = content.replace(
  "{/* Render Real-Time Notifications or similar floating elements */}",
  "{/* Render Real-Time Notifications or similar floating elements */}\n" + uiCode
);

// Also need `data.adId` in the WS handler to track clicks. I will just pass adId to the recommendedAd state.
content = content.replace(
  "const [recommendedAd, setRecommendedAd] = useState<Project | null>(null);",
  "const [recommendedAd, setRecommendedAd] = useState<{project: Project, adId: string} | null>(null);"
);

content = content.replace(
  "setRecommendedAd(project);",
  "setRecommendedAd({ project, adId: data.adId });"
);

content = content.replace(
  "{recommendedAd && (",
  "{recommendedAd && recommendedAd.project && ("
);

content = content.replace(
  "recommendedAd.thumbnailData",
  "recommendedAd.project.thumbnailData"
);
content = content.replace(
  "recommendedAd.thumbnailData",
  "recommendedAd.project.thumbnailData"
);

content = content.replace(
  "Sponsored: {recommendedAd.name}",
  "Sponsored: {recommendedAd.project.name}"
);

content = content.replace(
  "setActiveProject(recommendedAd);",
  "setActiveProject(recommendedAd.project);"
);

content = content.replace(
  "body: JSON.stringify({ adId: data.adId })",
  "body: JSON.stringify({ adId: recommendedAd.adId })"
);

fs.writeFileSync(file, content, 'utf8');
console.log('Patched App.tsx with RECOMMENDED_AD WS handler');
