import { ApexLuaEngine } from '../src/utils/luaEngine.js';

(global as any).window = { addEventListener: () => {}, removeEventListener: () => {}, clearTimeout: () => {}, clearInterval: () => {} };

const dummyScript: any = {
  id: 'test',
  name: 'test',
  content: `
local spawnPoint = createPart({
    id = "Tycoon_SpawnPoint",
    name = "SpawnPoint",
    shape = "block",
    position = Vector3.new(0, 4, 2.5),
    size = Vector3.new(0.5, 0.1, 0.5),
    color = "#facc15",
    material = "neon",
    anchored = true,
    canCollide = false,
    transparency = 1
})
local conveyor = createPart({
    id = "Tycoon_Conveyor",
    name = "Conveyor",
    shape = "block",
    position = Vector3.new(0, 0.5, 5),
    size = Vector3.new(3, 1, 8),
    color = "#1e293b",
    material = "plastic",
    anchored = true,
    canCollide = true
})
local collector = createPart({
    id = "Tycoon_Collector",
    name = "Collector",
    shape = "block",
    position = Vector3.new(0, 1.5, 9.5),
    size = Vector3.new(3.2, 3, 2),
    color = "#10b981",
    material = "neon",
    anchored = true,
    canCollide = true
})

if conveyor then
    -- Set the physical conveyor velocity so dropped unanchored parts are pushed!
    conveyor.AssemblyLinearVelocity = Vector3.new(0, 0, 10)
end

if collector then
    collector.Touched:Connect(function(hit)
        if hit and hit.Name == "DropperOre" then
            print("[Tycoon] Collected! Destroying...")
            hit:Destroy()
        end
    end)
end

if spawnPoint then
    task.spawn(function()
        while true do
            task.wait(0.2)
            local drop = createPart({
                name = "DropperOre",
                shape = "block",
                position = spawnPoint.Position,
                size = Vector3.new(0.8, 0.8, 0.8),
                color = "#06b6d4",
                material = "neon",
                anchored = false,
                canCollide = true
            })
            print("Spawned block at", tostring(drop.Position))
        end
    end)
end
`,
  type: 'server',
  enabled: true
};

const engine = new ApexLuaEngine(dummyScript, [], null, console.log, () => {}, () => {}, () => {}, () => {});
engine.run();

const interval = setInterval(() => {
    engine.checkTouchCollisions({x:0, y:0, z:0} as any, {Health: 100} as any);
}, 33);

setTimeout(() => {
  clearInterval(interval);
  engine.stop();
  process.exit(0);
}, 2000);
