import fs from 'fs';
import path from 'path';

const fileAds = path.join(process.cwd(), 'src/components/DeveloperHubAds.tsx');
let contentAds = fs.readFileSync(fileAds, 'utf8');
contentAds = contentAds.replace(/import \{ User, Project \} from "\.\.\/types";/, 'import { UserProfile as User, Project } from "../types";');
fs.writeFileSync(fileAds, contentAds, 'utf8');

const serverFile = path.join(process.cwd(), 'server.ts');
let serverContent = fs.readFileSync(serverFile, 'utf8');

// Move botClients up
serverContent = serverContent.replace(
  'const botClients = new Map<string, ConnectedPlayerSocket>();',
  ''
);

serverContent = serverContent.replace(
  'const activeGameSessions = new Map<string, Map<string, number>>();',
  'const activeGameSessions = new Map<string, Map<string, number>>();\nconst botClients = new Map<string, ConnectedPlayerSocket>();'
);

// We need to fix the duplicate list array
// Check if the duplicate is still there
serverContent = serverContent.replace(
  'const list: any[] = [];\n  const list: any[] = [];',
  'const list: any[] = [];'
);

fs.writeFileSync(serverFile, serverContent, 'utf8');
console.log('Fixed lint issues');
