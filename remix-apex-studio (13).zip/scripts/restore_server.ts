import fs from 'fs';

let content = fs.readFileSync('server.ts', 'utf8');

// The file is currently:
// Part A: original file from 0 to spawnAIBotStart (lines 1 to 4791)
// Part B: original file from line 49 to end (lines 4792 to 9673)

// So original file is (Part A up to line 48) + (Part B)
const lines = content.split('\n');

const originalLines = [...lines.slice(0, 48), ...lines.slice(4791)];

fs.writeFileSync('server.ts', originalLines.join('\n'), 'utf8');
