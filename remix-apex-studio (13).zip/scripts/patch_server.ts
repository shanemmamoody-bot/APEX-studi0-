import fs from 'fs';

const path = 'server.ts';
let content = fs.readFileSync(path, 'utf8');

// Insert at the end of the file or somewhere appropriate if we stripped it
if (content.includes('// Removed AI bots loop for ads')) {
  const replacement = `
// Global Ad Check Loop
setInterval(() => {
  const now = Date.now();
  for (const ad of adCampaigns) {
    if (ad.status !== 'active') continue;
    if (now >= ad.endTime) {
      ad.status = 'completed';
      continue;
    }
    // Every 30 minutes
    if (now - ad.lastCycleTime >= 30 * 60 * 1000) {
      ad.lastCycleTime = now;
      // Recommend to 3-6 REAL players
      const numReal = Math.floor(Math.random() * 4) + 3;
      const onlineUsers = Array.from(wsClients.values()).filter(c => !c.id.startsWith('bot-'));
      const picked = onlineUsers.sort(() => 0.5 - Math.random()).slice(0, numReal);
      for (const p of picked) {
         if (p.ws && p.ws.readyState === 1) { // WebSocket.OPEN is 1
            p.ws.send(JSON.stringify({ type: "RECOMMENDED_AD", adId: ad.id, gameId: ad.gameId }));
            ad.stats.realPlayerRecommendations++;
         }
      }
    }
  }
});
`;
  content = content.replace('// Removed AI bots loop for ads', replacement);
  fs.writeFileSync(path, content, 'utf8');
}
