import fs from 'fs';

const path = 'src/App.tsx';
let content = fs.readFileSync(path, 'utf8');

content = content.replace(
  '<PlayerGamesHub\n              userProjects={projects}',
  '<PlayerGamesHub\n              userProjects={projects}\n              onSelectGame={(game) => setSelectedGameForDetail(game)}'
);

fs.writeFileSync(path, content, 'utf8');
