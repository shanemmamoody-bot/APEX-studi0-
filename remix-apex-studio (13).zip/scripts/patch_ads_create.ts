import fs from 'fs';
import path from 'path';

const serverFile = path.join(process.cwd(), 'server.ts');
let content = fs.readFileSync(serverFile, 'utf8');

const badCode = `   if (!userProgressionMap[uKey]) return res.status(404).json({ error: "User not found" });

   const bal = userProgressionMap[uKey].aBucks || 0;
   if (bal < budgetAbux) {
      return res.status(400).json({ error: "Insufficient Abux" });
   }
   userProgressionMap[uKey].aBucks -= budgetAbux;
   saveProgressionDB();`;

const goodCode = `   const bal = getUserBalance(uKey);
   if (bal < budgetAbux) {
      return res.status(400).json({ error: "Insufficient Abux" });
   }
   syncUserBalance(uKey, bal - budgetAbux);`;

content = content.replace(badCode, goodCode);
fs.writeFileSync(serverFile, content, 'utf8');
console.log('Patched /api/ads/create');
