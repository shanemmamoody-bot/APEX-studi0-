import fs from 'fs';
import path from 'path';

const file = path.join(process.cwd(), 'src/components/ParkAndObbyEngine.tsx');
let content = fs.readFileSync(file, 'utf8');

const headStart = content.indexOf('if (isBotPlayer) {');
const headEnd = content.indexOf('// Remote Torso', headStart);

if (headStart > -1 && headEnd > -1) {
    const badCode = content.substring(headStart, headEnd);
    const goodCode = `
                // Human Head
                ctx.fillStyle = rp.avatar?.skinColor || "#facc15";
                ctx.fillRect(headX, headY, headW, headH);

                // Human Eyes
                ctx.fillStyle = "#000000";
                ctx.fillRect(
                  rpProj.u - headW / 3,
                  headY + headH * 0.35,
                  3.5,
                  3.5,
                );
                ctx.fillRect(
                  rpProj.u + headW / 6,
                  headY + headH * 0.35,
                  3.5,
                  3.5,
                );
              
              `;
    content = content.replace(badCode, goodCode);
    fs.writeFileSync(file, content, 'utf8');
    console.log("Patched engine bot head.");
}
