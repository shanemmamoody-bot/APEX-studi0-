import fs from 'fs';
import path from 'path';

const file = path.join(process.cwd(), 'src/components/CreatorDashboard.tsx');
let content = fs.readFileSync(file, 'utf8');

// Add import
content = content.replace(
  'import { DeveloperHubGamepasses } from "./DeveloperHubGamepasses";',
  'import { DeveloperHubGamepasses } from "./DeveloperHubGamepasses";\nimport { DeveloperHubAds } from "./DeveloperHubAds";'
);

// Add rendering logic
content = content.replace(
  '        {(activeTab === "store" || activeTab === "monetization") && (',
  `        {activeTab === "ads" && (
          <DeveloperHubAds currentUser={currentUser} projects={safeProjects} />
        )}
        {(activeTab === "store" || activeTab === "monetization") && (`
);

fs.writeFileSync(file, content, 'utf8');
console.log('Patched CreatorDashboard rendering');
