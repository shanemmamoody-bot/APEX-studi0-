import fs from 'fs';

const path = 'server.ts';
let content = fs.readFileSync(path, 'utf8');

// The original file is restored. Let's find the loop.
const loopStart = content.indexOf('setInterval(() => {\n  const now = Date.now();\n  for (const ad of adCampaigns) {');

if (loopStart !== -1) {
  const replacement = `setInterval(() => {
  const now = Date.now();
  for (const ad of adCampaigns) {
    if (ad.status !== 'active') continue;
    if (now >= ad.endTime) {
      ad.status = 'completed';
      continue;
    }
    // Every 30 minutes
    if (now - ad.lastCycleTime >= 30 * 60 * 1000) {
      ad.lastCycleTime = now;
      const numReal = Math.floor(Math.random() * 4) + 3;
      const onlineUsers = Array.from(wsClients.values()).filter(c => !c.id.startsWith('bot-'));
      const picked = onlineUsers.sort(() => 0.5 - Math.random()).slice(0, numReal);
      for (const p of picked) {
         if (p.ws && p.ws.readyState === 1) { // WebSocket.OPEN is 1
            p.ws.send(JSON.stringify({ type: "RECOMMENDED_AD", adId: ad.id, gameId: ad.gameId }));
            ad.stats.realPlayerRecommendations++;
         }
      }
    }
  }
});`;

  // Find where the loop ends (the }); after spawnAIBot loop)
  // Let's just find the exact block and replace it.
  
  const botMovementStart = content.indexOf('// Bot movement', loopStart);
  
  if (botMovementStart !== -1) {
     content = content.slice(0, loopStart) + replacement + '\n  \n  ' + content.slice(botMovementStart);
  }
}

// Now remove spawnAIBot
const spawnStart = content.indexOf('function spawnAIBot(');
if (spawnStart !== -1) {
   const spawnEnd = content.indexOf('}\n', content.indexOf('activeGameSessions.get(gameId)?.set(username, Date.now());', spawnStart)) + 2;
   content = content.slice(0, spawnStart) + content.slice(spawnEnd);
}

fs.writeFileSync(path, content, 'utf8');
