import fs from 'fs';

const path = 'src/components/PlayerGamesHub.tsx';
let content = fs.readFileSync(path, 'utf8');

// Replace the stranded `return initial;  });` block
content = content.replace(
  '  // Real stats & liked status persistence\n     \n    return initial;\n  });',
  '  // Liked status persistence'
);

fs.writeFileSync(path, content, 'utf8');
