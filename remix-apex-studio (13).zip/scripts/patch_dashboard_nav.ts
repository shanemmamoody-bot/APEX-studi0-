import fs from 'fs';
import path from 'path';

const file = path.join(process.cwd(), 'src/components/CreatorDashboard.tsx');
let content = fs.readFileSync(file, 'utf8');

// Add "ads" to activeTab
content = content.replace(
  '| "gamepasses"',
  '| "gamepasses"\n    | "ads"'
);

// Add to navItems
content = content.replace(
  '{ id: "store", label: "Store & Passes", icon: Store },',
  '{ id: "store", label: "Store & Passes", icon: Store },\n    { id: "ads", label: "Advertisement", icon: Zap },'
);

// We need an Ads tab rendering logic.
// Find the switch statement or conditional rendering.

fs.writeFileSync(file, content, 'utf8');
console.log('Patched CreatorDashboard navItems');
