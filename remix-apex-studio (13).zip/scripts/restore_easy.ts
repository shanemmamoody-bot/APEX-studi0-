import fs from 'fs';
const lines = fs.readFileSync('server.ts', 'utf8').split('\n');

// Find the second const AI_MODELS_FILE
const firstIdx = lines.findIndex(l => l.includes('const AI_MODELS_FILE'));
const secondIdx = lines.findIndex((l, i) => i > firstIdx && l.includes('const AI_MODELS_FILE'));

// Find function spawnAIBot
const spawnIdx = lines.findIndex(l => l.includes('function spawnAIBot'));

if (secondIdx !== -1 && spawnIdx !== -1) {
   // delete lines from secondIdx to spawnIdx - 1
   const originalLines = [...lines.slice(0, secondIdx), ...lines.slice(spawnIdx)];
   fs.writeFileSync('server.ts', originalLines.join('\n'), 'utf8');
   console.log("Restored!");
}
