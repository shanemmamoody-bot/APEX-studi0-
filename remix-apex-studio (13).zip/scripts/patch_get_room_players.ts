import fs from 'fs';
import path from 'path';

const serverFile = path.join(process.cwd(), 'server.ts');
let content = fs.readFileSync(serverFile, 'utf8');

content = content.replace(
  'function getRoomPlayersList(gameId: string, excludeWs?: WebSocket) {',
  `function getRoomPlayersList(gameId: string, excludeWs?: WebSocket) {
  const list: any[] = [];
  // Add bots
  for (const bot of botClients.values()) {
    if (bot.gameId === gameId) {
      list.push({
        id: bot.id,
        username: bot.username,
        gameId: bot.gameId,
        gameMode: bot.gameMode,
        avatar: bot.avatar,
        x: bot.x,
        y: bot.y,
        z: bot.z,
        facingYaw: bot.facingYaw,
        animState: bot.animState,
        health: bot.health,
      });
    }
  }`
);

// We need to also patch broadcastToRoom to not break when passing 'ws' 
// Actually broadcastToRoom only iterates over wsClients so we don't need to patch it. Wait, bot logic calls broadcastToRoom. Does that work? Yes, broadcastToRoom ignores bots, sending only to real players, which is perfect.

fs.writeFileSync(serverFile, content, 'utf8');
console.log('Patched getRoomPlayersList');
