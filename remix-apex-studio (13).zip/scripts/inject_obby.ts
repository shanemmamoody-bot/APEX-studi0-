import fs from 'fs';
import path from 'path';

const file = path.join(process.cwd(), 'published_games.json');
let games = JSON.parse(fs.readFileSync(file, 'utf8'));

// Check if already injected
if (!games.find((g: any) => g.id === 'custom-obby-king-21')) {
  const newObby = {
    id: "custom-obby-king-21",
    name: "Ultimate Neon Obby",
    title: "Ultimate Neon Obby",
    creator: "king",
    author: "king",
    description: "A fun and challenging 20-stage neon obby. Jump, dodge, and conquer!",
    genre: "Platformer",
    thumbnailUrl: "https://images.unsplash.com/photo-1518770660439-4636190af475?w=500&q=80",
    likes: 543,
    favorites: 120,
    plays: 10420,
    activePlayers: 21,
    revenue: 0,
    version: "1.0.0",
    workspace: [
      {
        id: "spawn_plate",
        name: "SpawnLocation",
        type: "part",
        shape: "block",
        position: { x: 0, y: 0.5, z: 0 },
        rotation: { x: 0, y: 0, z: 0 },
        size: { x: 10, y: 1, z: 10 },
        color: "#ffffff",
        material: "plastic",
        transparency: 0,
        canCollide: true,
        anchored: true
      },
      ...Array.from({ length: 20 }).map((_, i) => ({
        id: `obby_stage_${i}`,
        name: `Stage_${i + 1}`,
        type: "part",
        shape: i % 3 === 0 ? "cylinder" : "block",
        position: { x: 0, y: (i + 1) * 2, z: (i + 1) * 8 },
        rotation: { x: i % 3 === 0 ? 0 : 0, y: 0, z: i % 3 === 0 ? 90 : 0 },
        size: { x: 6, y: 1, z: 6 },
        color: ["#ef4444", "#3b82f6", "#10b981", "#f59e0b", "#8b5cf6"][i % 5],
        material: "neon",
        transparency: 0,
        canCollide: true,
        anchored: true
      }))
    ],
    scripts: [],
    lighting: {
      ambient: "#1a1a1a",
      skyColor: "#000000",
      brightness: 2,
      timeOfDay: "00:00",
      graphicsTier: "tier2"
    },
    graphicsTier: "tier2",
    guiObjects: [],
    createdAt: new Date().toISOString().split('T')[0],
    publishedAt: new Date().toISOString()
  };

  games.unshift(newObby);
  fs.writeFileSync(file, JSON.stringify(games, null, 2), 'utf8');
  console.log("Injected Ultimate Neon Obby");
} else {
  console.log("Obby already exists");
}
