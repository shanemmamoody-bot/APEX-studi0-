import fs from 'fs';
import path from 'path';

const file = path.join(process.cwd(), 'src/server/adex/nlpBrain.ts');
let content = fs.readFileSync(file, 'utf8');

const entitiesRegex = /const entities = \[\s*'dropper', 'tycoon dropper', 'conveyor', 'collector', 'button', 'tycoon',\s*'endless runner'/;
if (entitiesRegex.test(content)) {
    content = content.replace(entitiesRegex, "const entities = [\n                'dropper', 'tycoon dropper', 'conveyor', 'collector', 'button', 'tycoon', 'door', 'shop', 'npc', 'weapon', 'obby', 'checkpoint', 'quest', 'spawn', 'ui', 'damage', 'currency', 'saving',\n                'endless runner'");
}

fs.writeFileSync(file, content, 'utf8');
console.log("Patched nlpBrain.ts for all concepts.");
