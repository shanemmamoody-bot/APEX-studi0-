import fs from 'fs';
import path from 'path';

const file = path.join(process.cwd(), 'src/App.tsx');
let content = fs.readFileSync(file, 'utf8');

// The instruction was: "Do NOT display: ... Advertising-system explanations ... Do NOT add replacement messages explaining that the information was removed ... Only clean up the player-facing and purchase-facing UI ... Keep the existing: ... Recommendations"
// The prompt implies we shouldn't display any advertising UI in the player view, but the websocket will still send 'RECOMMENDED_AD'.
// We should probably just ignore 'RECOMMENDED_AD' or remove the toast logic if it shows advertising UI.
// The user says: "Remove those details from the normal player-facing experience." 
// And: "Players should simply see the normal game and normal Apex UI."
// Let's remove the recommendedAd state and where it is rendered.

content = content.replace(/const \[recommendedAd, setRecommendedAd\] = useState<\{project: Project, adId: string\} \| null>\(null\);\n/g, '');

const onRecommendAdStart = content.indexOf('} else if (data.type === \'RECOMMENDED_AD\') {');
if (onRecommendAdStart > -1) {
    const onRecommendAdEnd = content.indexOf('} else if (data.type === \'CHAT_BROADCAST\' || data.type === \'CHAT_MESSAGE\') {');
    const replaceWith = `} else if (data.type === 'RECOMMENDED_AD') {
            // Advertising functionality is kept intact serverside.
            // Client-side UI for ad recommendations is hidden to players.
          `;
    content = content.substring(0, onRecommendAdStart) + replaceWith + content.substring(onRecommendAdEnd);
}

// See if there's any recommendedAd render logic
const renderAdStart = content.indexOf('{recommendedAd && (');
if (renderAdStart > -1) {
    let bracketCount = 0;
    let endIndex = -1;
    for (let i = renderAdStart; i < content.length; i++) {
        if (content[i] === '{') bracketCount++;
        if (content[i] === '}') {
            bracketCount--;
            if (bracketCount === 0) {
                endIndex = i;
                break;
            }
        }
    }
    if (endIndex > -1) {
        content = content.substring(0, renderAdStart) + content.substring(endIndex + 1);
    }
}

fs.writeFileSync(file, content, 'utf8');
console.log("Patched App.tsx to remove recommendedAd UI.");
