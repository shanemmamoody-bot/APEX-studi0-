import fs from 'fs';
import path from 'path';

const file = path.join(process.cwd(), 'src/components/ParkAndObbyEngine.tsx');
let content = fs.readFileSync(file, 'utf8');

const botTagStart = content.indexOf('// Floating Player Tag Above Head');
const botTagEnd = content.indexOf('ctx.shadowBlur = 0;', botTagStart);

if (botTagStart > -1 && botTagEnd > -1) {
    const badCode = content.substring(botTagStart, botTagEnd + 'ctx.shadowBlur = 0;'.length);
    const goodCode = `// Floating Player Tag Above Head
              ctx.fillStyle = "#ffffff";
              ctx.font = "bold 12px sans-serif";
              ctx.textAlign = "center";
              ctx.shadowColor = "#000000";
              ctx.shadowBlur = 4;
              ctx.fillText(
                \`🎮 \${rp.username}\`,
                rpProj.u,
                headY - 10,
              );
              ctx.shadowBlur = 0;`;
    content = content.replace(badCode, goodCode);
    fs.writeFileSync(file, content, 'utf8');
    console.log("Patched engine bot tag.");
}
