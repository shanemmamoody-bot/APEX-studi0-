import fs from 'fs';
import path from 'path';

const file = path.join(process.cwd(), 'src/utils/luaEngine.ts');
let content = fs.readFileSync(file, 'utf8');

// Remove the bad __index patch
const badIndexPatch = `
            if k == "AssemblyLinearVelocity" or k == "assemblyLinearVelocity" then
              local vel = type(v) == "table" and (v.x and v or Vector3.new(v[1], v[2], v[3])) or Vector3.zero
              rawset(t, "_assemblyLinearVelocity", vel)
              return
            end
            if k == "Velocity" or k == "velocity" then
              local vel = type(v) == "table" and (v.x and v or Vector3.new(v[1], v[2], v[3])) or Vector3.zero
              rawset(t, "_velocity", vel)
              return
            end
`;

content = content.replace(badIndexPatch, '');


const goodNewIndexPatch = `
            if k == "AssemblyLinearVelocity" or k == "assemblyLinearVelocity" then
              local vel = type(v) == "table" and (v.x and v or Vector3.new(v[1], v[2], v[3])) or Vector3.zero
              rawset(t, "_assemblyLinearVelocity", vel)
              return
            end
            if k == "Velocity" or k == "velocity" then
              local vel = type(v) == "table" and (v.x and v or Vector3.new(v[1], v[2], v[3])) or Vector3.zero
              rawset(t, "_velocity", vel)
              return
            end
`;

content = content.replace('__newindex = function(t, k, v)\n            if k == "Position"', '__newindex = function(t, k, v)\n' + goodNewIndexPatch + '\n            if k == "Position"');


fs.writeFileSync(file, content, 'utf8');
console.log("Patched physics properly.");
