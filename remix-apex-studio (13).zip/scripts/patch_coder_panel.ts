import fs from 'fs';
import path from 'path';

const file = path.join(process.cwd(), 'src/components/AICoderPanel.tsx');
let content = fs.readFileSync(file, 'utf8');

const oldPhrasesStart = content.indexOf('const phrases = [');
if (oldPhrasesStart > -1) {
    const oldPhrasesEnd = content.indexOf('];', oldPhrasesStart) + 2;
    const badCode = content.substring(oldPhrasesStart, oldPhrasesEnd);
    const goodCode = `const phrases = [
      "1. Understanding the request...",
      "2. Planning required objects/scripts...",
      "3. Building using real Apex systems...",
      "4. Running/testing generated code...",
      "5. Detecting errors...",
      "6. Fixing the errors...",
      "7. Testing again...",
      "8. Finished! System works."
    ];`;
    content = content.replace(badCode, goodCode);
    fs.writeFileSync(file, content, 'utf8');
    console.log("Patched AICoderPanel phrases.");
} else {
    console.log("Phrases array not found.");
}
