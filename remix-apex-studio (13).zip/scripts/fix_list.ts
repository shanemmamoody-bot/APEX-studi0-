import fs from 'fs';
import path from 'path';

const serverFile = path.join(process.cwd(), 'server.ts');
let content = fs.readFileSync(serverFile, 'utf8');

content = content.replace(
  'const list: any[] = [];\n  const list: any[] = [];',
  'const list: any[] = [];'
);

fs.writeFileSync(serverFile, content, 'utf8');
console.log('Fixed duplicate list');
