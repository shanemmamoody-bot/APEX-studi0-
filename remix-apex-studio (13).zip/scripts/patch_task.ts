import fs from 'fs';
import path from 'path';

const file = path.join(process.cwd(), 'src/utils/luaEngine.ts');
let content = fs.readFileSync(file, 'utf8');

const taskPatch = `
        _G.__activeThreads = {}
        
        task = {
          wait = function(sec)
            sec = tonumber(sec) or 0.03
            return coroutine.yield(sec)
          end,
          spawn = function(fn, ...)
            if type(fn) == "function" then
              local args = {...}
              local co = coroutine.create(function() fn(table.unpack(args)) end)
              table.insert(_G.__activeThreads, {co = co, wakeTime = os.clock()})
            end
          end,
          delay = function(sec, fn, ...)
            if type(fn) == "function" then
              local args = {...}
              task.spawn(function()
                task.wait(sec)
                fn(table.unpack(args))
              end)
            end
          end,
          defer = function(fn, ...)
            task.spawn(fn, ...)
          end
        }
`;

content = content.replace(/task = \{\s*wait = function\(sec\).*?defer = function\(fn, \.\.\.\)\s*task\.spawn\(fn, \.\.\.\)\s*end\s*\}/s, taskPatch.trim());

const tickPatch = `
        function _G.__checkCollisions(px, py, pz, health)
          -- Tick Threads
          if _G.__activeThreads then
            local now = os.clock()
            for i = #_G.__activeThreads, 1, -1 do
              local entry = _G.__activeThreads[i]
              if now >= entry.wakeTime then
                local ok, waitTime = coroutine.resume(entry.co)
                if not ok then
                  print("🛑 [Thread Error]:", waitTime)
                  table.remove(_G.__activeThreads, i)
                elseif coroutine.status(entry.co) == "dead" then
                  table.remove(_G.__activeThreads, i)
                else
                  entry.wakeTime = now + (tonumber(waitTime) or 0.03)
                end
              end
            end
          end
          
          if not _G.activeParts or #_G.activeParts == 0 then return end
`;

content = content.replace('function _G.__checkCollisions(px, py, pz, health)\n          if not _G.activeParts or #_G.activeParts == 0 then return end', tickPatch.trim());

fs.writeFileSync(file, content, 'utf8');
console.log("Patched task.spawn and tick");
