import fs from 'fs';
import path from 'path';

const file = path.join(process.cwd(), 'src/server/adex/nlpBrain.ts');
let content = fs.readFileSync(file, 'utf8');

// Insert 'dropper', 'tycoon', 'conveyor', 'collector', 'button' into entities
const entitiesRegex = /const entities = \[\s*'endless runner'/;
if (entitiesRegex.test(content)) {
    content = content.replace(entitiesRegex, "const entities = [\n                'dropper', 'tycoon dropper', 'conveyor', 'collector', 'button', 'tycoon',\n                'endless runner'");
}

// Map 'tycoon dropper' to 'dropper'
const nameMapRegex = /if \(e === 'trees'\) eName = 'tree';/;
if (nameMapRegex.test(content)) {
    content = content.replace(nameMapRegex, `if (e === 'trees') eName = 'tree';\n                if (e === 'tycoon dropper' || e === 'dropper') eName = 'dropper';`);
}

const requirementsStart = content.indexOf('// Endless Runner specific mechanics');
if (requirementsStart > -1) {
    const addDropperLogic = `
            // Dropper / Tycoon specific mechanics
            if (lower.includes('dropper') || primarySubject === 'dropper') {
                requirements.push({ type: 'gameplay', value: 'tycoon_dropper' });
                requirements.push({ type: 'behavior', value: 'spawn_parts' });
                requirements.push({ type: 'behavior', value: 'collect_value' });
                requirements.push({ type: 'behavior', value: 'destroy_parts' });
            }

            // Endless Runner specific mechanics`;
    content = content.replace('// Endless Runner specific mechanics', addDropperLogic);
}

fs.writeFileSync(file, content, 'utf8');
console.log("Patched nlpBrain.ts for dropper.");
