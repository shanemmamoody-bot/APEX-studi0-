import fs from 'fs';

const path = 'src/components/ExperienceDetailPage.tsx';
let content = fs.readFileSync(path, 'utf8');

const storeTabButton = `
          <button
            onClick={() => setActiveTab("store")}
            className={\`text-xs font-extrabold pb-2 border-b-2 transition-all cursor-pointer \${
              activeTab === "store"
                ? "border-[#3B82F6] text-white"
                : "border-transparent text-gray-400"
            }\`}
          >
            Gamepasses
          </button>
`;

const serverTabStr = '<button\n            onClick={() => setActiveTab("servers")}';
content = content.replace(serverTabStr, storeTabButton + serverTabStr);

const storeTabContent = `
        {activeTab === "store" && (
          <div className="space-y-4">
            <h3 className="text-white font-extrabold text-sm border-b border-[#1E1E24] pb-2">Passes & Boosts</h3>
            {purchaseSuccess && <div className="p-3 bg-emerald-500/20 text-emerald-400 text-xs rounded-xl font-bold border border-emerald-500/30">{purchaseSuccess}</div>}
            {purchaseError && <div className="p-3 bg-red-500/20 text-red-400 text-xs rounded-xl font-bold border border-red-500/30">{purchaseError}</div>}
            {gamepasses.length === 0 ? (
              <p className="text-gray-400 text-xs italic">No gamepasses available for this experience.</p>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                {gamepasses.map(gp => (
                  <div key={gp.id} className="bg-[#181820] border border-[#2B2D38] p-4 rounded-xl flex flex-col justify-between">
                    <div>
                      <h4 className="text-white font-bold text-sm mb-1">{gp.name}</h4>
                      <p className="text-gray-400 text-xs line-clamp-2 min-h-[32px]">{gp.description}</p>
                    </div>
                    <div className="mt-4 flex items-center justify-between">
                      <div className="font-mono text-emerald-400 font-extrabold text-sm">A$ {gp.price}</div>
                      {ownedPasses[gp.id] ? (
                        <div className="text-[10px] text-gray-500 font-bold bg-gray-800 px-2 py-1 rounded-md">OWNED</div>
                      ) : (
                        <button onClick={() => handlePurchasePass(gp)} className="bg-emerald-600 hover:bg-emerald-500 text-white text-[10px] font-bold px-3 py-1.5 rounded-md cursor-pointer transition-colors shadow-lg shadow-emerald-500/20">
                          BUY
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
`;

const serversTabContentStr = '{activeTab === "servers" && (';
content = content.replace(serversTabContentStr, storeTabContent + '\n        ' + serversTabContentStr);

fs.writeFileSync(path, content, 'utf8');
