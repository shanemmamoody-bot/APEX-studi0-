import fs from 'fs';
import path from 'path';

const file = path.join(process.cwd(), 'src/components/DeveloperHubAds.tsx');
let content = fs.readFileSync(file, 'utf8');

// Replace preview section
content = content.replace(/<div className="flex flex-col border-b border-gray-800 pb-3">[\s\S]*?65% individual join chance<\/span>\s*<\/div>\s*<\/div>/g, '</div>');

content = content.replace(/<div className="grid grid-cols-2 md:grid-cols-4 gap-6 flex-1 text-center md:border-l md:border-gray-800 md:pl-6">[\s\S]*?<\/div>\s*<\/div>\s*<\/div>/g, 
`<div className="grid grid-cols-1 md:grid-cols-1 gap-6 flex-1 text-center md:border-l md:border-gray-800 md:pl-6">
                             <div>
                                <p className="text-xs text-gray-500 uppercase font-bold tracking-wider mb-1">Time Left</p>
                                <p className={\`text-lg font-bold \${isActive ? 'text-white' : 'text-gray-600'}\`}>
                                   {isActive ? Math.max(0, Math.ceil((ad.endTime - Date.now()) / (1000 * 60 * 60))) + "h" : "0h"}
                                </p>
                             </div>
                          </div>
                       </div>`);

fs.writeFileSync(file, content, 'utf8');
console.log("Patched DeveloperHubAds.tsx 2");
