import fs from 'fs';

const path = 'src/App.tsx';
let content = fs.readFileSync(path, 'utf8');

const replacement = `
          } else if (data.type === 'RECOMMENDED_AD') {
            fetch('/api/games').then(r => r.json()).then(games => {
                const adGame = games.find((g: any) => g.id === data.gameId);
                if (adGame) {
                    setNotifications(prev => [{
                      id: 'ad-' + Date.now(),
                      type: 'system',
                      title: 'Sponsored Game Recommendation',
                      message: \`Play now: \${adGame.title} (\${adGame.genre})!\`,
                      timestamp: 'Just Now',
                      read: false,
                      actionLabel: 'Play Now',
                      actionUrl: '#'
                    }, ...prev]);
                    // Auto-open notifications so they see it
                    setIsNotificationsOpen(true);
                }
            }).catch(e => {});
`;

content = content.replace(
  `} else if (data.type === 'RECOMMENDED_AD') {\n            // Advertising functionality is kept intact serverside.\n            // Client-side UI for ad recommendations is hidden to players.`,
  replacement.trim()
);

fs.writeFileSync(path, content, 'utf8');
