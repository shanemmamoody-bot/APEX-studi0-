import fs from 'fs';
import path from 'path';

const serverFile = path.join(process.cwd(), 'server.ts');
let content = fs.readFileSync(serverFile, 'utf8');

// Change bot.currentJump = Math.random() < 0.15; -> bot.currentJump = Math.random() < 0.15 ? 1 : 0; OR boolean if that's what it was.
// The error says "Type 'boolean' is not assignable to type 'number'."
// Let's replace `bot.currentJump = Math.random() < 0.15;` with `bot.currentJump = (Math.random() < 0.15 ? 1 : 0) as any;` or just find out what currentJump should be. Let's just do `bot.currentJump = Math.random() < 0.15 ? 1 : 0;`

content = content.replace('bot.currentJump = Math.random() < 0.15;', 'bot.currentJump = Math.random() < 0.15 ? 1 : 0;');

fs.writeFileSync(serverFile, content, 'utf8');
console.log('Fixed currentJump type error');
