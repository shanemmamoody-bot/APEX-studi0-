with open('src/App.tsx', 'r') as f:
    lines = f.readlines()

def replace_lines(start, end, content):
    del lines[start-1:end]
    lines.insert(start-1, content)

content = """      if (partHit) {
        return { ...prev, workspace: newWorkspace };
      }
      return prev;
    });
  }, [handleSpawnChildModels]);
"""
replace_lines(1599, 1602, content)
with open('src/App.tsx', 'w') as f:
    f.writelines(lines)
