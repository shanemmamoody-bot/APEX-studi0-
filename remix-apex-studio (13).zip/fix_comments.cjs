const fs = require('fs');

function fixFile(filePath) {
    let content = fs.readFileSync(filePath, 'utf-8');
    
    // We will find all instances of "//" and try to replace them with /* ... */
    // But it's risky if "//" is inside a string.
    // Let's do a simple regex that finds "//", then looks for the next keyword that usually starts a new statement,
    // and inserts a newline before it.
    
    // Keywords: export, import, const, let, var, function, class, interface, type, return, if, for, while, switch, }, console.
    const regex = /\/\/ (.*?)(export |import |const |let |var |function |class |interface |type |return |if |for |while |switch |\} |console\.)/g;
    
    let newContent = content.replace(regex, '/* $1 */\n$2');
    
    // Also try without space after //
    const regex2 = /\/\/(.*?)(export |import |const |let |var |function |class |interface |type |return |if |for |while |switch |\} |console\.)/g;
    newContent = newContent.replace(regex2, '/* $1 */\n$2');
    
    fs.writeFileSync(filePath, newContent, 'utf-8');
}

fixFile('src/App.tsx');
console.log("App.tsx fixed");
