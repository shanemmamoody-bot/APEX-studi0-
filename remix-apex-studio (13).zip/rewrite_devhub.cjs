const fs = require('fs');
const file = 'src/components/DeveloperHubGamepasses.tsx';
let code = fs.readFileSync(file, 'utf8');

// The main grid
// <div className="grid grid-cols-1 gap-4">
code = code.replace(
  /<div className="grid grid-cols-1 gap-4">/g,
  '<div className="flex flex-col">'
);

// The cards
// className="bg-[#121215] border border-[#1E1E24] rounded-xl p-4 flex items-center justify-between"
code = code.replace(
  /className="bg-\[#121215\] border border-\[#1E1E24\] rounded-xl p-4 flex items-center justify-between"/g,
  'className="border-b border-[#1E1E24] py-4 flex items-center justify-between"'
);

// The loading state
// <div className="bg-[#121215] border border-[#1E1E24] rounded-xl p-12 text-center text-gray-400 font-mono">
code = code.replace(
  /className="bg-\[#121215\] border border-\[#1E1E24\] rounded-xl p-12 text-center text-gray-400 font-mono"/g,
  'className="py-12 border-b border-[#1E1E24] text-center text-gray-400 font-mono"'
);

// The form container
// className="bg-[#121215] p-6 rounded-xl border border-[#1E1E24] space-y-4"
code = code.replace(
  /className="bg-\[#121215\] p-6 rounded-xl border border-\[#1E1E24\] space-y-4"/g,
  'className="space-y-6 pt-4"'
);

// Input fields inside the form
// className="w-full p-2 bg-[#0A0A0C] border border-[#1E1E24] rounded-lg text-white"
code = code.replace(
  /className="w-full p-2 bg-\[#0A0A0C\] border border-\[#1E1E24\] rounded-lg text-white"/g,
  'className="w-full p-2 bg-transparent border-b border-[#1E1E24] text-white focus:outline-none focus:border-blue-500 transition-colors"'
);

// The empty spaces in the layout
// <div className="p-8  min-h-screen text-white">
code = code.replace(
  /<div className="p-8  min-h-screen text-white">/g,
  '<div className="p-8 min-h-screen text-white bg-[#0A0A0C]">'
);

fs.writeFileSync(file, code);
