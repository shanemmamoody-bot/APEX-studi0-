with open('src/App.tsx', 'r') as f:
    text = f.read()

def check_balance():
    stack = []
    for i, char in enumerate(text):
        if char == '{':
            stack.append(('{', i))
        elif char == '(':
            stack.append(('(', i))
        elif char == '}':
            if not stack:
                print(f"Extra }} at {i}")
                return
            top, pos = stack.pop()
            if top != '{':
                print(f"Mismatch at {i}: expected {top}, got }}")
                return
        elif char == ')':
            if not stack:
                print(f"Extra ) at {i}")
                return
            top, pos = stack.pop()
            if top != '(':
                print(f"Mismatch at {i}: expected {top}, got )")
                return
    for s in stack:
        print(f"Unclosed {s[0]} at index {s[1]}")

check_balance()
