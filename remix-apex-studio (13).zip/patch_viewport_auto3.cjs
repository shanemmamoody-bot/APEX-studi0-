const fs = require('fs');
let code = fs.readFileSync('src/components/Viewport.tsx', 'utf-8');

code = code.replace(
  "if (modelInst.aiMode !== 'Flee') {",
  "if (activeAiMode !== 'Flee') {"
);

code = code.replace(
  "if (modelInst.aiMode === 'Attack') {",
  "if (activeAiMode === 'Attack') {"
);

code = code.replace(
  "if (modelInst.health < modelInst.maxHealth * 0.3 && (modelInst.aiMode === 'Follow' || modelInst.aiDamage)) {",
  "if (modelInst.health < modelInst.maxHealth * 0.3 && (activeAiMode === 'Follow' || modelInst.aiDamage)) {"
);

fs.writeFileSync('src/components/Viewport.tsx', code);
