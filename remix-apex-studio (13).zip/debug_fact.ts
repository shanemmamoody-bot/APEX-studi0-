import { Adex3Engine } from "./src/server/adex/adex3Engine";
import { LearnedKnowledge } from "./src/server/adex/knowledge";

const db = LearnedKnowledge.getDb();
Adex3Engine.processText("remember my game speed is 19");

const rules = db.knowledgeBase.rules.filter((r: any) => r.category === 'fact_structured');
console.log(rules);
