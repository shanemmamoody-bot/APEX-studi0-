import React, { useState, useRef, useEffect } from "react";
import { Terminal, Play, Square, Trash2, Code, AlertTriangle, CheckCircle2, Sparkles, X, RotateCcw,
} from "lucide-react";
import { GameScript, ConsoleLog, WorkspacePart } from "../types";
import { ApexLuaEngine, luaToJS } from "../utils/luaEngine";
import { validateLuaSyntax, LuaSyntaxError } from "../utils/luaValidator"; interface LuaTesterModalProps { isOpen: boolean; onClose: () => void; workspaceParts?: WorkspacePart[];
} export const LuaTesterModal: React.FC<LuaTesterModalProps> = ({ isOpen, onClose, workspaceParts = [],
}) => { const [code, setCode] = useState<string>(`print("Hello from Apex Studio!")`); const [logs, setLogs] = useState<ConsoleLog[]>([]); const [isRunning, setIsRunning] = useState<boolean>(false); const [syntaxError, setSyntaxError] = useState<LuaSyntaxError | null>(null); const activeEngineRef = useRef<ApexLuaEngine | null>(null); const executionTimeoutRef = useRef<number | null>(null); const consoleEndRef = useRef<HTMLDivElement | null>(null); const textareaRef = useRef<HTMLTextAreaElement | null>(null); useEffect(() => { if (consoleEndRef.current) { consoleEndRef.current.scrollIntoView({ behavior: "smooth" }); } }, [logs]); if (!isOpen) return null; const sampleScripts = [ { name: "🧪 Full Engine API Suite", code: `-- 🧪 Apex Studio Full Engine API Diagnostic Suite
print("========================================")
print("▶️ STARTING APEX ENGINE API SUITE...")
print("========================================") -- 1. Math & Data Types
local v1 = Vector3.new(10, 20, 30)
local v2 = Vector3.new(5, 5, 5)
local vSum = v1 + v2
local vMag = vSum.Magnitude
assert(vSum.X == 15 and vSum.Y == 25 and vSum.Z == 35, "Vector3 math failed")
print("✅ Vector3 & Magnitude: " .. tostring(vSum) .. " | Mag=" .. string.format("%.2f", vMag)) local cf = CFrame.new(0, 5, 10) * CFrame.Angles(0, math.rad(90), 0)
print("✅ CFrame & LookVector: " .. tostring(cf.Position) .. " Look=" .. tostring(cf.LookVector)) local col = Color3.fromRGB(255, 100, 50)
print("✅ Color3 RGB & Hex: " .. col.Hex) local udim = UDim2.new(0.5, 10, 0.5, 20)
print("✅ UDim2: " .. tostring(udim)) -- 2. Services Verification
local services = { "Workspace", "Players", "Lighting", "SoundService", "TweenService", "GamepassService", "UserInputService", "StarterPack", "HttpService", "QuestService", "RatingService", "HappinessService", "DataStoreService", "RunService"
} for _, sName in ipairs(services) do local s = game:GetService(sName) assert(s ~= nil, "Failed to fetch service: " .. sName) print("✅ Service [ " .. sName .. " ] loaded successfully")
end -- 3. DataStoreService Test
local ds = game:GetService("DataStoreService"):GetStore("TestStore")
ds:SetAsync("User_1001", { coins = 500, level = 3, inventory = {"Sword", "Shield"} })
local loadedData = ds:GetAsync("User_1001")
assert(loadedData and loadedData.coins == 500, "DataStore persistence test failed")
print("✅ DataStoreService: Stored & retrieved coins=" .. tostring(loadedData.coins) .. " items=" .. table.concat(loadedData.inventory, ", ")) -- 4. QuestService Test
local quests = game:GetService("QuestService")
local dummyPlayer = Players.LocalPlayer
quests:StartQuest(dummyPlayer, "Build5Houses")
quests:AddProgress(dummyPlayer, "Build5Houses", 3)
print("✅ QuestService: Started & progressed quest 'Build5Houses'") -- 5. Rating & Happiness Services
local ratings = game:GetService("RatingService")
ratings:SetStat(dummyPlayer, "Economy", 85)
ratings:SetStat(dummyPlayer, "Safety", 90)
local currentRating = ratings:GetRating(dummyPlayer)
print("✅ RatingService: Calculated Star Rating = " .. tostring(currentRating)) local happy = game:GetService("HappinessService")
happy:Add(dummyPlayer, 25)
print("✅ HappinessService: Current Morale Index = " .. tostring(happy:Get(dummyPlayer))) -- 6. TweenService & Tween Creation
local testPart = createPart({ name = "TweenTarget", position = Vector3.new(0, 10, 0), color = "#3b82f6", anchored = true
})
local tInfo = TweenInfo.new(2, Enum.EasingStyle.Quad, Enum.EasingDirection.Out, 0, false, 0)
local tw = TweenService:Create(testPart, tInfo, { Position = Vector3.new(0, 25, 0), Transparency = 0.5
})
tw:Play()
print("✅ TweenService: Created & started Quad tween on Part") -- 7. Instance Hierarchy & Cloning
local folder = Instance.new("Folder")
folder.Name = "TestFolder"
folder.Parent = workspace
testPart.Parent = folder
assert(folder:FindFirstChild("TweenTarget") == testPart, "Hierarchy lookup failed")
local clonedPart = testPart:Clone()
clonedPart.Parent = folder
print("✅ Instance Hierarchy & Cloning: Folder child count=" .. tostring(#folder:GetChildren())) -- 8. HttpService JSON Test
local http = game:GetService("HttpService")
local jsonEncoded = http:JSONEncode({ status = "OK", code = 200, uid = http:GenerateGUID(false) })
local jsonDecoded = http:JSONDecode(jsonEncoded)
assert(jsonDecoded.code == 200, "HttpService JSON Encode/Decode failed")
print("✅ HttpService: JSON Encode & Decode verified, GUID=" .. tostring(jsonDecoded.uid)) -- 9. Raycasting Test
local rayOrigin = Vector3.new(0, 20, 0)
local rayDirection = Vector3.new(0, -50, 0)
local rayParams = RaycastParams.new()
local hitResult = workspace:Raycast(rayOrigin, rayDirection, rayParams)
if hitResult then print("✅ Raycasting: Ray intersected '" .. hitResult.Instance.Name .. "' at distance=" .. string.format("%.2f", hitResult.Distance))
else print("✅ Raycasting: Raycast executed successfully (no intersection)")
end print("========================================")
print("🎉 ALL APEX STUDIO API TESTS PASSED!")
print("========================================")`, }, { name: "🚀 TweenService Smooth Easing", code: `-- 🚀 Smooth Tweening Demo
local part = createPart({ name = "ElevatorPart", position = Vector3.new(0, 2, 0), size = Vector3.new(6, 1, 6), color = "#ec4899", anchored = true
}) print("Created elevator part. Setting up smooth Sine tween...")
local tweenInfo = TweenInfo.new(3, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut, -1, true, 0.5) local elevatorTween = TweenService:Create(part, tweenInfo, { Position = Vector3.new(0, 30, 0), Transparency = 0.3
}) elevatorTween.Completed:Connect(function(state) print("Elevator tween sequence finished with state: " .. tostring(state))
end) elevatorTween:Play()
print("▶️ Elevator tween is now playing (Infinite repeating sine loop)")`, }, { name: "🧟 Zombie NPC & AI System", code: `-- 🧟 Zombie Spawner & AI Demo
print("Spawning Apex Zombie NPC...") local zombie = createZombie({ name = "DungeonCrawler", position = Vector3.new(10, 2.25, -20), speed = 18, health = 150, damage = 15, followRange = 50
}) print("Zombie Spawned: " .. zombie.Name .. " | Health: " .. tostring(zombie.Health)) local hum = zombie.Humanoid
if hum then hum.Died:Connect(function() print("💀 Zombie died! Playing death animation & awarding XP...") end) task.delay(2, function() print("Damaging zombie by 75...") hum:TakeDamage(75) print("Zombie health now: " .. tostring(hum.Health)) end)
end`, }, { name: "🎮 UserInput & ProximityPrompt", code: `-- 🎮 User Input & Interaction Demo
local chest = createPart({ name = "TreasureChest", position = Vector3.new(0, 2, -15), size = Vector3.new(3, 2, 2), color = "#eab308", anchored = true
}) local prompt = Instance.new("ProximityPrompt")
prompt.ActionText = "Open Chest"
prompt.ObjectText = "Gold Chest"
prompt.HoldDuration = 1.0
prompt.MaxActivationDistance = 12
prompt.Parent = chest prompt.Triggered:Connect(function(player) print("🎁 Treasure Chest opened by " .. tostring(player.Name) .. "!") SoundService:PlayLocalSound("coin") chest.Color = Color3.fromHex("#22c55e")
end) local uis = game:GetService("UserInputService")
uis.InputBegan:Connect(function(input, isProcessed) if not isProcessed then print("Key Pressed: " .. tostring(input.KeyCode)) end
end) print("ProximityPrompt & UserInputService active. Press E or interact with the chest.")`, }, { name: "Damage Block (onTouch)", code: `local block = createPart({ name = "DamageBlock", position = Vector3.new(0, 5, 0), size = Vector3.new(8, 1, 8), color = "red", anchored = true
}) block:onTouch(function(player) player:takeDamage(20)
end)`, }, { name: "Loops & Countdown", code: `print("Starting Apex Lua Countdown...") for i = 5, 1, -1 do print("T-minus: " .. tostring(i) .. " seconds") task.wait(0.4)
end print("🚀 Blast off! Apex Lua Engine is running!")`, }, { name: "Lava Damage & Respawning", code: `-- Lua Lava Damage System
local player = Players.LocalPlayer if player then print("Player spawned with Health: " .. tostring(player.Health)) print("Stepping on lava...") player:takeDamage(40) print("Health after lava: " .. tostring(player.Health)) if player.Health <= 60 then print("⚡ Warning: Health Low! Respawning player...") player.Position = Vector3.new(0, 5, 0) player.Health = 100 print("Respawn complete. Health restored to: " .. tostring(player.Health)) end
end`, }, ]; const handleClearOutput = () => { setLogs([]); }; const handleStopScript = () => { if (activeEngineRef.current) { activeEngineRef.current.stop(); activeEngineRef.current = null; } if (executionTimeoutRef.current) { window.clearTimeout(executionTimeoutRef.current); executionTimeoutRef.current = null; } setIsRunning(false); setLogs((prev) => [ ...prev, { id: "stop-" + Date.now(), type: "system", message: "🛑 Execution stopped by user.", timestamp: new Date().toLocaleTimeString(), }, ]); }; const handleRunScript = () => { // 1. Stop any currently running instance handleStopScript(); setSyntaxError(null); // 2. Syntax Check const err = validateLuaSyntax(code); if (err) { setSyntaxError(err); setLogs((prev) => [ ...prev, { id: "err-" + Date.now(), type: "error", message: `🛑 [Lua Syntax Error on line ${err.line}]: ${err.message}`, timestamp: new Date().toLocaleTimeString(), }, ]); return; } setIsRunning(true); const dummyScript: GameScript = { id: "lua-tester-" + Date.now(), name: "LuaTesterScript", type: "server", content: code, active: true, }; const dummyPlayer = { Position: { x: 0, y: 3, z: 0 }, Health: 100, Gravity: 0.8, VelocityY: 0, Speed: 16, WalkSpeed: 16, onWalkSpeedChange: (speedVal: number) => { dummyPlayer.WalkSpeed = speedVal; dummyPlayer.Speed = speedVal; }, takeDamage: (amt: number) => { dummyPlayer.Health = Math.max(0, dummyPlayer.Health - amt); }, heal: (amt: number) => { dummyPlayer.Health = Math.min(100, dummyPlayer.Health + amt); }, }; // 3. Create Lua Engine Instance const engine = new ApexLuaEngine( dummyScript, workspaceParts, dummyPlayer, (log) => { setLogs((prev) => [ ...prev, { id: "log-" + Date.now() + "-" + Math.random().toString(36).substring(2, 5), type: log.type, message: log.message, timestamp: new Date().toLocaleTimeString(), }, ]); }, () => {}, () => {}, (newPart) => { workspaceParts.push(newPart); }, undefined, (scriptErr) => { setLogs((prev) => [ ...prev, { id: "err-" + Date.now(), type: "error", message: `🛑 [Runtime Error]: ${scriptErr.message}`, timestamp: new Date().toLocaleTimeString(), }, ]); }, ); activeEngineRef.current = engine; // 4. Execution with safety timeout (10 seconds max to prevent infinite loops) try { engine.run(); executionTimeoutRef.current = window.setTimeout(() => { if (activeEngineRef.current) { activeEngineRef.current.stop(); setIsRunning(false); } }, 10000); } catch (e: any) { setLogs((prev) => [ ...prev, { id: "err-" + Date.now(), type: "error", message: `🛑 Execution Failed: ${e?.message || String(e)}`, timestamp: new Date().toLocaleTimeString(), }, ]); setIsRunning(false); } }; const lineCount = Math.max(1, (code || "").split("\n").length); return ( <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4"> <div className="bg-[#121218] border-2 border-zinc-800 w-full max-w-4xl rounded-2xl overflow-hidden shadow-sm flex flex-col h-[650px]"> {/* Header */} <div className="px-5 py-3.5 bg-[#1A1A24] border-b border-zinc-800 flex items-center justify-between"> <div className="flex items-center space-x-3"> <div className="p-2 bg-zinc-800 border border-zinc-800 rounded-xl text-zinc-100"> <Terminal className="h-5 w-5 text-zinc-100" /> </div> <div> <div className="flex items-center space-x-2"> <h3 className="text-sm font-black text-white uppercase tracking-wider font-sans"> Apex Studio Built-in Lua Tester </h3> <span className="text-[10px] bg-zinc-800 text-zinc-100 font-mono font-bold px-2 py-0.5 rounded border border-zinc-800"> LUA ONLY </span> </div> <p className="text-[11px] text-gray-400 font-sans"> Real-time Lua execution sandbox with syntax checking, output console, and safe execution. </p> </div> </div> <button onClick={onClose} className="p-1.5 text-gray-400 hover:text-white rounded-lg bg-[#252533] hover:bg-[#323245] transition-colors cursor-pointer" > <X className="h-5 w-5" /> </button> </div> {/* Action Controls & Preset Loader */} <div className="px-5 py-2.5 bg-[#161620] border-b border-[#2A2A3A] flex flex-wrap items-center justify-between gap-3 font-sans"> {/* Main Action Buttons */} <div className="flex items-center space-x-2"> <button onClick={handleRunScript} className="px-4 py-1.5 bg-[#27272a] hover: hover: text-white font-extrabold text-xs rounded-xl shadow-sm flex items-center space-x-1.5 transition-all cursor-pointer active:scale-95" > <Play className="h-3.5 w-3.5 fill-current" /> <span>Run Script</span> </button> <button onClick={handleStopScript} disabled={!isRunning} className={`px-3 py-1.5 border text-xs font-bold rounded-xl flex items-center space-x-1.5 transition-all cursor-pointer ${ isRunning ? "bg-red-500/20 border-red-500/50 text-red-300 hover:bg-red-500/30" : "bg-gray-800/40 border-gray-700 text-gray-500 cursor-not-allowed" }`} > <Square className="h-3.5 w-3.5 fill-current" /> <span>Stop</span> </button> <button onClick={handleClearOutput} className="px-3 py-1.5 bg-[#222230] hover:bg-[#2C2C3E] border border-gray-700/60 text-gray-300 font-bold text-xs rounded-xl flex items-center space-x-1.5 transition-all cursor-pointer" > <Trash2 className="h-3.5 w-3.5" /> <span>Clear Output</span> </button> </div> {/* Sample Scripts Selector */} <div className="flex items-center space-x-2 text-xs"> <span className="text-gray-400 font-bold">Samples:</span> <select onChange={(e) => { const selected = sampleScripts.find( (s) => s.name === e.target.value, ); if (selected) { setCode(selected.code); setSyntaxError(null); } }} className="bg-[#222230] border border-zinc-800 text-white rounded-lg px-2 py-1 outline-none text-xs font-mono" > {sampleScripts.map((s) => ( <option key={s.name} value={s.name}> {s.name} </option> ))} </select> </div> </div> {/* Main Content Area: Editor + Console Split */} <div className="flex-1 grid grid-cols-1 md:grid-cols-2 overflow-hidden"> {/* Left: Code Editor */} <div className="flex flex-col border-b md:border-b-0 md:border-r border-[#2A2A3A] bg-[#0E0E14] overflow-hidden"> <div className="px-3 py-1.5 bg-[#14141E] border-b border-[#222230] flex items-center justify-between text-[11px] font-mono text-gray-400"> <span className="flex items-center space-x-1 font-bold text-zinc-100"> <Code className="h-3.5 w-3.5" /> <span>Lua Script Editor</span> </span> <span>{lineCount} Lines</span> </div> {/* Editor Body with Line Numbers */} <div className="flex-1 relative flex overflow-hidden font-mono text-xs"> {/* Line numbers column */} <div className="w-10 bg-[#12121A] text-gray-600 text-right pr-2 py-3 select-none border-r border-[#222230]"> {Array.from({ length: lineCount }).map((_, idx) => ( <div key={idx} className={`h-5 leading-5 ${ syntaxError && syntaxError.line === idx + 1 ? "text-red-400 font-bold bg-red-500/20" : "" }`} > {idx + 1} </div> ))} </div> {/* Textarea */} <textarea ref={textareaRef} value={code} onChange={(e) => { setCode(e.target.value); setSyntaxError(null); }} placeholder="-- Write Lua code here..." className="flex-1 bg-transparent text-gray-100 p-3 leading-5 outline-none resize-none font-mono text-xs scrollbar-thin scrollbar-thumb-cyan-900/40" spellCheck={false} /> </div> {/* Syntax Error Notice Banner */} {syntaxError && ( <div className="p-2.5 bg-red-950/80 border-t border-red-500/50 text-red-300 text-xs flex items-center space-x-2"> <AlertTriangle className="h-4 w-4 text-red-400 shrink-0" /> <span className="font-mono text-[11px] break-all"> Line {syntaxError.line}: {syntaxError.message} </span> </div> )} </div> {/* Right: Output Console */} <div className="flex flex-col bg-[#0A0A0F] overflow-hidden font-mono"> <div className="px-3 py-1.5 bg-[#14141E] border-b border-[#222230] flex items-center justify-between text-[11px] text-gray-400"> <span className="flex items-center space-x-1 font-bold text-emerald-400"> <Terminal className="h-3.5 w-3.5" /> <span>Output Console</span> </span> <span className="text-[10px] text-gray-500"> {logs.length} Entries </span> </div> {/* Console Log Stream */} <div className="flex-1 overflow-y-auto p-3 space-y-1.5 text-xs scrollbar-thin scrollbar-thumb-emerald-900/30"> {logs.length === 0 ? ( <div className="h-full flex flex-col items-center justify-center text-gray-600 text-center p-4 select-none"> <Terminal className="h-8 w-8 mb-2 opacity-30 text-zinc-100" /> <p className="text-xs font-bold text-gray-500"> Output console is empty. </p> <p className="text-[10px] text-gray-600 mt-0.5"> Click "Run Script" to execute Lua code and view print() logs here. </p> </div> ) : ( logs.map((log) => { let textStyle = "text-gray-300"; if (log.type === "print") textStyle = "text-emerald-300 font-bold"; if (log.type === "system") textStyle = "text-zinc-100 font-semibold"; if (log.type === "warn") textStyle = "text-amber-300 font-semibold"; if (log.type === "error") textStyle = "text-red-400 font-bold bg-red-950/30 p-1.5 rounded border border-red-800/40"; return ( <div key={log.id} className={`${textStyle} leading-relaxed break-words`} > {log.message} </div> ); }) )} <div ref={consoleEndRef} /> </div> </div> </div> {/* Footer Info */} <div className="px-5 py-2 bg-[#0C0C12] border-t border-[#1F1F2E] flex items-center justify-between text-[10px] text-gray-500 font-sans"> <span> Apex Lua VM Sandbox • Supports{" "} <code className="text-zinc-100 font-mono">print()</code>,{" "} <code className="text-zinc-100 font-mono">task.wait()</code>,{" "} <code className="text-zinc-100 font-mono">workspace</code>,{" "} <code className="text-zinc-100 font-mono">Players</code> </span> <span className="text-zinc-100 font-bold">Lua Only</span> </div> </div> </div> );
};
