declare module 'fengari' { export const lua: any; export const lauxlib: any; export const lualib: any; export function to_jsstring(uint8Array: any): string; export function to_luastring(str: string): Uint8Array; const fengari: any; export default fengari;
} declare module 'fengari-web' { export const interop: any; export const lua: any; export const lauxlib: any; export const lualib: any; export function to_jsstring(uint8Array: any): string; export function to_luastring(str: string): Uint8Array; const fengariWeb: any; export default fengariWeb;
}
