export const constants = { UV_UDP_REUSEPORT: 4, dlopen: {}, errno: { E2BIG: 7, EACCES: 13, EBADF: 9, BUSY: 16, EXIST: 17, EINTR: 4, EINVAL: 22, EIO: 5, ISDIR: 21, EMFILE: 24, ENOENT: 2, NOMEM: 12, NOSPC: 28, NOTDIR: 20, PERM: 1, PIPE: 32, }, signals: {}, priority: {},
}; export function platform() { return 'browser';
} export function tmpdir() { return '/tmp';
} export function homedir() { return '/';
} export function type() { return 'Browser';
} export function arch() { return 'x64';
} export function release() { return '1.0.0';
} export function endianness() { return 'LE';
} const os = { constants, platform, tmpdir, homedir, type, arch, release, endianness, ...constants,
}; export default os; 