export const constants = { O_RDONLY: 0, O_WRONLY: 1, O_RDWR: 2, O_CREAT: 64, O_EXCL: 128, O_NOCTTY: 256, O_TRUNC: 512, O_APPEND: 1024, O_DIRECTORY: 65536, O_NOATIME: 262144, O_NOFOLLOW: 131072, O_SYNC: 1052672, O_DSYNC: 4096, O_SYMLINK: 32768, O_NONBLOCK: 2048, F_OK: 0, R_OK: 4, W_OK: 2, X_OK: 1,
}; export function readFileSync() { return '';
} export function writeFileSync() {} export function existsSync() { return false;
} export function statSync() { return { isFile: () => false, isDirectory: () => false };
} export function readdirSync() { return [];
} export function openSync() { return 1;
} export function closeSync() {} export function unlinkSync() {} export function rmdirSync() {} export function mkdirSync() {} const fs = { constants, readFileSync, writeFileSync, existsSync, statSync, readdirSync, openSync, closeSync, unlinkSync, rmdirSync, mkdirSync, ...constants,
}; export default fs; 