export function execSync() { return '';
} export function exec() {} export function spawn() {} const childProcess = { execSync: () => '', exec: () => {}, spawn: () => {},
}; export default childProcess;
