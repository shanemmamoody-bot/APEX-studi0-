export function resolve(...args: string[]) { return args.join('/');
} export function join(...args: string[]) { return args.join('/');
} export function dirname(p: string) { return p.substring(0, p.lastIndexOf('/')) || '.';
} export function basename(p: string) { return p.substring(p.lastIndexOf('/') + 1);
} export function extname(p: string) { const i = p.lastIndexOf('.'); return i >= 0 ? p.substring(i) : '';
} export const sep = '/'; const pathPolyfill = { resolve: (...args: string[]) => args.join('/'), join: (...args: string[]) => args.join('/'), dirname: (p: string) => p.substring(0, p.lastIndexOf('/')) || '.', basename: (p: string) => p.substring(p.lastIndexOf('/') + 1), extname: (p: string) => { const i = p.lastIndexOf('.'); return i >= 0 ? p.substring(i) : ''; }, sep: '/',
}; export default pathPolyfill;
