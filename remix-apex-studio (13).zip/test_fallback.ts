import { ReasoningEngine } from "./src/server/adex/adex3Engine";
import { generateProceduralText } from "./src/server/adex/proceduralText";

console.log(generateProceduralText("what is the meaning of life?", "adex_3"));
