const fs = require('fs');
let code = fs.readFileSync('src/components/Viewport.tsx', 'utf-8');

const targetStr = `          const stepMoveRigid = (targetX: number, targetZ: number, moveSpeed: number, faceTarget: boolean = true) => {
            const stepDx = targetX - mPos.x;
            const stepDz = targetZ - mPos.z;
            const stepDist = Math.sqrt(stepDx * stepDx + stepDz * stepDz);
            if (stepDist > 0.01) {
              const moveDist = Math.min(stepDist, (moveSpeed * dt) / 1000);
              const dirX = stepDx / stepDist;
              const dirZ = stepDz / stepDist;`;

const replaceStr = `          const stepMoveRigid = (targetX: number, targetZ: number, moveSpeed: number, faceTarget: boolean = true, targetY?: number) => {
            const stepDx = targetX - mPos.x;
            const stepDz = targetZ - mPos.z;
            const stepDist = Math.sqrt(stepDx * stepDx + stepDz * stepDz);
            
            // Handle Flying
            if (modelInst.aiIsFlying) {
               const ty = targetY !== undefined ? targetY : curPlayerPos.y + (modelInst.aiHoverHeight || 4);
               const dyY = ty - mPos.y;
               if (Math.abs(dyY) > 0.1) {
                 mainPart.position.y += Math.sign(dyY) * Math.min(Math.abs(dyY), ((modelInst.aiFlySpeed || moveSpeed) * dt) / 1000);
               }
            }
            
            if (stepDist > 0.01) {
              const moveDist = Math.min(stepDist, (moveSpeed * dt) / 1000);
              const dirX = stepDx / stepDist;
              const dirZ = stepDz / stepDist;`;

code = code.replace(targetStr, replaceStr);
fs.writeFileSync('src/components/Viewport.tsx', code);
