const fs = require('fs');
let code = fs.readFileSync('src/components/Viewport.tsx', 'utf-8');

const targetStr = `          // SMART AI: Self-Preservation Override
          // If the AI has health, and is below 30%, and is currently following or attacking, override to flee
          if (modelInst.health !== undefined && modelInst.maxHealth !== undefined) {`;

const replaceStr = `          // SMART AI: Faction Override
          if (modelInst.aiFaction === 'Hostile') {
             // Vision check
             const playerAngle = Math.atan2(dx, dz) * (180 / Math.PI);
             const viewDiff = Math.abs((playerAngle - mainPart.rotation.y + 360 + 180) % 360 - 180);
             const isAware = viewDiff <= 80 || dist < 8; // 160 deg FOV or hear them closely
             
             if (dist < 40 && isAware) {
               // Remove passive behaviors
               for (let i = behaviors.length - 1; i >= 0; i--) {
                  if (['Wander', 'Patrol', 'Guard Area', 'Idle'].includes(behaviors[i].type)) {
                    behaviors.splice(i, 1);
                  }
               }
               // Add aggressive chase if not already fleeing
               if (modelInst.aiMode !== 'Flee') {
                 behaviors.push({ type: 'Follow Player', speed: (modelInst.aiWalkSpeed || 16) * 1.2, followDistance: 1 });
                 behaviors.push({ type: 'Deal Damage', damage: modelInst.aiDamage || 15, radius: 3.5, cooldown: 1.0 });
               }
             }
          }
          
          // SMART AI: Attack Mode Manual Override
          if (modelInst.aiMode === 'Attack') {
             for (let i = behaviors.length - 1; i >= 0; i--) {
                if (['Wander', 'Patrol', 'Guard Area', 'Idle'].includes(behaviors[i].type)) {
                  behaviors.splice(i, 1);
                }
             }
             behaviors.push({ type: 'Follow Player', speed: (modelInst.aiWalkSpeed || 16) * 1.2, followDistance: 1 });
             behaviors.push({ type: 'Deal Damage', damage: modelInst.aiDamage || 15, radius: 3.5, cooldown: 1.0 });
          }

          // SMART AI: Self-Preservation Override
          // If the AI has health, and is below 30%, and is currently following or attacking, override to flee
          if (modelInst.health !== undefined && modelInst.maxHealth !== undefined) {`;

code = code.replace(targetStr, replaceStr);
fs.writeFileSync('src/components/Viewport.tsx', code);
