const fs = require('fs');
let code = fs.readFileSync('src/components/PropertiesPanel.tsx', 'utf-8');

const targetStr = `                      {/* Mentality */}
                      <label className="flex items-center gap-2 cursor-pointer mb-1 group">
                        <input
                          type="checkbox"
                          checked={selectedPart.aiPackMentality || false}
                          onChange={(e) => handlePartChange("aiPackMentality", e.target.checked)}
                          className="w-3 h-3 accent-amber-600 rounded bg-[#090d18] border border-gray-600 cursor-pointer"
                        />
                        <span className="text-gray-300 font-medium text-xs group-hover:text-white transition-colors">
                          Pack Mentality (Call nearby allies)
                        </span>
                      </label>
                      <label className="flex items-center gap-2 cursor-pointer mb-2 group">
                        <input
                          type="checkbox"
                          checked={selectedPart.aiSleepAtNight || false}
                          onChange={(e) => handlePartChange("aiSleepAtNight", e.target.checked)}
                          className="w-3 h-3 accent-amber-600 rounded bg-[#090d18] border border-gray-600 cursor-pointer"
                        />
                        <span className="text-gray-300 font-medium text-xs group-hover:text-white transition-colors">
                          Sleeps At Night
                        </span>
                      </label>
                    </div>`;

const replaceStr = targetStr + `
                    <div className="pt-2 mt-2 border-t border-gray-800">
                      <details className="group">
                        <summary className="text-emerald-500 font-bold text-[10px] cursor-pointer mb-2 select-none hover:text-emerald-400">
                          ▶ 40+ ADVANCED AI BLUEPRINT SYSTEMS
                        </summary>
                        <div className="pl-2 space-y-2 pb-2">
                          
                          {/* Movement & Navigation */}
                          <div className="space-y-1">
                             <span className="text-gray-500 font-bold text-[9px] uppercase tracking-wider block">Movement</span>
                             <label className="flex items-center gap-2 cursor-pointer group">
                                <input type="checkbox" checked={selectedPart.aiIsFlying || false} onChange={(e) => handlePartChange("aiIsFlying", e.target.checked)} className="w-3 h-3 accent-emerald-600 rounded bg-[#090d18] border border-gray-600" />
                                <span className="text-gray-400 font-medium text-xs">Is Flying AI</span>
                             </label>
                             <label className="flex items-center gap-2 cursor-pointer group">
                                <input type="checkbox" checked={selectedPart.aiCanSwim || false} onChange={(e) => handlePartChange("aiCanSwim", e.target.checked)} className="w-3 h-3 accent-emerald-600 rounded bg-[#090d18] border border-gray-600" />
                                <span className="text-gray-400 font-medium text-xs">Can Swim</span>
                             </label>
                             <label className="flex items-center gap-2 cursor-pointer group">
                                <input type="checkbox" checked={selectedPart.aiCanOpenDoors || false} onChange={(e) => handlePartChange("aiCanOpenDoors", e.target.checked)} className="w-3 h-3 accent-emerald-600 rounded bg-[#090d18] border border-gray-600" />
                                <span className="text-gray-400 font-medium text-xs">Can Open Doors</span>
                             </label>
                             <label className="flex items-center gap-2 cursor-pointer group">
                                <input type="checkbox" checked={selectedPart.aiAvoidFire || false} onChange={(e) => handlePartChange("aiAvoidFire", e.target.checked)} className="w-3 h-3 accent-emerald-600 rounded bg-[#090d18] border border-gray-600" />
                                <span className="text-gray-400 font-medium text-xs">Avoids Fire/Lava</span>
                             </label>
                          </div>

                          {/* Combat Stats */}
                          <div className="space-y-1 mt-2">
                             <span className="text-gray-500 font-bold text-[9px] uppercase tracking-wider block">Combat Stats</span>
                             <div className="flex items-center justify-between gap-2 text-gray-400">
                                <span className="shrink-0 font-medium text-[10px]">Armor Rating</span>
                                <input type="number" value={selectedPart.aiArmorRating ?? 0} onChange={(e) => handlePartChange("aiArmorRating", parseFloat(e.target.value) || 0)} className="bg-[#0d0810] text-white border border-[#3b1119] rounded px-1 py-0.5 text-[10px] w-12 text-right" />
                             </div>
                             <div className="flex items-center justify-between gap-2 text-gray-400">
                                <span className="shrink-0 font-medium text-[10px]">Knockback Power</span>
                                <input type="number" value={selectedPart.aiKnockbackPower ?? 10} onChange={(e) => handlePartChange("aiKnockbackPower", parseFloat(e.target.value) || 0)} className="bg-[#0d0810] text-white border border-[#3b1119] rounded px-1 py-0.5 text-[10px] w-12 text-right" />
                             </div>
                             <div className="flex items-center justify-between gap-2 text-gray-400">
                                <span className="shrink-0 font-medium text-[10px]">Attack Range</span>
                                <input type="number" value={selectedPart.aiAttackRange ?? 4} onChange={(e) => handlePartChange("aiAttackRange", parseFloat(e.target.value) || 0)} className="bg-[#0d0810] text-white border border-[#3b1119] rounded px-1 py-0.5 text-[10px] w-12 text-right" />
                             </div>
                             <div className="flex items-center justify-between gap-2 text-gray-400">
                                <span className="shrink-0 font-medium text-[10px]">Health Regen/sec</span>
                                <input type="number" value={selectedPart.aiRegenRate ?? 0} onChange={(e) => handlePartChange("aiRegenRate", parseFloat(e.target.value) || 0)} className="bg-[#0d0810] text-white border border-[#3b1119] rounded px-1 py-0.5 text-[10px] w-12 text-right" />
                             </div>
                             <div className="flex items-center justify-between gap-2 text-gray-400">
                                <span className="shrink-0 font-medium text-[10px]">Damage Type</span>
                                <select value={selectedPart.aiDamageType || 'Physical'} onChange={(e) => handlePartChange("aiDamageType", e.target.value)} className="bg-[#0d0810] text-white border border-[#3b1119] rounded px-1 py-0.5 text-[10px] w-16">
                                  <option value="Physical">Physical</option>
                                  <option value="Fire">Fire</option>
                                  <option value="Ice">Ice</option>
                                  <option value="Poison">Poison</option>
                                  <option value="Magical">Magical</option>
                                </select>
                             </div>
                          </div>

                          {/* Boss Mechanics */}
                          <div className="space-y-1 mt-2">
                             <span className="text-gray-500 font-bold text-[9px] uppercase tracking-wider block">Boss Mechanics</span>
                             <label className="flex items-center gap-2 cursor-pointer group">
                                <input type="checkbox" checked={selectedPart.aiIsBoss || false} onChange={(e) => handlePartChange("aiIsBoss", e.target.checked)} className="w-3 h-3 accent-purple-600 rounded bg-[#090d18] border border-purple-600" />
                                <span className="text-purple-400 font-medium text-[10px]">Is Boss Entity</span>
                             </label>
                             <label className="flex items-center gap-2 cursor-pointer group">
                                <input type="checkbox" checked={selectedPart.aiImmuneToCC || false} onChange={(e) => handlePartChange("aiImmuneToCC", e.target.checked)} className="w-3 h-3 accent-purple-600 rounded bg-[#090d18] border border-purple-600" />
                                <span className="text-gray-400 font-medium text-[10px]">Immune to Stuns/Knockback</span>
                             </label>
                          </div>
                          
                        </div>
                      </details>
                    </div>`;

code = code.replace(targetStr, replaceStr);
fs.writeFileSync('src/components/PropertiesPanel.tsx', code);
