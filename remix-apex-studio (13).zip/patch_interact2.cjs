const fs = require('fs');
let code = fs.readFileSync('src/components/Viewport.tsx', 'utf-8');

code = code.replace(
  "if (onUpdatePart) onUpdatePart(nearbyNPC.id, { aiMode: 'Follow', aiDamage: 0, aiHeal: 0, aiWalkSpeed: 20 });",
  "if (onUpdatePart) onUpdatePart({ ...nearbyNPC, aiMode: 'Follow', aiDamage: 0, aiHeal: 0, aiWalkSpeed: 20 });"
);

code = code.replace(
  "if (onUpdatePart) onUpdatePart(nearbyNPC.id, { aiMode: 'Follow', aiDamage: 20 });",
  "if (onUpdatePart) onUpdatePart({ ...nearbyNPC, aiMode: 'Follow', aiDamage: 20 });"
);

code = code.replace(
  "if (onUpdatePart) onUpdatePart(nearbyNPC.id, { aiMode: 'Follow', aiHeal: 20 });",
  "if (onUpdatePart) onUpdatePart({ ...nearbyNPC, aiMode: 'Follow', aiHeal: 20 });"
);

code = code.replace(
  "if (onUpdatePart) onUpdatePart(nearbyNPC.id, { aiMode: 'Follow' });",
  "if (onUpdatePart) onUpdatePart({ ...nearbyNPC, aiMode: 'Follow' });"
);

fs.writeFileSync('src/components/Viewport.tsx', code);
