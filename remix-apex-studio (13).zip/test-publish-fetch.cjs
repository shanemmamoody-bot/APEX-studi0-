async function test() {
  const gamesRes = await fetch("http://localhost:3000/api/games");
  const games = await gamesRes.json();
  const game = games.find(g => g.name === "Test UI Game");
  console.log("Has guiObjects?", game.guiObjects.length > 0);
}
test();
