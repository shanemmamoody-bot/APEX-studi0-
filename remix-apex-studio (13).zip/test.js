import { createFullTycoon } from './src/utils/templates.js';
console.log(createFullTycoon().workspace.length);
