import re
with open('src/App.tsx', 'r') as f:
    text = f.read()

# very naive jsx tag matcher
tags = re.findall(r'<\/?([a-zA-Z0-9]+)[^>]*>', text)
print(f"Total tags: {len(tags)}")
