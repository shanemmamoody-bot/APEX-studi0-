const { readFileSync } = require('fs');

let template = readFileSync('src/utils/templates.ts', 'utf-8');
let match = template.match(/zombieWaveScript\s*=\s*\{([\s\S]*?)id:\s*'script-zombie-wave-manager'/);
console.log(match ? "Found script" : "Not found");
